Theme Name: anymag
Theme URI: http://3styler.in/themes/anymag/
Description: Clean Wordpress Blog Theme
Author: 3styler
Author URI: 3styler.in
Version: 1.0
Text Domain: anymag
License: Themeforest Licence
Documentation: http://3styler.in/themes/anymag/documentation/
License URI: http://themeforest.net/licenses
Tags: blog, right-sidebar, one-column, two-columns, featured-images, woocommerce, shop