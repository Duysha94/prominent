<header id="content-header">
 <?php if (get_theme_mod( 'anymag_topbar_social' )) : ?> 
   <?php get_template_part('inc/templates/social','header'); ?>
 <?php endif ?> 

<?php if (class_exists('WooCommerce') || is_active_sidebar('hidden-sidebar')) : ?>
<div id="top-bar-right">
 <?php if (class_exists('WooCommerce')) : ?>
  <div class="header-icon cart">  
    <div class="wc-shopping-cart">
    <?php $count = WC()->cart->get_cart_contents_count(); ?>
      <a class="cart-contents" href="<?php echo esc_url(wc_get_cart_url()); ?>" title="<?php esc_attr_e( 'View your shopping cart', 'anymag' ); ?>" aria-label="cart"><i class="fas fa-shopping-cart"></i><?php if ( $count >= 0 ) echo '<span class="cart-count">' . $count . '</span>'; ?>
      </a>
    </div>
   <div class="wc-user">
     <a class="user-contents" href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="User" aria-label="woo user">
      <i class="fas fa-user"></i>
    </a>
   </div>
  </div>
  <?php endif; ?>  

  <?php if (get_theme_mod('anymag_topbarright_search', true)) : ?>
    <div class="right-search">
       <a href="#" class="search" aria-label="search"><i class="fas fa-search"></i></a>
    </div> 
  <?php endif; ?>

  <?php if( is_active_sidebar('hidden-sidebar') ) { ?>
    <div class="header-icon">
      <div class="hidden-sidebar-button">
        <a href="#" class="open-hidden-sidebar" aria-label="sidebar">
          <span class="bar-1"></span>
          <span class="bar-2"></span>
        </a>
      </div>
    </div>
  <?php } ?>
  </div>
  <?php endif; ?>

</header> 
