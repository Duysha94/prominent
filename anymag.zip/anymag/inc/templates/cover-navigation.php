<?php

  	$prevPost = get_previous_post();
 	  $nextPost = get_next_post();

	if(!empty($prevPost) || !empty($nextPost)) { ?>
	<div class="post-navigation">
		
		<div class="post-next">
			<?php if(!empty($prevPost)) { $prevURL = get_permalink($prevPost->ID); ?>
			<a class="prev-post-label" href="<?php echo esc_url($prevURL); ?>" aria-label="Previous Post">
				<?php if( has_post_thumbnail($prevPost->ID)) : ?>
				<div class="postnav-image">
				<i class="fas fa-arrow-right"></i>
				<div class="overlay"></div>	
				<?php if( has_post_thumbnail($prevPost->ID) ){ echo '<div class="navprev">'.get_the_post_thumbnail($prevPost->ID, 'anymag-thumb').'</div>'; } ?>
				</div>
				<?php else : ?>
				<div class="postnav-noimage">
					<i class="fas fa-arrow-right"></i>
				</div>	
				<?php endif; ?>
			</a>
			<?php } ?>
		</div>
		
		<div class="post-prev">
			<?php if(!empty($nextPost)) { $nextURL = get_permalink($nextPost->ID); ?>
			<a class="next-post-label" href="<?php echo esc_url($nextURL); ?>" aria-label="Next Post">
				<?php if( has_post_thumbnail($nextPost->ID)) : ?>
				<div class="postnav-image">
				<i class="fas fa-arrow-left"></i>
				<div class="overlay"></div>	
				<?php if( has_post_thumbnail($nextPost->ID) ){ echo '<div class="navnext">'.get_the_post_thumbnail($nextPost->ID, 'anymag-thumb').'</div>'; } ?>
				</div>
				<?php else : ?>
				<div class="postnav-noimage">
          <i class="fas fa-arrow-left"></i>
				</div>	
				<?php endif; ?>
			</a>
			<?php } ?>
		</div>
		
	</div>
<?php } ?>