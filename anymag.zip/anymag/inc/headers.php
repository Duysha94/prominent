<?php if (class_exists('WooCommerce')) {
  if (is_product()) { $prodchck = true; }  
  else { $prodchck = false; }
 }
  else { $prodchck = false; }
?>

<?php if (is_home()) : ?>
  <?php if (!get_theme_mod('anymag_cover')) : ?><div class="site-wrapper f-width"> 
  <?php else : ?><div class="site-wrapper"><?php endif; ?>
  <div class="magheader"> 
    <?php if (!get_theme_mod( 'anymag_cover' )) : ?>
    <?php get_template_part('inc/headers/header-left'); ?>
    <?php endif; ?>  
    <?php get_template_part('inc/headers/header-right'); ?>
  </div> 
  <?php if (get_theme_mod( 'anymag_cover' )) : ?>
    <?php get_template_part('inc/covers/cover'); ?>
  <?php endif; ?> 
  <div class="magcontent">
  <?php if (get_theme_mod( 'anymag_cover' )) : ?>
    <div class="fold-shadow-right"></div>
   <?php else : ?>
    <div class="fold-shadow"></div>
   <?php endif ?>
  <div id="main-area"> 

 <?php elseif (is_single() && $prodchck == false) : ?>
  <?php if (!has_post_thumbnail() || is_page_template('framework/post-fullwidth.php')) : ?><div class="site-wrapper f-width"> 
  <?php else : ?><div class="site-wrapper"><?php endif; ?>
  <div class="magheader">
    <?php if(!has_post_thumbnail() || is_page_template('framework/post-fullwidth.php')) : ?>
    <?php get_template_part('inc/headers/header-left'); ?>
    <?php endif; ?>  
    <?php get_template_part('inc/headers/header-right'); ?>
  </div>
    <?php if(is_front_page() && get_theme_mod('anymag_cover')) : ?>
    <?php get_template_part('inc/covers/cover'); ?>
      <?php else : ?> 
      <?php if(has_post_thumbnail() && !is_page_template('framework/post-fullwidth.php')) : ?>
         <?php get_template_part('inc/covers/cover-single'); ?>
        <?php endif; ?>
      <?php endif; ?> 
    <div class="magcontent">
    <?php if (get_theme_mod('anymag_cover') || has_post_thumbnail()) : ?>
      <div class="fold-shadow-right"></div>

     <?php endif ?>
    <div id="main-area">  

<?php elseif (is_page()) : ?>
  <?php if (!has_post_thumbnail()) : ?><div class="site-wrapper f-width"> 
  <?php else : ?><div class="site-wrapper"><?php endif; ?>
  <div class="magheader">
    <?php if(!has_post_thumbnail() && !is_front_page()) : ?>
    <?php get_template_part('inc/headers/header-left'); ?>
    <?php endif; ?>  
    <?php get_template_part('inc/headers/header-right'); ?>
  </div>
    <?php if(is_front_page() && get_theme_mod('anymag_cover')) : ?>
      <?php if (get_theme_mod('anymag_cover')) : ?>
       <?php get_template_part('inc/covers/cover'); ?>
     <?php endif ?>
      <?php else : ?> 
      <?php if(has_post_thumbnail()) : ?>
        <?php get_template_part('inc/covers/cover-page'); ?>
      <?php endif; ?>
    <?php endif; ?> 
  <div class="magcontent">  
   <?php if (get_theme_mod('anymag_cover') || has_post_thumbnail()) : ?>
    <div class="fold-shadow-right"></div>
   <?php endif ?>
  <div id="main-area">       
 
<?php elseif (is_category()) : ?>
  <?php 
    $category = get_queried_object();
    $cat_id ='category_'.$category->term_id;
    if (class_exists('ACF')) {
    $cat_image = get_field('category_image', $cat_id);
    } 
  if (!$cat_image) : ?><div class="site-wrapper f-width"> 
  <?php else : ?><div class="site-wrapper"><?php endif; ?>
  <div class="magheader">
    <?php if(!$cat_image) : ?>
    <?php get_template_part('inc/headers/header-left'); ?>
    <?php endif; ?>  
    <?php get_template_part('inc/headers/header-right'); ?>
  </div>
  <?php if ($cat_image) : ?>
    <?php get_template_part('inc/covers/cover-cat'); ?>
  <?php endif; ?>  
  <div class="magcontent">
  <?php if ($cat_image) : ?>
    <div class="fold-shadow-right"></div>
  <?php else : ?>
    <div class="fold-shadow"></div>
  <?php endif ?>
  <div id="main-area"> 

<?php elseif (is_tag()) : ?>
  <?php 
    $posttag = get_queried_object();
    $tag_id ='category_'.$posttag->term_id;
    if (class_exists('ACF')) {
    $tag_image = get_field('tag_image', $tag_id);
    } 
  if (!$tag_image) : ?><div class="site-wrapper f-width"> 
  <?php else : ?><div class="site-wrapper"><?php endif; ?>
  <div class="magheader">
    <?php if(!$tag_image) : ?>
    <?php get_template_part('inc/headers/header-left'); ?>
    <?php endif; ?>  
    <?php get_template_part('inc/headers/header-right'); ?>
  </div>
  <?php if ($tag_image) : ?>
    <?php get_template_part('inc/covers/cover-tag'); ?>
  <?php endif; ?>  
  <div class="magcontent">
  <?php if ($tag_image) : ?>
    <div class="fold-shadow-right"></div>
  <?php else : ?>
    <div class="fold-shadow"></div>
  <?php endif ?>
  <div id="main-area">     

<?php elseif (is_archive() || is_author()) : ?>
  <div class="site-wrapper f-width">
  <div class="magheader">
    <?php get_template_part('inc/headers/header-left'); ?>
    <?php get_template_part('inc/headers/header-right'); ?>
  </div>
  <div class="magcontent">
  <div class="fold-shadow"></div>
  <div id="main-area"> 

<?php 
  elseif (class_exists('WooCommerce') && is_product()) : ?>
  <?php if (!has_post_thumbnail()) : ?><div class="site-wrapper f-width"> 
  <?php else : ?><div class="site-wrapper"><?php endif; ?>
  <div class="magheader">
    <?php get_template_part('inc/headers/header-left'); ?>
    <?php get_template_part('inc/headers/header-right'); ?>
  </div>

<?php else : ?>
  <div class="site-wrapper f-width">
  <div class="magheader">
    <?php get_template_part('inc/headers/header-left'); ?>
    <?php get_template_part('inc/headers/header-right'); ?>
  </div>
  <div class="magcontent">
  <div id="main-area">
<?php endif; ?>  