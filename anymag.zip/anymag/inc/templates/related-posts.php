<?php 

$orig_post = $post;
global $post;

$categories = get_the_category($post->ID);

if ($categories) {

	$category_ids = array();

	foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
	
	$args = array(
		'category__in'     => $category_ids,
		'post__not_in'     => array($post->ID),
		'posts_per_page'   => 3, // Number of related posts that will be shown.
		'ignore_sticky_posts' => 1,
		'orderby' => 'rand'
	);

	$my_query = new wp_query( $args );
	if( $my_query->have_posts() ) { ?>
		<div class="section-title <?php if (get_theme_mod('anymag_side_pattern', true)) : ?>side-pattern<?php endif; ?>"><h2 class="post-box-title"><span><?php esc_html_e('You Might Also Like', 'anymag'); ?></span></h2></div>
		<?php while( $my_query->have_posts() ) {
			$my_query->the_post();?>
				<div class="item-related">
					
					<?php if ( (function_exists('has_post_thumbnail')) && (has_post_thumbnail()) ) : ?>
                      <div class="related-image">
					  <a href="<?php echo get_permalink() ?>"><?php the_post_thumbnail('anymag-misc'); ?></a>
					</div>
					<?php endif; ?>
					
					<h5><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h5>
					<?php if(get_theme_mod('anymag_list_date', true)) : ?>
					  <span class="widget-date"><?php the_time( get_option('date_format') ); ?></span>
					<?php endif; ?>
					
				</div>
		<?php
		}
	}
}
$post = $orig_post;
wp_reset_postdata();

?>