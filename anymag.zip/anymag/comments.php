<?php
if ( post_password_required() ){
    return;
}
?>
<div id="comments" class="post-comments">

  <div class="comments-list">

<div class="comments-title"> 
    <?php comments_number( '', '<h3><span>'.esc_html__('1 Comment','anymag').'</span></h3>', '<h3><span>'.esc_html__('% Comments','anymag').'</span></h3>' ); ?>
</div>

      <?php if ( have_comments() ) { ?>
        <div class="comments">
          <ul class="comment-list list-unstyled">
            <?php wp_list_comments('callback=anymag_list_comments'); ?>
          </ul>
          <?php
          // Are there comments to navigate through?
          if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
              ?>
            <footer class="navigation comment-navigation">
              <div class="previous"><?php previous_comments_link( esc_html__( '&larr; Older Comments', 'anymag' ) ); ?></div>
              <div class="next right"><?php next_comments_link( esc_html__( 'Newer Comments &rarr;', 'anymag' ) ); ?></div>
            </footer><!-- .comment-navigation -->
          <?php endif; // Check for comment navigation ?>

          <?php if ( ! comments_open() && get_comments_number() ) : ?>
              <p class="no-comments"><?php esc_html_e( 'Comments are closed.' , 'anymag' ); ?></p>
          <?php endif; ?>
        </div>
        <?php } ?>
    </div>
    <?php
      $aria_req = ( $req ? " aria-required='true'" : '' );
      $comment_args = array(
        'title_reply'=> '<span class="heading widgettitles">'.esc_html__('Leave a Comment','anymag').'</span>',
        'comment_field' => '<div class="comment-form-comment"><textarea rows="8" id="comment" class="form-control" placeholder="'.esc_attr__('Comment*', 'anymag').'" name="comment"'.$aria_req.'></textarea> </div>',
        'fields' => apply_filters( 'comment_form_default_fields',
                array(
                'author' => '<div class="comment-form-group"><div class="comment-author"><input type="text" name="author" placeholder="'.esc_attr__('Name*', 'anymag').'" class="form-control" id="author" value="' . esc_attr( $commenter['comment_author'] ) . '" ' . $aria_req . ' /></div>',
                'email' => '<div class="comment-email"><input id="email" name="email" class="form-control" placeholder="'.esc_attr__('Email*', 'anymag').'" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" ' . $aria_req . ' /></div>',
                'url' => '<div class="comment-url"><input id="url" name="url" class="form-control" placeholder="'.esc_attr__('Website', 'anymag').'" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) . '" /></div></div>',
            )),
        'label_submit' => esc_html__('Post Comment', 'anymag'),
        'comment_notes_before' => '<p class="h-info">'.esc_html__('Your email address will not be published.','anymag').'</p>',
        'comment_notes_after' => '',
      );
      ?>
      <?php if('open' == $post->comment_status){ ?>
        <div class="commentform">
          <?php anymag_comment_form($comment_args,'btn-variant'); ?>
        </div><!-- end commentform -->
      <?php } ?>

</div><!-- end comments -->