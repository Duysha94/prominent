<?php
  $posttag = get_queried_object();
  $tag_id ='post_tag_'.$posttag->term_id;
  if (class_exists('ACF')) {
    $tag_image = get_field('tag_image', $tag_id);
    $tag_text =  get_field('tag_text', $tag_id);
  } 
?>

<?php get_header(); ?>

    <div class="content-area<?php if (get_theme_mod('anymag_archive_sidebar') && is_active_sidebar('main-sidebar')) : ?> has-sidebar<?php endif; ?>">

      <?php if(get_theme_mod('anymag_adv_archive') == true) : ?>     
        <?php get_template_part('inc/templates/add-area'); ?>
      <?php endif; ?> 
      
      <div class="category-box <?php if (get_theme_mod('anymag_side_pattern', true)) : ?>side-pattern<?php endif; ?>">
        <h1><?php printf( __( '%s', 'anymag' ), single_cat_title( '', false ) ); ?></h1>
      <?php  if ($tag_text) : ?>   
        <div class="category-text"> <?php echo wp_kses_post($tag_text); ?> </div> 
      <?php endif; ?>  
      </div> 


      <div class="posts-area">
      <?php 
        if (get_theme_mod('anymag_categ_layout') == 'categ-list') { $postclass="post-list"; }
        elseif (get_theme_mod('anymag_categ_layout') == 'categ-wide') { $postclass="post-wide"; }
        else { $postclass="two-fr"; }
      ?>

        <?php if (have_posts()) : ?> 
        <div class="blog-posts <?php echo esc_html($postclass) ?>">
          <?php  while (have_posts()) : the_post(); ?>
            <?php get_template_part('content'); ?>
          <?php endwhile; ?>
        </div>  
        <?php else : ?>
          <?php get_template_part('content', 'none'); ?>
        <?php endif; ?>
         
        <div class="page-nav">
          <?php anymag_pagination_type(); ?>
        </div>
      </div>

      <?php if ( get_theme_mod('anymag_archive_sidebar') && is_active_sidebar('main-sidebar')) : ?>
        <?php get_sidebar(); ?>
      <?php endif; ?>
      
    </div>

<?php get_footer(); ?>