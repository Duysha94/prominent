<?php
    global $post;
    $loop = get_posts( 'numberposts=1' );
    $firstPost = ($wp_query->current_post) ;
    $firstid = $loop[0]->ID;;
 ?>

<div class="widget">
	<div class="post-navigation">
		<div class="post-next">
			<?php 
			if(!empty($firstid)) { $firstURL = get_permalink($firstid); ?>
			<a class="first-post-label" href="<?php echo esc_url($firstURL); ?>" >
				<?php if( has_post_thumbnail($firstid)) : ?>
				<div class="postnav-image">
				<i class="fas fa-arrow-right"></i>
				<div class="overlay"></div>	
				<?php if( has_post_thumbnail($firstid) ){ echo '<div class="navfirst">'.get_the_post_thumbnail($firstid, 'thumbnail').'</div>'; } ?>
				</div>
				<?php else : ?>
				<div class="postnav-noimage">
					<i class="fas fa-arrow-right"></i>
				</div>	
				<?php endif; ?>
			</a>
			<?php } ?>
		</div>
	</div>
</div>