<?php
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
if( $paged == 1 ) :
?>

<?php if  (get_theme_mod('anymag_featcat_header')) : ?>
	<div class="section-title <?php if (get_theme_mod('anymag_side_pattern', true)) : ?>side-pattern<?php endif; ?>">
		<h2><?php 
    $anymag_allow_html = array('i' => array());
		echo wp_kses(get_theme_mod('anymag_featcat_header'), $anymag_allow_html); ?></h2>
	</div>
<?php endif; ?> 
<div class="feat-category">
<?php 
  $catid = get_theme_mod( 'anymag_featured_category' );
  $catquery = new WP_Query( 'cat='.$catid.'&posts_per_page=4' ); 
  $post = $posts[0]; 
  $count=0;
?>
	<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
	<div class="feat-categ-item <?php $count++; if($count == 1) { echo 'first'; } ?>">
		<div class="image-part">
			<div class="overlay"></div>
				<a href="<?php the_permalink() ?>" rel="bookmark">
			    <?php the_post_thumbnail('anymag-misc'); ?>
			  </a> 
		</div>
		<div class="content-part">
			<div class="the-content">
	     <h5 class="feat-title <?php if (get_theme_mod('anymag_hover_style', true) == 'hover-underline'):?>underline<?php endif; ?>"><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h5>
	      <?php if (get_theme_mod('anymag_featcat_date', true)):?>
	       	<span class="widget-date"><?php the_time( get_option('date_format') ); ?></span>
        <?php endif; ?>
      </div>  
	  </div>
	</div> 
	<?php endwhile; ?> 
<?php wp_reset_postdata(); ?>
</div>
<?php endif; ?> <!-- #if paged -->