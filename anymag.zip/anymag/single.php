<?php get_header(); ?>

	<div class="container site-content single-page">

	  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <?php get_template_part('content'); ?>
      <?php endwhile; ?>
			
			<?php endif; ?>

	</div>		

<?php get_footer(); ?> 