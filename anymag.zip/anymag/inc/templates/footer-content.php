<footer id="footer">
    <div class="container">
  
  <?php if(get_theme_mod('anymag_show_footer_logo', true)) : ?>     
    <?php if (get_theme_mod( 'anymag_footer_logo' )) : ?>
       <div class="footer-logo">
          <a href="<?php echo esc_url(home_url()); ?>/"><img src="<?php echo esc_url(get_theme_mod('anymag_footer_logo')); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"></a>
       </div> 
       <?php else : ?>
       <div class="footer-logo">
          <a href="<?php echo esc_url(home_url()); ?>/"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/footer-logo.png" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" /></a>
       </div>   
    <?php endif; ?> 
  <?php endif; ?>    


  <?php if (get_theme_mod( 'anymag_footer_menu' )) : ?>
    <?php 
      wp_nav_menu( array(
      'theme_location' => 'footer-menu',
      'menu_class' => 'footer-menu')); 
    ?>
  <?php endif; ?> 

    <?php if (get_theme_mod('anymag_footer_social')) : ?>
      <?php get_template_part('inc/templates/social','footer'); ?> 
    <?php endif; ?> 

    <?php if(get_theme_mod( 'anymag_show_copyright', true )) { ?>
      <?php if( !get_theme_mod( 'anymag_copyright_text' ) ) { ?>
        <div id="footer-copyright">
          <?php esc_html_e( '&copy;', 'anymag' ); ?><?php echo date(' Y '); ?>
          <?php bloginfo( 'name' ); ?>
          <?php esc_html_e( ' - All Rights Reserved.', 'anymag' ); ?>
        </div>
      <?php } else { ?>
      <div id="footer-copyright">
        <?php 
        $anymag_allow_html = array(
          'a' => array(
            'href' => array(),
            'title' => array()
          ),
          'br' => array(),
          'em' => array(),
          'strong' => array(),
          'b' => array(),
          'i' => array(),
        );
        echo wp_kses(get_theme_mod('anymag_copyright_text'), $anymag_allow_html); ?>
      </div>
     <?php }} ?>  
  </div>
</footer>

<div class="searchform-overlay">
    <a href="javascript:;" class="btn-close-search"><i class="close-icon"></i></a>
    <div class="searchform">
      <p><?php echo esc_html_x('Start typing and press Enter to search', 'front-view', 'anymag')?></p>
      <?php get_search_form(); ?>
    </div>
</div>
