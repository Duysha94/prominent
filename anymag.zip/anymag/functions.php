<?php 

//Set content width
//--------------------------------------------------------------------------*/
if ( ! isset( $content_width ) )
  $content_width = 1080;

//Anymag functions and definitions
//--------------------------------------------------------------------------*/

add_action( 'after_setup_theme', 'anymag_theme_setup' );
if ( !function_exists('anymag_theme_setup') ) {

  function anymag_theme_setup() {
    
    // Register navigation menu
    register_nav_menus( array(
      'header-menu' => esc_html__( 'Header Menu', 'anymag' )
    ) );
    register_nav_menus( array(
      'footer-menu' => esc_html__( 'Footer Menu', 'anymag' )
    ) );
        
    // Localization support
    load_theme_textdomain('anymag', get_template_directory() . '/languages');

    // Support title tag
    add_theme_support( 'title-tag' );
        
    // Set post formats
    add_theme_support( 'post-formats', array( 'video', 'audio', 'gallery' ) );

    // Add default posts and comments RSS feed link.
     add_theme_support( 'automatic-feed-links' );

    // Enable support for Post Thumbnails dimensions.
    add_theme_support('post-thumbnails');
    add_image_size( 'anymag-small', 60, 60, true );
    add_image_size( 'anymag-thumb', 96, 100, true );
    add_image_size( 'anymag-misc', 490, 550, true );
    add_image_size( 'anymag-slide', 960, 550, true );
    add_image_size( 'anymag-post', 960, 1000, true );


// Disables the block editor from managing widgets in the Gutenberg plugin.
add_filter( 'gutenberg_use_widgets_block_editor', '__return_false', 100 );

// Disables the block editor from managing widgets. renamed from wp_use_widgets_block_editor
add_filter( 'use_widgets_block_editor', '__return_false' );

// Enable support animated gifs.
function resizeGifs(array $metadata, int $attachment_id, string $context)
{
    if (preg_match('/\.gif$/', $metadata['file'])) {

        foreach ($metadata['sizes'] as $image_site) {

            $file_path_original = wp_upload_dir()['basedir'] .'/'. $metadata['file'];
            $imagick = new Imagick($file_path_original);
            $imagick = $imagick->coalesceImages();

            $width = $image_site['width'];
            $height = $image_site['height'];

            foreach ($imagick as $frame) {
                $frame->cropThumbnailImage($width, $height);
                $imagick->setImagePage($width, $height, 0, 0);
            }
            $imagick = $imagick->deconstructImages();

            $file_path_thump = wp_upload_dir()['path'] .'/'. $image_site['file'];
            $imagick->writeImages($file_path_thump, true);
        }
    }
    return $metadata;
}
    // Gutenberg
    add_theme_support( 'align-wide' );
    add_theme_support( 'editor-styles' );
    add_editor_style( 'customize/assets/css/editor-styles.css' );
  }
}

//Theme functions
require get_template_directory().'/framework/theme-functions.php';
require get_template_directory().'/framework/theme-fields.php';
require get_template_directory().'/framework/metabox.php';
require get_template_directory().'/framework/elementor-helper.php';
//Customizer
include_once(trailingslashit( get_template_directory() ).'customize/customize.php');
include_once(trailingslashit( get_template_directory() ).'customize/customize-controller.php');
include_once(trailingslashit( get_template_directory() ).'customize/custom-css.php');
if( is_admin() ){
  include_once(trailingslashit( get_template_directory() ).'customize/editor-css.php');
}

function anymag_widgets_fonts() {
    $fonts_url = '';
    $font_families = array();
    $font_families[] = 'Bitter:400,500,600';
    $font_families[] = 'Playfair Display:400,500,700';
    $font_families[] = 'Oswald:400,500,600';
    $font_families[] = 'Roboto:400,500,600';
    $font_families[] = 'Teko:400,500,600';
    $query_args = array(
      'family' => urlencode( implode( '|', $font_families ) ),
      'subset' => urlencode( 'latin,latin-ext' ),
    );
    $fonts_url = add_query_arg( $query_args, '//fonts.googleapis.com/css' );
    return esc_url_raw( $fonts_url );
}


// Load scripts and styles
//--------------------------------------------------------------------------*/
add_action( 'wp_enqueue_scripts','anymag_load_scripts', 1 );
function anymag_load_scripts() {
  // Register Styles
  wp_enqueue_style('owl-carousel', get_template_directory_uri() . '/assets/css/owl.carousel.css', array(), '2.3.4');
  wp_enqueue_style('fontawesome', get_template_directory_uri() . '/assets/fonts/fontawesome-free-5.15.2/css/all.min.css', array(), '5.15.2');
  wp_enqueue_style('fontello', get_template_directory_uri() . '/assets/fonts/css/fontello.css', array(), '5.13.0');
  wp_enqueue_style('interlace-css', get_template_directory_uri() . '/assets/css/interlace.css', array(), '2.2.1');
  wp_enqueue_style('simplebar', get_template_directory_uri() . '/assets/css/simplebar.css', array(), '6.2.7');
  wp_enqueue_style('anymag-main', get_template_directory_uri() . '/style.css', array(), '1.0', 'all' );
  //Responsive
  wp_enqueue_style( 'anymag-responsive', get_template_directory_uri() . '/assets/css/responsive.css', array(), '1.0', 'all' );
  wp_enqueue_style( 'widgets-fonts', anymag_widgets_fonts(), array(), null );
  // Register Scripts 
  wp_enqueue_script('owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array( 'jquery' ), '', true);
  wp_enqueue_script('fitvids', get_template_directory_uri() . '/assets/js/fitvids.js', array( 'jquery' ), '', true);
  wp_enqueue_script('simple-bar', get_template_directory_uri() . '/assets/js/simple-bar.min.js', array(), '6.2.7', true);
  wp_enqueue_script('interlace', get_template_directory_uri() . '/assets/js/interlace.min.js', array( 'jquery' ), '', true);
  if(get_theme_mod('anymag_inf_scroll')) {
   wp_enqueue_script( 'infinite_scroll', get_template_directory_uri() . '/assets/js/infinite-scroll.pkgd.min.js', array('jquery'), '2.1.0', true );
  }
  wp_enqueue_script('anymag-scripts', get_template_directory_uri() . '/assets/js/anymag.js', array( 'jquery' ), '', true);
}

if( class_exists('WooCommerce') ){
  add_action( 'wp_enqueue_scripts','anymag_woo_styles', 10);
  function anymag_woo_styles() {
    wp_enqueue_style( 'anymag-woocommerce', get_template_directory_uri(). '/assets/css/woocommerce.css', array(), '1.0', 'all' );
  }      
}

function anymag_gutenberg_editor() {
  wp_enqueue_style( 'anymag-blocks-style', get_template_directory_uri() . '/customize/assets/css/editor-styles.css');
  wp_enqueue_style('fontawesome', get_template_directory_uri() . '/assets/fonts/fontawesome-free-5.15.2/css/all.min.css', array(), '5.15.2');
}
add_action( 'enqueue_block_editor_assets', 'anymag_gutenberg_editor' );


ElementorHelper::get_instance();

// Register Widgets
//--------------------------------------------------------------------------*/
if ( ! function_exists( 'anymag_widgets_init' ) ) {
  function anymag_widgets_init() {
    register_sidebar(array(
      'name' => esc_html__('Main Sidebar', 'anymag'),
      'id' => 'main-sidebar',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget' => '</div>',
      'before_title' => '<h4 class="widget-title">',
      'after_title' => '</h4>',
    ));
    register_sidebar(array(
      'name' => esc_html__('Hidden Sidebar', 'anymag'),
      'id' => 'hidden-sidebar',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget' => '</div>',
      'before_title' => '<h4 class="widget-title">',
      'after_title' => '</h4>',
    ));
    register_sidebar(array(
      'name' => esc_html__('Cover Sidebar Left', 'anymag'),
      'id' => 'cover-sidebar-left',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget' => '</div>',
      'before_title' => '<h4 class="widget-title">',
      'after_title' => '</h4>',
    ));
    register_sidebar(array(
      'name' => esc_html__('Cover Sidebar Right', 'anymag'),
      'id' => 'cover-sidebar-right',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget' => '</div>',
      'before_title' => '<h4 class="widget-title">',
      'after_title' => '</h4>',
    ));
  }
}
add_action( 'widgets_init', 'anymag_widgets_init' );

// Register Plugins
//--------------------------------------------------------------------------*/
require_once get_template_directory() . '/framework/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'anymag_register_theme_plugins' );

function anymag_register_theme_plugins() {
    $plugins = array(    
    array(
      'name'                  => esc_html__('Anymag Core', 'anymag'),
      'slug'                  => 'anymag-core',
      'source'                => get_template_directory() . '/framework/plugins/anymag-core.zip',
      'required'              => true,
      'version'               => '',
      'force_activation'      => false,
      'force_deactivation'    => false,
      'external_url'          => '',
    ),  
    array(
      'name'                  => esc_html__('Advanced Custom Fields','anymag'),
      'slug'                  => 'advanced-custom-fields',
      'required'              => true,
      'version'               => '',
      'force_activation'      => false,
      'force_deactivation'    => false,
    ),
    array(
      'name'                  => esc_html__('Contact Form 7', 'anymag'),
      'slug'                  => 'contact-form-7',
      'required'              => false,
      'version'               => '',
      'force_activation'      => false,
      'force_deactivation'    => false,
      'external_url'          => '',
    ),
    array(
      'name'                  => esc_html__('MailChimp for WordPress', 'anymag'),
      'slug'                  => 'mailchimp-for-wp',
      'required'              => false,
      'version'               => '',
      'force_activation'      => false,
      'force_deactivation'    => false,
      'external_url'          => '',
    ),
    array(
      'name'                  => esc_html__('Smash Balloon Instagram Feed', 'anymag'),
      'slug'                  => 'instagram-feed',
      'required'              => false,
      'version'               => '',
      'force_activation'      => false,
      'force_deactivation'    => false,
      'external_url'          => '',
    ),
    array(
      'name'                  => esc_html__('One Click Demo Import','anymag'),
      'slug'                  => 'one-click-demo-import',
      'required'              => false,
      'version'               => '',
      'force_activation'      => false,
      'force_deactivation'    => false,
    ),
    array(
      'name'                  => esc_html__('Envato Market','anymag'),
      'slug'                  => 'envato-market',
      'source'                => get_stylesheet_directory() . '/framework/plugins/envato-market.zip',
      'required'              => false,
      'version'               => '2.0.8',
    ),
 );

    $config = array(
      'id'           => 'anymag',                 // Unique ID for hashing notices for multiple 
      'default_path' => '',                        // Default absolute path to bundled plugins.
      'menu'         => 'tgmpa-install-plugins',   // Menu slug.
      'has_notices'  => true,                      // Show admin notices or not.
      'dismissable'  => true,                      // If false, a user cannot dismiss the nag message.
      'dismiss_msg'  => '',                        // If 'dismissable' is false, this message will be 
      'is_automatic' => true,                     // Automatically activate plugins after installation 
      'message'      => '',                        // Message to output right before the plugins table.
    );
    tgmpa( $plugins, $config );
}   

if(!function_exists('anymag_import_files')){
  function anymag_import_files() {
      return array(
          array(
              'import_file_name'             => 'Main Demo',
              'local_import_file'            => trailingslashit( get_template_directory() ).'framework/demos/main/demo.xml',
              'local_import_customizer_file' => trailingslashit( get_template_directory() ).'framework/demos/main/customizer.dat',
              'local_import_widget_file'     => trailingslashit( get_template_directory() ).'framework/demos/main/widgets.wie',
              'import_preview_image_url'     => trailingslashit( get_template_directory_uri() ).'framework/demos/main/demo.jpg',
              'preview_url'                  => 'http://3styler.org/themes/anymag/main/',
          ),
          array(
              'import_file_name'             => 'Multiple Issues Demo (Elementor)',
              'local_import_file'            => trailingslashit( get_template_directory() ).'framework/demos/multi/demo.xml',
              'local_import_customizer_file' => trailingslashit( get_template_directory() ).'framework/demos/multi/customizer.dat',
              'local_import_widget_file'     => trailingslashit( get_template_directory() ).'framework/demos/multi/widgets.wie',
              'import_preview_image_url'     => trailingslashit( get_template_directory_uri() ).'framework/demos/multi/demo.jpg',
              'preview_url'                  => 'http://3styler.org/themes/anymag/multi/',
          ),
          array(
              'import_file_name'             => 'Extended Demo',
              'local_import_file'            => trailingslashit( get_template_directory() ).'framework/demos/extended/demo.xml',
              'local_import_customizer_file' => trailingslashit( get_template_directory() ).'framework/demos/extended/customizer.dat',
              'local_import_widget_file'     => trailingslashit( get_template_directory() ).'framework/demos/extended/widgets.wie',
              'import_preview_image_url'     => trailingslashit( get_template_directory_uri() ).'framework/demos/extended/demo.jpg',
              'preview_url'                  => 'http://3styler.org/themes/anymag/extended/',
          ),
          array(
              'import_file_name'             => 'Dark Demo',
              'local_import_file'            => trailingslashit( get_template_directory() ).'framework/demos/dark/demo.xml',
              'local_import_customizer_file' => trailingslashit( get_template_directory() ).'framework/demos/dark/customizer.dat',
              'local_import_widget_file'     => trailingslashit( get_template_directory() ).'framework/demos/dark/widgets.wie',
              'import_preview_image_url'     => trailingslashit( get_template_directory_uri() ).'framework/demos/dark/demo.jpg',
              'preview_url'                  => 'http://3styler.org/themes/anymag/dark/',
          ),
          array(
              'import_file_name'             => 'Fashion Demo',
              'local_import_file'            => trailingslashit( get_template_directory() ).'framework/demos/fashion/demo.xml',
              'local_import_customizer_file' => trailingslashit( get_template_directory() ).'framework/demos/fashion/customizer.dat',
              'local_import_widget_file'     => trailingslashit( get_template_directory() ).'framework/demos/fashion/widgets.wie',
              'import_preview_image_url'     => trailingslashit( get_template_directory_uri() ).'framework/demos/fashion/demo.jpg',
              'preview_url'                  => 'http://3styler.org/themes/anymag/fashion/',
          ),
          array(
              'import_file_name'             => 'Lifestyle Demo',
              'local_import_file'            => trailingslashit( get_template_directory() ).'framework/demos/lifestyle/demo.xml',
              'local_import_customizer_file' => trailingslashit( get_template_directory() ).'framework/demos/lifestyle/customizer.dat',
              'local_import_widget_file'     => trailingslashit( get_template_directory() ).'framework/demos/lifestyle/widgets.wie',
              'import_preview_image_url'     => trailingslashit( get_template_directory_uri() ).'framework/demos/lifestyle/demo.jpg',
              'preview_url'                  => 'http://3styler.org/themes/anymag/lifestyle/',
          )
      );
  }
  add_filter( 'pt-ocdi/import_files', 'anymag_import_files' );
}  

if(!function_exists('anymag_after_import_setup')) {

    function anymag_after_import_setup( $selected_import ) {
    if( 'Main Demo' === $selected_import['import_file_name'] ) {
      $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
      set_theme_mod( 'nav_menu_locations', array(
        'header-menu' => $main_menu->term_id,
      ));
    }
    if( 'Lifestyle Demo' === $selected_import['import_file_name'] ) {
      $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
      set_theme_mod( 'nav_menu_locations', array(
        'header-menu' => $main_menu->term_id,
      ));
    }
    if( 'Extended Demo' === $selected_import['import_file_name'] ) {
      $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
      set_theme_mod( 'nav_menu_locations', array(
        'header-menu' => $main_menu->term_id,
      ));
      $front_page_id = get_page_by_title('Home');
      update_option( 'show_on_front', 'page' );
      update_option( 'page_on_front', $front_page_id->ID );
    }
    if( 'Multiple Issues Demo (Elementor)' === $selected_import['import_file_name'] ) {
      $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
      set_theme_mod( 'nav_menu_locations', array(
        'header-menu' => $main_menu->term_id,
      ));
      $front_page_id = get_page_by_title('August');
      update_option( 'show_on_front', 'page' );
      update_option( 'page_on_front', $front_page_id->ID );
    }
  }
  add_action( 'pt-ocdi/after_import', 'anymag_after_import_setup' );
}

?>