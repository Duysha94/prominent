<?php
  $posttag = get_queried_object();
  $tag_id ='post_tag_'.$posttag->term_id;
  if (class_exists('ACF')) {
    $tag_image = get_field('tag_image', $tag_id);
    $tag_text =  get_field('tag_text', $tag_id);
  } 
?>
<div class="magcover">
  <?php if(get_theme_mod('anymag_turn_left', true)) : ?><div class="turn-left"></div><?php endif; ?>
  <div class="fold-shadow-left"></div>
    <div class="cover-wrap">
      <div class="cover-content">
        <?php get_template_part('inc/headers/header-post'); ?>
        <div class="overlay"></div>
          <?php 
            $thumbnail1 = $tag_image ['sizes']['anymag-post'];
            $thumbnail2 = $tag_image ['sizes']['anymag-thumb'];
          ?>
        <div class="single-post-image" data-interlace-src="<?php echo esc_url($thumbnail1); ?>" data-interlace-low="<?php echo esc_url($thumbnail2); ?>"> </div>   
      </div>
  </div> 
  <?php the_archive_description( '<div class="category-descr">', '</div>' ); ?>
</div> 
