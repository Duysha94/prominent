<?php
/**
 * Adding Custom Meta Boxes.
 *
 * @package anymag
 */

/**
 * ==================================
 * Video Thumbnails
 * ==================================
 */

/**
 * Add video meta boxes
 */
function meta_boxe_video_options() {
	$function = sprintf( 'add_meta_%s', 'box' );

	$function( 'mb_video_thumbonial', esc_html__( 'Video Thumbnail', 'anymag' ), 'mb_video_options_callback', array( 'post', 'page' ), 'side' );
}
add_action( sprintf( 'add_meta_%s', 'boxes' ), 'meta_boxe_video_options' );

function mb_video_options_callback( $post ) {
	wp_nonce_field( 'video_thumbonial', 'mb_video_thumbonial' );
	$post_video_url           = get_post_meta( $post->ID, 'post_video_url', true );
	$post_video_bg_start_time = get_post_meta( $post->ID, 'post_video_bg_start_time', true );
	$post_video_bg_end_time   = get_post_meta( $post->ID, 'post_video_bg_end_time', true );

	// Set Default Setings.
  $post_video_url           = $post_video_url ? $post_video_url : '';
	$post_video_bg_start_time = $post_video_bg_start_time ? (int) $post_video_bg_start_time : 0;
	$post_video_bg_end_time   = $post_video_bg_end_time ? (int) $post_video_bg_end_time : 0;
	?>
	<!-- YouTube URL -->
	<h4><?php esc_html_e( 'YouTube URL', 'anymag' ); ?></h4>
	<input style="width:100%" type="text" id="post_video_url" name="post_video_url" value="<?php echo esc_attr( $post_video_url ); ?>">
	<!-- Start Time -->
	<h4><?php esc_html_e( 'Start Time (sec)', 'anymag' ); ?></h4>
	<input class="small-text" type="number" id="post_video_bg_start_time" name="post_video_bg_start_time" value="<?php echo esc_attr( $post_video_bg_start_time ); ?>">
	<!-- End Time -->
	<h4><?php esc_html_e( 'End Time (sec)', 'anymag' ); ?></h4>
	<input class="small-text" type="number" id="post_video_bg_end_time" name="post_video_bg_end_time" value="<?php echo esc_attr( $post_video_bg_end_time ); ?>">
	<?php
}

/**
 * Save meta box
 *
 * @param int $post_id The post id.
 */
function mb_video_options_save( $post_id ) {

	// Doing an auto save.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
  // if our nonce isn't there, or we can't verify it, bail.
	if ( isset( $_POST['mb_video_thumbonial'] ) && wp_verify_nonce( $_POST['mb_video_thumbonial'], 'video_thumbonial' ) ) { // Input var OK, sanitization OK.
		if ( isset( $_POST['post_video_location'] ) ) { // Input var OK, sanitization OK.
			$post_video_location = array_map( 'sanitize_text_field', $_POST['post_video_location'] ); // Input var OK, sanitization OK.
			update_post_meta( $post_id, 'post_video_location', $post_video_location );
		} else {
			update_post_meta( $post_id, 'post_video_location', array() );
		}
		if ( isset( $_POST['post_video_url'] ) ) { // Input var OK, sanitization OK.
			$post_video_bg_start_time = esc_url( $_POST['post_video_url'] ); // Input var OK, sanitization OK.
			update_post_meta( $post_id, 'post_video_url', $post_video_bg_start_time );
		}
		if ( isset( $_POST['post_video_bg_start_time'] ) ) { // Input var OK, sanitization OK.
			$post_video_bg_start_time = intval( $_POST['post_video_bg_start_time'] ); // Input var OK, sanitization OK.
			update_post_meta( $post_id, 'post_video_bg_start_time', $post_video_bg_start_time );
		}
		if ( isset( $_POST['post_video_bg_end_time'] ) ) { // Input var OK, sanitization OK.
			$post_video_bg_end_time = intval( $_POST['post_video_bg_end_time'] ); // Input var OK, sanitization OK.
			update_post_meta( $post_id, 'post_video_bg_end_time', $post_video_bg_end_time );
		}
	}
}
add_action( 'save_post', 'mb_video_options_save' );
