<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<input type="text" class="search-field" placeholder="<?php esc_attr_e('Search and hit enter...', 'anymag'); ?>" name="s" />
	<button class="search-button" type="submit"><i class="fa fa-search"></i></button>
</form>