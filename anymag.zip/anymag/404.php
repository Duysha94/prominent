<div class="f-width">
<?php get_header(); ?>

	<div class="container site-content">
		
      <div class="content-area error-page">
        <article class="nothing-found">
	    	  <h2><?php esc_html_e( 'Not Found', 'anymag' ); ?></h2>
					<h1>4<span>0</span>4</h1>
					<p><?php esc_html_e( "It seems we can't find what you're looking for. Perhaps searching can help.", 'anymag' ); ?></p>
					<?php get_search_form(); ?>
	      </article>
	    
	    </div> 

	</div>

<?php get_footer(); ?>
</div>
