<div class="adv-image">
  
  <?php if(get_theme_mod('anymag_adv_link')) : ?>
   <?php if(get_theme_mod('anymag_adv_new')) : ?>  
    <a href="<?php echo esc_html(get_theme_mod('anymag_adv_link')); ?>" target="_blank"> 
    <?php else : ?>   
    <a href="<?php echo esc_html(get_theme_mod('anymag_adv_link')); ?>">  
   <?php endif; ?>
      
  <?php endif; ?>
  
    <img src="<?php echo esc_url(get_theme_mod('anymag_adv_image')); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
  
  <?php if(get_theme_mod('anymag_adv_link')) : ?>
   </a>
  <?php endif; ?> 
</div> 