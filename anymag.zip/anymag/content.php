<?php
$excerpt_cnt = get_theme_mod('anymag_excerpt_lenght', '20');
  if (class_exists('ACF')) {
    $post_bg_color = get_field('anymag_post_bg_color');
    $post_cat_color = get_field('anymag_post_cat_color');
    $post_head_color = get_field('anymag_post_head_color');
    $post_meta_color = get_field('anymag_post_meta_color');
    $post_text_color = get_field('anymag_post_text_color');
    $post_link_color = get_field('anymag_post_link_color');
    $post_link_hover_color = get_field('anymag_post_link_hover_color');
    $post_overlay_opacity = get_field('anymag_post_overlay_opacity');
    $post_footer_bg = get_field('anymag_post_footer_bg_color');
    $post_hide_img = get_field('anymag_post_hide_image');
    $post_descr = get_field('anymag_post_descr');
  }  
?>

<?php if(is_single()) : ?>

<style>
  <?php if ($post_bg_color) :?>
  .magcontent { background-color : <?php echo esc_attr($post_bg_color); ?>; }
  <?php endif; ?>
  <?php if ($post_head_color) :?>
  .entry-title,
  .post-entry h1,
  .post-entry h2,
  .post-entry h3,
  .post-entry h4,
  .post-entry h5, 
  .post-entry h6, 
  .item-related h5 a,
  .thecomment .comment-text h6.author,
  .header-social-links a { color : <?php echo esc_attr($post_head_color); ?>; }
  <?php endif; ?>
  <?php if ($post_cat_color) :?>
  .single-categs .categ a { color : <?php echo esc_attr($post_cat_color); ?>; }
  <?php endif; ?>
  <?php if ($post_text_color) :?>
  p, .thecomment p, li, .post-navigation span, .comment-text .date, .item-related .widget-date ,textarea { color : <?php echo esc_attr($post_text_color); ?>; }
  <?php endif; ?>
  <?php if ($post_link_color) :?>
  a, .post-content a, .thecomment .comment-text h6.author a, .post-comments span.reply a { color : <?php echo esc_attr($post_link_color); ?>; }
  <?php endif; ?>
  <?php if ($post_link_hover_color) :?>
  a:hover, .post-content a:hover, .post-comments span.reply a:hover { color : <?php echo esc_attr($post_link_hover_color); ?>; }
  <?php endif; ?>
  <?php if ($post_meta_color) :?>
  .post-meta li span, .post-entry .post-meta a, .comment-text .date { color : <?php echo esc_attr($post_meta_color); ?>; }
  <?php endif; ?>
  <?php if (get_theme_mod('anymag_single_overlay_opacity') != $post_overlay_opacity) :?>
    <?php if ($post_overlay_opacity != 3 ) :?>
      body.single-post .magcover .overlay, .post-overlay { opacity: .<?php echo esc_attr($post_overlay_opacity); ?>; }
    <?php endif; ?>
  <?php endif; ?>
  <?php if ($post_footer_bg) :?>
  #footer { background: <?php echo esc_attr($post_footer_bg); ?>; }
   <?php endif; ?>
</style>

  <div class="content-area<?php if (get_theme_mod('anymag_single_sidebar') && is_active_sidebar('main-sidebar')) : ?> has-sidebar<?php endif; ?>">
    <div class="post-entry">
      <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>> 
        <?php if(get_theme_mod('anymag_adv_single') == true) : ?>     
          <?php get_template_part('inc/templates/add-area'); ?>
        <?php endif; ?> 
        <?php if(get_theme_mod('anymag_single_categ', true)) : ?>
          <?php if(get_theme_mod('anymag_categ_style', true) == 'cat-boxed') : ?>
            <div class="single-categs-box">
          <?php else : ?>
            <div class="single-categs">
          <?php endif; ?>    
             <span class="categ"><?php the_category(' '); ?></span>
            </div>
        <?php endif; ?>
        <?php if (class_exists('ACF') && get_field('anymag_post_hide_title') == false) { ?>
        <h1 class="entry-title<?php if(get_theme_mod('anymag_title_border', true)) : ?> ttl-border<?php endif; ?>"><?php the_title(); ?></h1>
        <?php } ?> 
        <ul class="post-meta">
        <?php if(get_theme_mod('anymag_single_author', true)) : ?>
          <li class="post-author">
            <?php if(get_theme_mod('anymag_single_avatar', true)) : ?>
            <div class="author-avatar"><?php echo get_avatar( get_the_author_meta( 'ID' ), 30 ); ?></div>
            <?php endif; ?> 
            <span class="author"><?php the_author_posts_link(); ?></span></li>
        <?php endif; ?>
        <?php if(get_theme_mod('anymag_single_date', true)) : ?>
          <li class="single-post-date"><span><span class="date updated published"><?php the_time( get_option('date_format') ); ?></span></span></li>
        <?php endif; ?>
        </ul>
        
        <div class="post-content main-content">
          <?php  the_content(); ?>
        </div> 

        <?php wp_link_pages(array('before' =>'<div class="pagination-post aligncenter">', 'after'  =>'</div>', 'pagelink' => '<span>%</span>')); ?>
        
        <?php if(get_theme_mod('anymag_post_tags', true)) : ?>
          <?php if(has_tag()) : ?>
            <div class="post-tags">
              <?php the_tags("",""); ?>
            </div>
          <?php endif; ?> 
        <?php endif; ?> 

        <?php if(get_theme_mod('anymag_about_author') == true) : ?>
          <?php get_template_part('inc/templates/about-author'); ?>
        <?php endif; ?>


        <?php if(get_theme_mod('anymag_content_share', true)) : ?>
          <?php get_template_part('inc/templates/social-share'); ?>
        <?php endif; ?>
        
        <?php if(get_theme_mod('anymag_content_nav', true)) : ?>
          <?php get_template_part('inc/templates/post-navigation'); ?>
        <?php endif; ?>
        
        <?php if(get_theme_mod('anymag_post_comments', true)) : ?>
          <?php comments_template( '', true );  ?>
        <?php endif; ?>

        <?php if(get_theme_mod('anymag_related_posts')) : ?>
          <?php if(is_single()) : ?>
            <div class="related-posts">
              <?php get_template_part('inc/templates/related-posts'); ?>
            </div>
          <?php endif; ?>
        <?php endif; ?>
        </article>
        </div> 
        <?php if ( get_theme_mod('anymag_single_sidebar') && is_active_sidebar('main-sidebar')) : ?>
          <?php get_sidebar(); ?>
        <?php endif; ?>
     </div>

   
<!-- End Single Post --> 

<?php else : ?>  

<div class="post-item">
  <article id="post-<?php the_ID(); ?>">
   <?php if(has_post_thumbnail()) : ?>

      <div class="image-part <?php if(get_theme_mod('anymag_hover_zoom', true)) : ?>hoverzoom<?php endif; ?>">
        <div class="overlay"></div>
        <?php if(has_post_format('video')) : ?>
          <div class="post-format video-post"><i class="fas fa-video"></i></div>
        <?php elseif(has_post_format('audio')) : ?>
          <div class="post-format audio-post"><i class="fas fa-headphones-alt"></i></div>
        <?php elseif(has_post_format('gallery')) : ?>
          <div class="post-format audio-post"><i class="fas fa-image"></i></div>  
        <?php endif; ?>  
        <a href="<?php echo get_permalink(); ?>">
          <?php if (get_theme_mod('anymag_home_layout') == 'home-wide') : ?> 
            <?php the_post_thumbnail('anymag-post'); ?>  
          <?php else : ?>  
            <?php the_post_thumbnail('anymag-misc'); ?> 
          <?php endif; ?>  
        </a>   
        <?php if(get_theme_mod('anymag_list_categ', true) && get_theme_mod('anymag_categ_style', true) == 'cat-boxed') : ?>
            <div class="post-categs-box">
              <span class="categ"><?php the_category(' '); ?></span>
            </div>
        <?php endif; ?>
      </div>

      <div class="content-part">
        <div class="the-content">
          <?php if(get_theme_mod('anymag_list_categ', true) && get_theme_mod('anymag_categ_style') == 'cat-classic') : ?>
            <div class="post-categs">
              <span class="categ"><?php the_category(' '); ?></span>
            </div>
         <?php endif; ?>
            <?php  if ( is_sticky() && is_home() && ! is_paged() ) {
              printf( '<span class="sticky-post"> <i class="fa fa-star"></i></span>', 'anymag' );
            }?>
            <h3 class="post-title <?php if (get_theme_mod('anymag_hover_style', true) == 'hover-underline'):?>underline<?php endif; ?>">
              <a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a>
            </h3>
            <?php if(get_theme_mod('anymag_show_excerpt', true)) : ?>
              <div class="post-list-entry">
                <p><?php echo anymag_excerpt($excerpt_cnt); ?></p>
              </div>
            <?php endif; ?>
          <?php if(get_theme_mod('anymag_post_author', true) || get_theme_mod('anymag_list_date', true) || get_theme_mod('anymag_list_comments', true)) : ?>
            <ul class="post-meta">
            <?php if(get_theme_mod('anymag_post_author', true)) : ?>
              <?php if(get_theme_mod('anymag_post_avatar')) : ?>
               <div class="author-avatar"><?php echo get_avatar( get_the_author_meta( 'ID' ), 30 ); ?></div>
              <?php endif; ?> 
              <li class="post-author">
                <span class="author"><?php the_author_posts_link(); ?></span>
              </li>
            <?php endif; ?>  
            <?php if(get_theme_mod('anymag_list_date', true)) : ?>
            <li class="list-date">
              <span class="post-date"><?php the_time( get_option('date_format') ); ?></span>
            </li>
            <?php endif; ?> 
            <?php if(get_theme_mod('anymag_list_comments')) : ?>
            <li class="list-comment">
             <?php  if ( comments_open() || get_comments_number() ) {
                comments_number( esc_html__( '0 comments', 'anymag' ), esc_html__( '1 Comment', 'anymag' ), esc_html__( '% Comments', 'anymag' ) );
             } ?>
            </li>
            <?php endif; ?> 
          </ul>
          <?php endif; ?> 
        </div>
      </div>


  <?php else : ?>
      
    <div class="post-container no-image">
      <div class="overlay"></div>
      <?php if(get_theme_mod('anymag_list_categ', true)) : ?>
        <?php if( get_theme_mod('anymag_categ_style', true) == 'cat-boxed') : ?>
          <div class="post-categs-box">
            <span class="categ"><?php the_category(' '); ?></span>
          </div>
          <?php else : ?>
          <div class="post-categs">
            <span class="categ"><?php the_category(' '); ?></span>
          </div>
        <?php endif; ?>
      <?php endif; ?>
      <div class="content-part">
        <div class="post-header">
          <?php  if ( is_sticky() && is_home() && ! is_paged() ) {
           printf( '<span class="sticky-post"> <i class="fa fa-star"></i></span>', 'anymag' );
          }?>
          <h3 class="post-title <?php if (get_theme_mod('anymag_hover_style', true) == 'hover-underline'):?>underline<?php endif; ?>">
            <a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a>
          </h3>
          <?php if(get_theme_mod('anymag_show_excerpt', true)) : ?>
            <div class="post-list-entry">
              <p><?php echo anymag_excerpt($excerpt_cnt); ?></p>
            </div>
          <?php endif; ?>
        </div>
        <ul class="post-meta">
          <?php if(get_theme_mod('anymag_post_author', true)) : ?>
            <?php if(get_theme_mod('anymag_post_avatar')) : ?>
             <div class="author-avatar"><?php echo get_avatar( get_the_author_meta( 'ID' ), 30 ); ?></div>
            <?php endif; ?> 
            <li class="post-author">
              <span class="author"><?php the_author_posts_link(); ?></span>
            </li>
          <?php endif; ?>  
          <?php if(get_theme_mod('anymag_list_date', true)) : ?>
          <li class="list-date">
            <span class="post-date"><?php the_time( get_option('date_format') ); ?></span>
          </li>
          <?php endif; ?> 
          <?php if(get_theme_mod('anymag_list_comments')) : ?>
          <li class="list-comment">
           <?php  if ( comments_open() || get_comments_number() ) {
              comments_number( esc_html__( '0 comments', 'anymag' ), esc_html__( '1 Comment', 'anymag' ), esc_html__( '% Comments', 'anymag' ) );
           } ?>
          </li>
          <?php endif; ?> 
        </ul>
      </div> 
    </div>
  <?php endif; ?>
</article>
</div> 
<?php endif; ?>