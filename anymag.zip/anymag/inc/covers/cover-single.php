<?php
  $page_tag = get_the_tags($post->ID);
  $post_descr = ''; 
  if (class_exists('ACF')) {
    $post_descr = get_field('anymag_post_descr');
  }  
?>

<div class="magcover">
  <?php if(get_theme_mod('anymag_turn_left', true)) : ?><div class="turn-left"></div><?php endif; ?>
  <div class="fold-shadow-left"></div>
    <div class="cover-wrap">
      <div class="cover-content">
        <?php get_template_part('inc/headers/header-post'); ?>
        <?php if ($post_descr): ?>
          <div class="cover-descr">
            <h3>
            <?php echo esc_attr($post_descr) ?>
          </h3>
          </div>
        <?php endif; ?> 
        
        <?php if(get_theme_mod('anymag_cover_share', true)) : ?>
          <?php get_template_part('inc/templates/social-share-cover'); ?>
        <?php endif; ?>   

        <?php if(get_theme_mod('anymag_cover_nav', true)) : ?>
          <?php get_template_part('inc/templates/cover-navigation'); ?>
        <?php endif; ?>

        <div class="overlay"></div>
          <?php 
           $thumbnail1 = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'anymag-post' );
           $thumbnail2 = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'anymag-thumb' );
          ?>
         <div class="video-overlay">
          <div class="cover-image" data-interlace-src="<?php echo esc_url($thumbnail1[0]); ?>" data-interlace-low="<?php echo esc_url($thumbnail2[0]); ?>" data-interlace-alt="<?php echo $post_descr; ?>" data-interlace-low-alt="<?php echo $post_descr; ?>"> 
             <?php get_video_thumbnail('archive'); ?>
         </div> 
        </div>  
  
      </div>
  </div> 
</div>