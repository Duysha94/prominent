<?php get_header(); ?>

  <div class="content-area<?php if (get_theme_mod('anymag_archive_sidebar') && is_active_sidebar('main-sidebar')) : ?> has-sidebar<?php endif; ?>">
  <?php if(get_theme_mod('anymag_adv_archive') == true) : ?>     
    <?php get_template_part('inc/templates/add-area'); ?>
  <?php endif; ?> 
	
	<div class="category-box">
		<h1>
      <?php
        if ( is_day() ) :
      		printf( esc_html__( '%s', 'anymag' ), get_the_date() );
      	elseif ( is_month() ) :
      		printf( esc_html__( '%s', 'anymag' ), get_the_date( _x( 'F Y', 'monthly archives date format', 'anymag' ) ) );
      	elseif ( is_year() ) :
      		printf( esc_html__( '%s', 'anymag' ), get_the_date( _x( 'Y', 'yearly archives date format', 'anymag' ) ) );
        elseif ( is_tag() ) :
              printf( esc_html__( '%s', 'anymag' ), single_tag_title( '', false ) );
        else :
      		esc_html_e( 'Archives', 'anymag' );
      	endif;
     ?> 
		</h1>	
	</div>
	<div class="posts-area">
    <?php 
      if (get_theme_mod('anymag_categ_layout') == 'categ-list') { $postclass="post-list"; }
      elseif (get_theme_mod('anymag_categ_layout') == 'categ-wide') { $postclass="post-wide"; }
      else { $postclass="two-fr"; }
    ?>

      <div class="blog-posts <?php echo esc_html($postclass) ?>">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
          <?php get_template_part('content'); ?>
        <?php endwhile; ?>
      </div>
      <div class="page-nav">
        <?php anymag_pagination_type(); ?>
      </div>
  </div> 
  <?php if ( get_theme_mod('anymag_archive_sidebar') && is_active_sidebar('main-sidebar')) : ?>
    <?php get_sidebar(); ?>
  <?php endif; ?>
  
  <?php else : ?>
    <?php get_template_part('content', 'none'); ?>
  <?php endif; ?>
</div>

<?php get_footer(); ?>