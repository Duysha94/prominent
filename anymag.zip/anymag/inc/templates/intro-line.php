<?php 
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
if( $paged == 1 ) : ?>
<div class="intro-line">
	<h1>
    <?php 
    $anymag_allow_html = array(
	    'br' => array(),
	    'em' => array(),
	    'strong' => array(),
	    'b' => array(),
	    'i' => array(),
    );
    echo wp_kses(get_theme_mod('anymag_intro_line'), $anymag_allow_html); ?>
  </h1>
</div>
<?php endif; // #if paged
?>