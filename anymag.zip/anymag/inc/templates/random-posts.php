<?php 
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
if( $paged == 1 ) :
  
  global $post;
	$orig_post = $post;

	  $postnum = get_theme_mod('anymag_random_num', '3');
	  
	  $postnum ++;

		$args = array(
			'post__not_in'     => array($post->ID),
			'posts_per_page'   => $postnum, // Number of random posts that will be shown.
			'ignore_sticky_posts' => 1,
			'orderby' => 'rand'
		);

		$my_query = new wp_query( $args );
		if( $my_query->have_posts() ) { ?>
    <div class="random-posts <?php if(get_theme_mod('anymag_random_style') == 'overlayed') : ?> overlayed<?php endif; ?>">
			<?php if (get_theme_mod('anymag_random_header')) : ?> 
				<div class="section-title <?php if (get_theme_mod('anymag_side_pattern', true)) : ?>side-pattern<?php endif; ?>">
					<h2><?php 
          $anymag_allow_html = array('i' => array());
					echo wp_kses(get_theme_mod('anymag_random_header'), $anymag_allow_html); ?></h2>
				</div>
			<?php endif; ?> 

			<div class="random-items three-fr">
			<?php while( $my_query->have_posts() ) {
				$my_query->the_post();?>
					<div class="item-random">
						<?php if ( (function_exists('has_post_thumbnail')) && (has_post_thumbnail()) ) : ?>
	          <div class="random-image">
	          	<div class="overlay"></div>
						  <a href="<?php echo get_permalink() ?>"><?php the_post_thumbnail('anymag-misc'); ?></a>
						</div>
						<?php endif; ?>
						<div class="random-ttl">
							<h5><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h5>
							<?php if (get_theme_mod('anymag_random_date', true)):?>
						  	<span class="widget-date"><?php the_time( get_option('date_format') ); ?></span>
						  <?php endif; ?>	
						</div>
					</div>
			<?php
			}?>
			</div>
    </div>
		<?php 
	  }

	$post = $orig_post;
	wp_reset_postdata();
endif; // #if paged
?>