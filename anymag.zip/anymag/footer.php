 </div><!-- End Main Area -->

  <?php if (class_exists('ACF') && get_field('anymag_post_hide_footer') == false) { ?>   

    <?php if ( function_exists( 'elementor_theme_do_location' ) && elementor_theme_do_location( 'footer' ) ) : ?>
        <div class="footer-wrapper">
          <footer id="main-footer" class="main-footer">
            <?php elementor_theme_do_location( 'footer' ) ?>
          </footer>
        </div>
      <?php else : ?>
      <?php get_template_part('inc/templates/footer-content'); ?>
    <?php endif ?>

  <?php } ?>  

  </div><!-- End Mag Content -->
</div><!-- End Site Wrapper -->
  <?php wp_footer(); ?>
  </body>
</html>
