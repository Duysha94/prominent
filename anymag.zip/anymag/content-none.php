<article class="nothing-found">
					
	<h2><?php esc_html_e( 'Nothing Found', 'anymag' ); ?></h2>

		<?php if ( is_search() ) : ?>

			<p><?php esc_html_e( 'Sorry, but no results were found for the requested archive. Try using the search with a relevant phrase to find the post you are looking for.', 'anymag' ); ?></p>
			<?php get_search_form(); ?>

		<?php else : ?>

			<p><?php esc_html_e( 'Sorry, it seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'anymag' ); ?></p>
			<?php get_search_form(); ?>

		<?php endif; ?>
		
</article>