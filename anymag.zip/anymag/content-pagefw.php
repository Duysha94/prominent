<?php
  if (class_exists('ACF')) {
    $page_bg_color = get_field('anymag_page_bg_color');
    $page_head_color = get_field('anymag_page_head_color');
    $page_text_color = get_field('anymag_page_text_color');
    $page_link_color = get_field('anymag_page_link_color');
    $page_link_hover_color = get_field('anymag_page_link_hover_color');
    $page_overlay_opacity = get_field('anymag_page_overlay_opacity');
    $page_footer_bg = get_field('anymag_page_footer_bg_color');
    $page_hide_img = get_field('anymag_page_hide_image');
  }  
?>

<style>
  <?php if ($page_bg_color) :?>
  .magcontent { background-color : <?php echo esc_attr($page_bg_color); ?>; }
  <?php endif; ?>
  <?php if ($page_head_color) :?>
  .entry-title,
  .post-entry h1,
  .post-entry h2,
  .post-entry h3,
  .post-entry h4,
  .post-entry h5, 
  .post-entry h6, 
  .header-social-links a { color : <?php echo esc_attr($post_head_color); ?>; }
  <?php endif; ?>
  <?php if ($page_text_color) :?>
  p, .thecomment p, li, .post-navigation span, .comment-text .date, textarea { color : <?php echo esc_attr($page_text_color); ?>; }
  <?php endif; ?>
  <?php if ($page_link_color) :?>
  a, .post-content a, .thecomment .comment-text h6.author a { color : <?php echo esc_attr($page_link_color); ?>; }
  <?php endif; ?>
  <?php if ($page_link_hover_color) :?>
  a:hover, .post-content a:hover { color : <?php echo esc_attr($page_link_hover_color); ?>; }
  <?php endif; ?>
  <?php if ($page_overlay_opacity) :?>
  .overlay, .post-overlay { opacity: .<?php echo esc_attr($page_overlay_opacity); ?>; }
  <?php endif; ?>
  <?php if ($page_footer_bg) :?>
  #footer { background: <?php echo esc_attr($page_footer_bg); ?>; }
  <?php endif; ?>
</style>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

  <div class="content-area<?php if (get_theme_mod('anymag_home_sidebar') && is_active_sidebar('main-sidebar')) : ?> has-sidebar<?php endif; ?>">
    <div class="post-entry">
    <?php if(get_theme_mod('anymag_adv_pages') == true) : ?>     
      <?php get_template_part('inc/templates/add-area'); ?>
    <?php endif; ?> 

    <?php if(has_post_thumbnail()) : ?>
       <div class="single-post-image <?php if($page_hide_img){echo 'hide';}?>">
        <?php the_post_thumbnail('anymag-post'); ?>
      </div> 
    <?php endif; ?>

      <?php if (class_exists('ACF') && get_field('anymag_page_hide_title') == false) { ?>
        <h1 class="entry-title<?php if(get_theme_mod('anymag_title_border', true)) : ?> ttl-border<?php endif; ?>"><?php the_title(); ?>
        </h1>
      <?php } ?>   

        <div class="post-content">
          <?php  the_content(); ?>
          <?php wp_link_pages(array('before' =>'<div class="pagination-post aligncenter">', 'after'  =>'</div>', 'pagelink' => '<span>%</span>')); ?>
        </div> 

        <?php 
         if(get_theme_mod('anymag_page_share')) {
          get_template_part('inc/templates/social-share'); 
         } 
        ?>

        <?php if(get_theme_mod('anymag_post_comments', true)) : ?>
          <?php comments_template( '', true );  ?>
        <?php endif; ?>
    </div>
    <?php if ( get_theme_mod('anymag_page_sidebar') && is_active_sidebar('main-sidebar')) : ?>
      <?php get_sidebar(); ?>
    <?php endif; ?>
  </div>
   
</article>

