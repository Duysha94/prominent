<?php

if(empty($google_fonts)){
  $google_fonts = array('ABeeZee','Abel','Abhaya Libre','Aboreto','Abril Fatface','Aclonica','Acme','Actor','Adamina','Advent Pro','Aguafina Script','Akaya Kanadaka','Akaya Telivigala','Akronim','Akshar','Aladin','Alata','Alatsi','Albert Sans','Aldrich','Alef','Alegreya Sans SC','Alegreya Sans','Alegreya SC','Alegreya','Aleo','Alex Brush','Alfa Slab One','Alice','Alike Angular','Alike','Allan','Allerta Stencil','Allerta','Allison','Allura','Almarai','Almendra Display','Almendra SC','Almendra','Alumni Sans','Alumni Sans Inline One','Alumni Sans Pinstripe','Amarante','Amaranth','Amatic SC','Amethysta','Amiko','Amiri','Amiri Quran','Amita','Anaheim','Andada Pro','Andika New Basic','Andika','Anek Latin','Angkor','Annie Use Your Telescope','Anonymous Pro','Antic Didone','Antic Slab','Antic','Anton','Antonio','Anybody','Arapey','Arbutus Slab','Arbutus','Architects Daughter','Archivo Black','Archivo Narrow','Archivo','Are You Serious','Aref Ruqaa','Aref Ruqaa Ink','Arima Madurai','Arima','Arimo','Arizonia','Armata','Arsenal','Artifika','Arvo','Arya','Asap Condensed','Asap','Asar','Asset','Assistant','Astloch','Asul','Athiti','Atkinson Hyperlegible','Atma','Atomic Age','Aubrey','Audiowide','Autour One','Average Sans','Average','Averia Gruesa Libre','Averia Libre','Averia Sans Libre','Averia Serif Libre','Azeret Mono','B612 Mono','B612','Babylonica','Bad Script','Bahiana','Bahianita','Bai Jamjuree','Bakbak One','Ballet','Baloo 2','Baloo Bhai 2','Baloo Bhaijaan 2','Baloo Bhaina 2','Baloo Chettan 2','Baloo Da 2','Baloo Paaji 2','Baloo Tamma 2','Baloo Tammudu 2','Baloo Thambi 2','Balsamiq Sans','Balthazar','Bangers','Barlow Condensed','Barlow Semi Condensed','Barlow','Barriecito','Barrio','Basic','Baskervville','Battambang','Baumans','Bayon','Be Vietnam Pro','Bebas Neue','Belgrano','Bellefair','Belleza','Bellota Text','Bellota','BenchNine','Benne','Bentham','Berkshire Swash','Besley','Beth Ellen','Bevan','Big Shoulders Display','Big Shoulders Inline Display','Big Shoulders Inline Text','Big Shoulders Stencil Display','Big Shoulders Stencil Text','Big Shoulders Text','Bigelow Rules','Bigshot One','Bilbo Swash Caps','Bilbo','BioRhyme Expanded','BioRhyme','Birthstone Bounce','Birthstone','Biryani','Bitter','BIZ UDPMincho','BIZ UDPGothic','BIZ UDMincho','BIZ UDGothic','Black And White Picture','Black Han Sans','Black Ops One','Blaka','Blaka Ink','Blinker','Bodoni Moda','Bokor','Bona Nova','Bonbon','Bonheur Royale','Boogaloo','Bowlby One SC','Bowlby One','Brawler','Bree Serif','Brygada 1918','Bubblegum Sans','Bubbler One','Buda','Buenard','Bungee','Bungee Hairline','Bungee Inline','Bungee Outline','Bungee Shade','Bungee Spice','Butcherman','Butterfly Kids','Cabin Condensed','Cabin Sketch','Cabin','Caesar Dressing','Cagliostro','Cairo','Cairo Play','Caladea','Calistoga','Calligraffitti','Cambay','Cambo','Candal','Cantarell','Cantata One','Cantora One','Capriola','Caramel','Carattere','Cardo','Carme','Carrois Gothic SC','Carrois Gothic','Carter One','Castoro','Catamaran','Caudex','Caveat Brush','Caveat','Cedarville Cursive','Ceviche One','Chakra Petch','Changa One','Changa','Chango','Charm','Charmonman','Chathura','Chau Philomene One','Chela One','Chelsea Market','Chenla','Cherish','Cherry Cream Soda','Cherry Swash','Chewy','Chicle','Chilanka','Chivo','Chonburi','Cinzel Decorative','Cinzel','Clicker Script','Coda Caption','Coda','Codystar','Coiny','Combo','Comfortaa','Comforter Brush','Comforter','Comic Neue','Coming Soon','Commissioner','Concert One','Condiment','Content','Contrail One','Convergence','Cookie','Copse','Corben','Corinthia','Cormorant Garamond','Cormorant Infant','Cormorant SC','Cormorant Unicase','Cormorant Upright','Cormorant','Courgette','Courier Prime','Cousine','Coustard','Covered By Your Grace','Crafty Girls','Creepster','Crete Round','Crimson Pro','Croissant One','Crushed','Cuprum','Cute Font','Cutive Mono','Cutive','Damion','Dancing Script','Dangrek','Darker Grotesque','David Libre','Dawning of a New Day','Days One','Dekko','Dela Gothic One','Delius Swash Caps','Delius Unicase','Delius','Della Respira','Denk One','Devonshire','Dhurjati','Didact Gothic','Diplomata SC','Diplomata','DM Mono','DM Sans','DM Serif Display','DM Serif Text','Do Hyeon','Dokdo','Domine','Donegal One','Dongle','Doppio One','Dorsa','Dosis','DotGothic16','Dr Sugiyama','Duru Sans','Dynalight','DynaPuff','Eagle Lake','East Sea Dokdo','Eater','EB Garamond','Economica','Eczar','Edu QLD Beginner','El Messiri','Electrolize','Elsie Swash Caps','Elsie','Emblema One','Emilys Candy','Encode Sans Condensed','Encode Sans Expanded','Encode Sans SC','Encode Sans Semi Condensed','Encode Sans Semi Expanded','Encode Sans','Engagement','Englebert','Enriqueta','Ephesis','Epilogue','Erica One','Esteban','Estonia','Euphoria Script','Ewert','Exo 2','Exo','Expletus Sans','Explora','Fahkwang','Familjen Grotesk','Fanwood Text','Farro','Farsan','Fascinate Inline','Fascinate','Faster One','Fasthand','Fauna One','Faustina','Federant','Federo','Felipa','Fenix','Festive','Figtree','Finger Paint','Finlandica','Fira Code','Fira Mono','Fira Sans Condensed','Fira Sans Extra Condensed','Fira Sans','Fjalla One','Fjord One','Flamenco','Flavors','Fleur De Leah','Flow Block','Flow Circular','Flow Rounded','Fondamento','Fontdiner Swanky','Forum','Francois One','Frank Ruhl Libre','Fraunces','Freckle Face','Fredericka the Great','Fredoka','Fredoka One','Freehand','Fresca','Frijole','Fruktur','Fugaz One','Fuggles','Fuzzy Bubbles','Gabriela','Gaegu','Gafata','Galada','Galdeano','Galindo','Gamja Flower','Gayathri','Gelasio','Gemunu Libre','Genos','Gentium Basic','Gentium Book Basic','Gentium Plus','Geo','Georama','Geostar Fill','Geostar','Germania One','GFS Didot','GFS Neohellenic','Gideon Roman','Gidugu','Gilda Display','Girassol','Give You Glory','Glass Antiqua','Glegoo','Gloria Hallelujah','Glory','Gluten','Goblin One','Gochi Hand','Goldman','Gorditas','Gothic A1','Gotu','Goudy Bookletter 1911','Gowun Batang','Gowun Dodum','Graduate','Grand Hotel','Grandstander','Grape Nuts','Gravitas One','Great Vibes','Grechen Fuemen','Grenze Gotisch','Grenze','Grey Qo','Griffy','Gruppo','Gudea','Gugi','Gupter','Gurajada','Gwendolyn','Habibi','Hachi Maru Pop','Hahmlet','Halant','Hammersmith One','Hanalei Fill','Hanalei','Handlee','Hanuman','Happy Monkey','Harmattan','Headland One','Heebo','Henny Penny','Hepta Slab','Herr Von Muellerhoff','Hi Melody','Hina Mincho','Hind Guntur','Hind Madurai','Hind Siliguri','Hind Vadodara','Hind','Holtwood One SC','Homemade Apple','Homenaje','Hubballi','Hurricane','Ibarra Real Nova','IBM Plex Mono','IBM Plex Sans Arabic','IBM Plex Sans Condensed','IBM Plex Sans Devanagari','IBM Plex Sans Hebrew','IBM Plex Sans KR','IBM Plex Sans Thai Looped','IBM Plex Sans Thai','IBM Plex Sans','IBM Plex Serif','Iceberg','Iceland','IM Fell Double Pica SC','IM Fell Double Pica','IM Fell DW Pica SC','IM Fell DW Pica','IM Fell English SC','IM Fell English','IM Fell French Canon SC','IM Fell French Canon','IM Fell Great Primer SC','IM Fell Great Primer','Imbue','Imperial Script','Imprima','Inconsolata','Inder','Indie Flower','Ingrid Darling','Inika','Inknut Antiqua','Inria Sans','Inria Serif','Inspiration','Inter','Irish Grover','Island Moments','Istok Web','Italiana','Italianno','Itim','Jacques Francois Shadow','Jacques Francois','Jaldi','JetBrains Mono','Jim Nightshade','Joan','Jockey One','Jolly Lodger','Jomhuria','Jomolhari','Josefin Sans','Josefin Slab','Jost','Joti One','Jua','Judson','Julee','Julius Sans One','Junge','Jura','Just Another Hand','Just Me Again Down Here','K2D','Kadwa','Kaisei Decol','Kaisei HarunoUmi','Kaisei Opti','Kaisei Tokumin','Kalam','Kameron','Kanit','Kantumruy Pro','Kantumruy','Karantina','Karla','Karma','Katibeh','Kaushan Script','Kavivanar','Kavoon','Kdam Thmor','Kdam Thmor Pro','Keania One','Kelly Slab','Kenia','Khand','Khmer','Khula','Kings','Kirang Haerang','Kite One','Kiwi Maru','Klee One','Knewave','Kodchasan','Koh Santepheap','KoHo','Kolker Brush','Kosugi Maru','Kosugi','Kotta One','Koulen','Kranky','Kreon','Kristi','Krona One','Krub','Kufam','Kulim Park','Kumar One Outline','Kumar One','Kumbh Sans','Kurale','La Belle Aurore','Lacquer','Laila','Lakki Reddy','Lalezar','Lancelot','Langar','Lateef','Lato','Lavishly Yours','League Gothic','League Script','League Spartan','Leckerli One','Ledger','Lekton','Lemon','Lemonada','Lexend Deca','Lexend Exa','Lexend Giga','Lexend Mega','Lexend Peta','Lexend Tera','Lexend Zetta','Lexend','Libre Barcode 128 Text','Libre Barcode 128','Libre Barcode 39 Extended Text','Libre Barcode 39 Extended','Libre Barcode 39 Text','Libre Barcode 39','Libre Barcode EAN13 Text','Libre Baskerville','Libre Bodoni','Libre Caslon Display','Libre Caslon Text','Libre Franklin','Licorice','Life Savers','Lilita One','Lily Script One','Limelight','Linden Hill','Literata','Liu Jian Mao Cao','Livvic','Lobster Two','Lobster','Londrina Outline','Londrina Shadow','Londrina Sketch','Londrina Solid','Long Cang','Lora','Love Light','Love Ya Like A Sister','Loved by the King','Lovers Quarrel','Luckiest Guy','Lusitana','Lustria','Luxurious Roman','Luxurious Script','M PLUS 1 Code','M PLUS 1','M PLUS 1p','M PLUS 2','M PLUS Code Latin','M PLUS Rounded 1c','Ma Shan Zheng','Macondo Swash Caps','Macondo','Mada','Magra','Maiden Orange','Maitree','Major Mono Display','Mako','Mali','Mallanna','Mandali','Manjari','Manrope','Mansalva','Manuale','Marcellus SC','Marcellus','Marck Script','Margarine','Markazi Text','Marko One','Marmelad','Martel Sans','Martel','Marvel','Mate SC','Mate','Maven Pro','McLaren','Mea Culpa','Meddon','MedievalSharp','Medula One','Meera Inimai','Megrim','Meie Script','Meow Script','Merienda One','Merienda','Merriweather Sans','Merriweather','Metal Mania','Metal','Metamorphous','Metrophobic','Michroma','Milonga','Miltonian Tattoo','Miltonian','Mina','Miniver','Miriam Libre','Mirza','Miss Fajardose','Mitr','Mochiy Pop One','Mochiy Pop P One','Modak','Modern Antiqua','Mogra','Mohave','Molengo','Molle','Monda','Monofett','Monoton','Monsieur La Doulaise','Montaga','Montagu Slab','MonteCarlo','Montez','Montserrat Alternates','Montserrat Subrayada','Montserrat','Moo Lah Lah','Moon Dance','Moul','Moulpali','Mountains of Christmas','Mouse Memoirs','Mr Bedfort','Mr Dafoe','Mr De Haviland','Mrs Saint Delafield','Mrs Sheppards','Ms Madi','Mukta Mahee','Mukta Malar','Mukta Vaani','Mukta','Mulish','Murecho','MuseoModerno','Mystery Quest','Nabla','Nanum Brush Script','Nanum Gothic Coding','Nanum Gothic','Nanum Myeongjo','Nanum Pen Script','Nerko One','Neucha','Neuton','New Rocker','New Tegomin','News Cycle','Newsreader','Niconne','Niramit','Nixie One','Nobile','Nokora','Norican','Nosifer','Notable','Nothing You Could Do','Noticia Text','Noto Kufi Arabic','Noto Music','Noto Naskh Arabic','Noto Nastaliq Urdu','Noto Rashi Hebrew','Noto Sans Adlam Unjoined','Noto Sans Adlam','Noto Sans Anatolian Hieroglyphs','Noto Sans Arabic','Noto Sans Armenian','Noto Sans Avestan','Noto Sans Balinese','Noto Sans Bamum','Noto Sans Bassa Vah','Noto Sans Batak','Noto Sans Bengali','Noto Sans Bhaiksuki','Noto Sans Brahmi','Noto Sans Buginese','Noto Sans Buhid','Noto Sans Canadian Aboriginal','Noto Sans Carian','Noto Sans Caucasian Albanian','Noto Sans Chakma','Noto Sans Cham','Noto Sans Cherokee','Noto Sans Coptic','Noto Sans Cuneiform','Noto Sans Cypriot','Noto Sans Deseret','Noto Sans Devanagari','Noto Sans Display','Noto Sans Duployan','Noto Sans Egyptian Hieroglyphs','Noto Sans Elbasan','Noto Sans Elymaic','Noto Sans Georgian','Noto Sans Glagolitic','Noto Sans Gothic','Noto Sans Grantha','Noto Sans Gujarati','Noto Sans Gunjala Gondi','Noto Sans Gurmukhi','Noto Sans Hanifi Rohingya','Noto Sans Hanunoo','Noto Sans Hatran','Noto Sans Hebrew','Noto Sans HK','Noto Sans Imperial Aramaic','Noto Sans Indic Siyaq Numbers','Noto Sans Inscriptional Pahlavi','Noto Sans Inscriptional Parthian','Noto Sans Javanese','Noto Sans JP','Noto Sans Kaithi','Noto Sans Kannada','Noto Sans Kayah Li','Noto Sans Kharoshthi','Noto Sans Khmer','Noto Sans Khojki','Noto Sans Khudawadi','Noto Sans KR','Noto Sans Lao','Noto Sans Lepcha','Noto Sans Limbu','Noto Sans Linear A','Noto Sans Linear B','Noto Sans Lisu','Noto Sans Lycian','Noto Sans Lydian','Noto Sans Mahajani','Noto Sans Malayalam','Noto Sans Mandaic','Noto Sans Manichaean','Noto Sans Marchen','Noto Sans Masaram Gondi','Noto Sans Math','Noto Sans Mayan Numerals','Noto Sans Medefaidrin','Noto Sans Meetei Mayek','Noto Sans Meroitic','Noto Sans Miao','Noto Sans Modi','Noto Sans Mongolian','Noto Sans Mono','Noto Sans Mro','Noto Sans Multani','Noto Sans Myanmar','Noto Sans N Ko','Noto Sans Nabataean','Noto Sans New Tai Lue','Noto Sans Newa','Noto Sans Nushu','Noto Sans Ogham','Noto Sans Ol Chiki','Noto Sans Old Hungarian','Noto Sans Old Italic','Noto Sans Old North Arabian','Noto Sans Old Permic','Noto Sans Old Persian','Noto Sans Old Sogdian','Noto Sans Old South Arabian','Noto Sans Old Turkic','Noto Sans Oriya','Noto Sans Osage','Noto Sans Osmanya','Noto Sans Pahawh Hmong','Noto Sans Palmyrene','Noto Sans Pau Cin Hau','Noto Sans Phags Pa','Noto Sans Phoenician','Noto Sans Psalter Pahlavi','Noto Sans Rejang','Noto Sans Runic','Noto Sans Samaritan','Noto Sans Saurashtra','Noto Sans SC','Noto Sans Sharada','Noto Sans Shavian','Noto Sans Siddham','Noto Sans Sinhala','Noto Sans Sogdian','Noto Sans Sora Sompeng','Noto Sans Soyombo','Noto Sans Sundanese','Noto Sans Syloti Nagri','Noto Sans Symbols 2','Noto Sans Symbols','Noto Sans Syriac','Noto Sans Tagalog','Noto Sans Tagbanwa','Noto Sans Tai Le','Noto Sans Tai Tham','Noto Sans Tai Viet','Noto Sans Takri','Noto Sans Tamil Supplement','Noto Sans Tamil','Noto Sans TC','Noto Sans Telugu','Noto Sans Thaana','Noto Sans Thai Looped','Noto Sans Thai','Noto Sans Tifinagh','Noto Sans Tirhuta','Noto Sans Ugaritic','Noto Sans Vai','Noto Sans Wancho','Noto Sans Warang Citi','Noto Sans Yi','Noto Sans Zanabazar Square','Noto Sans','Noto Serif Ahom','Noto Serif Armenian','Noto Serif Balinese','Noto Serif Bengali','Noto Serif Devanagari','Noto Serif Display','Noto Serif Dogra','Noto Serif Ethiopic','Noto Serif Georgian','Noto Serif Grantha','Noto Serif Gujarati','Noto Serif Gurmukhi','Noto Serif Hebrew','Noto Serif Hong Kong','Noto Serif JP','Noto Serif Kannada','Noto Serif Khmer','Noto Serif KR','Noto Serif Lao','Noto Serif Malayalam','Noto Serif Myanmar','Noto Serif Nyiakeng Puachue Hmong','Noto Serif SC','Noto Serif Sinhala','Noto Serif Tamil','Noto Serif Tangut','Noto Serif TC','Noto Serif Telugu','Noto Serif Thai','Noto Serif Tibetan','Noto Serif Yezidi','Noto Serif','Noto Traditional Nushu','Nova Cut','Nova Flat','Nova Mono','Nova Oval','Nova Round','Nova Script','Nova Slim','Nova Square','NTR','Numans','Nunito Sans','Nunito','Nuosu SIL','Odibee Sans','Odor Mean Chey','Offside','Oi','Old Standard TT','Oldenburg','Ole','Oleo Script Swash Caps','Oleo Script','Oooh Baby','Open Sans Condensed','Open Sans','Oranienbaum','Orbitron','Oregano','Orelega One','Orienta','Original Surfer','Oswald','Otomanopee One','Outfit','Over the Rainbow','Overlock SC','Overlock','Overpass Mono','Overpass','Ovo','Oxanium','Oxygen Mono','Oxygen','Pacifico','Padauk','Palanquin Dark','Palanquin','Palette Mosaic','Pangolin','Paprika','Parisienne','Passero One','Passion One','Passions Conflict','Pathway Gothic One','Patrick Hand SC','Patrick Hand','Pattaya','Patua One','Pavanam','Paytone One','Peddana','Peralta','Permanent Marker','Petemoss','Petit Formal Script','Petrona','Philosopher','Piazzolla','Piedra','Pinyon Script','Pirata One','Plaster','Play','Playball','Playfair Display SC','Playfair Display','Plus Jakarta Sans','Podkova','Poiret One','Poller One','Poly','Pompiere','Pontano Sans','Poor Story','Poppins','Port Lligat Sans','Port Lligat Slab','Potta One','Pragati Narrow','Praise','Prata','Preahvihear','Press Start 2P','Pridi','Princess Sofia','Prociono','Prompt','Prosto One','Proza Libre','PT Mono','PT Sans Caption','PT Sans Narrow','PT Sans','PT Serif Caption','PT Serif','Public Sans','Puppies Play','Puritan','Purple Purse','Pushster','Qahiri','Quando','Quantico','Quattrocento Sans','Quattrocento','Questrial','Quicksand','Quintessential','Qwigley','Qwitcher Grypen','Racing Sans One','Radley','Radio Canada','Rajdhani','Rakkas','Raleway Dots','Raleway','Ramabhadra','Ramaraja','Rambla','Rammetto One','Rampart One','Ranchers','Rancho','Ranga','Rasa','Rationale','Ravi Prakash','Readex Pro','Recursive','Red Hat Display','Red Hat Mono','Red Hat Text','Red Rose','Redacted Script','Redacted','Redressed','Reem Kufi','Reenie Beanie','Reggae One','Revalia','Rhodium Libre','Ribeye Marrow','Ribeye','Righteous','Risque','Road Rage','Roboto Condensed','Roboto Flex','Roboto Mono','Roboto Slab','Roboto','Rochester','Rock 3D','Rock Salt','RocknRoll One','Rokkitt','Romanesco','Ropa Sans','Rosario','Rosarivo','Rouge Script','Rowdies','Rozha One','Rubik','Rubik Beastly','Rubik Burned','Rubik Dirt','Rubik Distressed','Rubik Iso','Rubik Marker Hatch','Rubik Maze','Rubik Mono One','Ruda','Rufina','Ruge Boogie','Ruluko','Rum Raisin','Ruslan Display','Russo One','Ruthie','Rye','Sacramento','Sahitya','Sail','Saira Condensed','Saira Extra Condensed','Saira Semi Condensed','Saira Stencil One','Saira','Salsa','Sanchez','Sancreek','Sansita Swashed','Sansita','Sarabun','Sarala','Sarina','Sarpanch','Sassy Frass','Satisfy','Sawarabi Gothic','Sawarabi Mincho','Scada','Scheherazade New','Schoolbell','Scope One','Seaweed Script','Secular One','Sedgwick Ave Display','Sedgwick Ave','Sen','Send Flowers','Sevillana','Seymour One','Shadows Into Light Two','Shadows Into Light','Shalimar','Shanti','Share Tech Mono','Share Tech','Share','Shippori Antique B1','Shippori Antique','Shippori Mincho B1','Shippori Mincho','Shizuru','Shojumaru','Short Stack','Shrikhand','Siemreap','Sigmar One','Signika Negative','Signika','Silkscreen','Simonetta','Single Day','Sintony','Sirin Stencil','Six Caps','Skranji','Slabo 13px','Slabo 27px','Slackey','Smokum','Smooch','Smooch Sans','Smythe','Sniglet','Snippet','Snowburst One','Sofadi One','Sofia','Solway','Song Myung','Sonsie One','Sora','Sorts Mill Goudy','Source Code Pro','Source Sans 3','Source Sans Pro','Source Serif 4','Source Serif Pro','Space Grotesk','Space Mono','Spartan','Special Elite','Spectral SC','Spectral','Spicy Rice','Spinnaker','Spirax','Spline Sans','Spline Sans Mono','Squada One','Square Peg','Sree Krushnadevaraya','Sriracha','Srisakdi','Staatliches','Stalemate','Stalinist One','Stardos Stencil','Stick No Bills','Stick','Stint Ultra Condensed','Stint Ultra Expanded','STIX Two Text','Stoke','Strait','Style Script','Stylish','Sue Ellen Francisco','Suez One','Sulphur Point','Sumana','Sunflower','Sunshiney','Supermercado One','Sura','Suranna','Suravaram','Suwannaphum','Swanky and Moo Moo','Syncopate','Syne Mono','Syne Tactile','Syne','Tajawal','Tangerine','Taprom','Tauri','Taviraj','Teko','Telex','Tenali Ramakrishna','Tenor Sans','Text Me One','Texturina','Thasadith','The Girl Next Door','The Nautigal','Tienne','Tillana','Timmana','Tinos','Titan One','Titillium Web','Tomorrow','Tourney','Trade Winds','Train One','Trirong','Trispace','Trocchi','Trochut','Truculenta','Trykker','Tulpen One','Turret Road','Twinkle Star','Ubuntu Condensed','Ubuntu Mono','Ubuntu','Uchen','Ultra','Uncial Antiqua','Underdog','Unica One','UnifrakturCook','UnifrakturMaguntia','Unkempt','Unlock','Unna','Updock','Urbanist','Vampiro One','Varela Round','Varela','Varta','Vast Shadow','Vazirmatn','Vesper Libre','Viaoda Libre','Vibes','Vibur','Vidaloka','Viga','Voces','Volkhov','Vollkorn SC','Vollkorn','Voltaire','VT323','Vujahday Script','Waiting for the Sunrise','Wallpoet','Walter Turncoat','Warnes','Waterfall','Water Brush','Wellfleet','Wendy One','WindSong','Wire One','Whisper','Work Sans','Xanh Mono','Yaldevi','Yanone Kaffeesatz','Yantramanav','Yatra One','Yellowtail','Yeon Sung','Yeseva One','Yesteryear','Yomogi','Yrsa','Yuji Boku','Yuji Hentaigana Akari','Yuji Hentaigana Akebono','Yuji Mai','Yuji Syuku','Yusei Magic','ZCOOL KuaiLe','ZCOOL QingKe HuangYou','ZCOOL XiaoWei','Zen Antique Soft','Zen Antique','Zen Dots','Zen Kaku Gothic Antique','Zen Kaku Gothic New','Zen Kurenaido','Zen Loop','Zen Maru Gothic','Zen Old Mincho','Zen Tokyo Zoo','Zeyada','Zhi Mang Xing','Zilla Slab Highlight','Zilla Slab');
}

function anymag_all_posts(){
  $args = array(
    'post_status' => 'publish',
    'post_type' => 'post',
    'posts_per_page' => -1,
    'orderby'   => 'date'
  );
  $the_query = new WP_Query( $args );
  $array_of_post = array();
  if($the_query->have_posts()){
    while ($the_query->have_posts()) {
      $the_query->the_post();
      $array_of_post[get_the_ID()] = get_the_title();
    }
  }
  wp_reset_postdata();
  return $array_of_post;
}


if (!class_exists('anymag_Customize')) {
  class anymag_Customize {
    public $customizers = array();
    public $panels = array();

    public function init() {
      $this->anymag_customizer();
      add_action('customize_controls_enqueue_scripts', array($this, 'anymag_customizer_script'));
      add_action('customize_register', array($this, 'anymag_register_customizer'));
    }

    public static function &getInstance() {
      static $instance;
        if (!isset($instance)) {
          $instance = new anymag_Customize();
        }
        return $instance;
    }

    protected function anymag_customizer() {

        global $google_fonts;
  
  $font_faces = array( 
    'Arial' => 'Arial',
    'Georgia, sans-serif' => 'Georgia',
    'Helvetica, sans-serif' => 'Helvetica',
    'Tahoma' => 'Tahoma',
    'Trebuchet' => 'Trebuchet',
    'Times New Roman, sans-serif' => 'Times New Roman',
    'Verdana' => 'Verdana'
  );
  
  if( is_array($google_fonts) ){
    $google_fonts = array_combine($google_fonts, $google_fonts);
    $font_faces = array_merge($font_faces, $google_fonts);
  }
  
  $font_sizes = array();
  $font_sizes_px_none = array();
  for ($i = 9; $i <= 50; $i++){ 
    $font_sizes[$i.'px'] = $i.'px';
    $font_sizes_px_none[$i] = $i.'px';
  }

      $this->customizers = array(

        'title_tagline' => array(
          'title' => esc_html__('Site Identity', 'anymag'),
          'priority'  =>  1,
          'settings' => array(
            'anymag_site_logo' => array(
              'class'         => 'image',
              'label'         => esc_html__('Main Logo', 'anymag'),
              'description'   => esc_html__('Upload Site Logo Image', 'anymag'),
              'priority'      => 1
            ),
          )
        ),
//01.General ==========================================================================
      'anymag_section_general' => array(
        'title' => esc_html__('General', 'anymag'),
        'description' => '',
        'priority' => 1,
        'settings' => array(
          'anymag_home_layout' => array(
            'type'          => 'radio',
            'label'         => esc_html__('Blog Posts Style', 'anymag'),
            'description'   => '',
            'priority'      => 1,
            'choices'       => array(
              'home-list' => esc_html__('List Post','anymag'),
              'home-grid' => esc_html__('Grid Post','anymag'),
              'home-wide' => esc_html__('Wide Post','anymag'),
            ),
            'values' => array(
              'default' => 'home-list',
            )  
          ),
          'anymag_categ_layout' => array(
            'type'          => 'radio',
            'label'         => esc_html__('Category and Archive Style', 'anymag'),
            'description'   => '',
            'priority'      => 2,
            'choices'       => array(
              'categ-list' => esc_html__('List Post','anymag'),
              'categ-grid' => esc_html__('Grid Post','anymag'),
              'categ-wide' => esc_html__('Wide Post','anymag'),
            ),
            'values' => array(
              'default' => 'categ-list',
            )  
          ),
          'anymag_sidebars_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Main Sidebar', 'anymag'),
            'priority'      => 3,
          ),
          'anymag_home_sidebar' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Home Page Sidebar', 'anymag'),
            'description'   => '',
            'priority'      => 4,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_archive_sidebar' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Archive and Category Page Sidebar', 'anymag'),
            'description'   => '',
            'priority'      => 5,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_single_sidebar' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Single Post Sidebar', 'anymag'),
            'description'   => '',
            'priority'      => 6,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_page_sidebar' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Page Sidebar', 'anymag'),
            'description'   => '',
            'priority'      => 7,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_woo_sidebar' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show WooCommerce Page Sidebar', 'anymag'),
            'description'   => '',
            'priority'      => 8,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_elements_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Site Elements', 'anymag'),
            'priority'      => 9,
          ),
          'anymag_shadow_opacity' => array(
            'class' => 'slider',
            'label' => esc_html__('Fold Shadow Opacity', 'anymag'),
            'description' => '',
            'priority'      => 10,
            'choices' => array(
              'min'         => 0,
              'max'         => 9,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 0,
            ),
          ),
          'anymag_side_pattern' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Heading Horizontal Border', 'anymag'),
            'description'   => '',
            'priority'      => 10,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_turn_left' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Page Turn Effect on Image', 'anymag'),
            'description'   => '',
            'priority'      => 11,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_multiple_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Multiple Issues', 'anymag'),
            'priority'      => 12,
          ),
          'anymag_multiple_issues' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Enable Multiple Issues', 'anymag'),
            'description'   => '',
            'priority'      => 13,
            'values'        => array(
              'default' => false,
            )  
          ),
        )
      ),        
//02.Fonts ==========================================================================
      'anymag_section_fonts' => array(
        'title' => esc_html__('Fonts', 'anymag'),
        'description' => '',
        'priority' => 2,
        'settings' => array(
           'anymag_title_font' => array(
            'type'          => 'select',
            'label'         => esc_html__('Title Font', 'anymag'),
            'choices'       => $font_faces,
            'priority'      => 1,
            'values'        => array(
              'default' => 'Oswald',
            )
          ),
          'anymag_title_font_size' => array(
            'class' => 'slider',
            'label' => esc_html__('Title Font Size', 'anymag'),
            'description'   => '',
            'priority'      => 2,
            'choices' => array(
              'min'         => 16,
              'max'         => 70,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 26,
            ),
          ),
          'anymag_title_font_weight' => array(
            'class' => 'slider',
            'label' => esc_html__('Title Font Weight', 'anymag'),
            'description' => '',
            'priority' => 3,
            'choices' => array(
              'min'         => 100,
              'max'         => 900,
              'step'        => 100
            ),
            'values'  => array(
              'default' => 800,
            ),
          ),
          'anymag_title_line' => array(
            'class' => 'slider',
            'label' => esc_html__('Line Height', 'anymag'),
            'description' => '',
            'priority' => 4,
            'choices' => array(
              'min'         => 0.7,
              'max'         => 1.6,
              'step'        => 0.1
            ),
            'values'  => array(
              'default' => 1.3,
            ),
          ),
          'anymag_title_letterspace' => array(
            'class' => 'slider',
            'label' => esc_html__('Letter Spacing', 'anymag'),
            'description' => '',
            'priority' => 4,
            'choices' => array(
              'min'         => -10,
              'max'         => 10,
              'step'        => 1
            ),
            'values'  => array(
              'default' => -1,
            ),
          ),
          'anymag_title_upper' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Uppercase Title Font', 'anymag'),
            'description'   => '',
            'priority'      => 5,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_main_font_heading' => array(
            'class'        => 'heading',
            'label'        => esc_html__('Main Font', 'anymag'),
            'priority'     => 6,
          ),
          'anymag_main_font' => array(
            'type'          => 'select',
            'label'         => esc_html__('Main Text Font', 'anymag'),
            'choices'       => $font_faces,
            'priority'      => 7,
            'values'        => array(
              'default' => 'Poppins',
            )
          ),
          'anymag_font_size' => array(
            'class'         => 'slider',
            'label'         => esc_html__('Main Text Font Size', 'anymag'),
            'description'   => '',
            'priority'      => 8,
            'choices' => array(
              'min'         => 9,
              'max'         => 30,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 15,
            ),
          ),
          'anymag_mainfont_line' => array(
            'class' => 'slider',
            'label' => esc_html__('Line Height', 'anymag'),
            'description' => '',
            'priority' => 9,
            'choices' => array(
              'min'         => 1,
              'max'         => 2.8,
              'step'        => 0.1
            ),
            'values'  => array(
              'default' => 1.6,
            ),
          ),
          'anymag_mainfont_letterspace' => array(
            'class' => 'slider',
            'label' => esc_html__('Letter Spacing', 'anymag'),
            'description' => '',
            'priority' => 9,
            'choices' => array(
              'min'         => -4,
              'max'         => 10,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 0,
            ),
          ),
          'anymag_navi_heading' => array(
            'class'        => 'heading',
            'label'        => esc_html__('Site Menu Font', 'anymag'),
            'priority'     => 10,
          ),
          'anymag_navigation_font' => array(
            'type'          => 'select',
            'label'         => esc_html__('Site Menu Font', 'anymag'),
            'choices'       => $font_faces,
            'priority'      => 11,
            'values'        => array(
              'default' => 'Oswald',
            )
          ),
          'anymag_nav_font_size' => array(
            'class' => 'slider',
            'label' => esc_html__('Top Navigation Font Size', 'anymag'),
            'description' => '',
            'priority' => 12,
            'choices' => array(
              'min'         => 16,
              'max'         => 40,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 33,
            ),
          ),
          'anymag_nav_font_weight' => array(
            'class' => 'slider',
            'label' => esc_html__('Navigation Font Weight', 'anymag'),
            'description' => '',
            'priority' => 13,
            'choices' => array(
              'min'         => 100,
              'max'         => 900,
              'step'        => 100
            ),
            'values'  => array(
              'default' => 800,
            ),
          ),
        )
      ), 
//03.Colors ===============================================================           
      'anymag_section_colors' => array(
        'title' => esc_html__('Colors', 'anymag'),
        'description' => '',
        'priority' => 3,
        'settings' => array(
          'anymag_site_bg_color' => array(
            'label'         => esc_html__('Site Background Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 1,
            'values'        => array(
              'default' => '#fff',
            ),
          ),
          'anymag_post_title_color' => array(
            'label'         => esc_html__('Post Title Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 2,
            'values'        => array(
              'default' => '#2d2d2d',
            ),
          ),
          'anymag_post_title_hover' => array(
            'label'         => esc_html__('Post Title Hover Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 3,
            'values'        => array(
              'default' => '#999',
            ),
          ),
          'anymag_post_title_underline' => array(
            'label'         => esc_html__('Post Title Hover Underline Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 4,
            'values'        => array(
              'default' => '#ff027f',
            ),
          ),
          'anymag_post_text_color' => array(
            'label'         => esc_html__('Post Text Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 5,
            'values'        => array(
              'default' => '#787878',
            ),
          ),
          'anymag_link_color' => array(
            'label'         => esc_html__('Link Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 6,
            'values'        => array(
              'default' => '#111111',
            ),
          ),
          'anymag_link_hover' => array(
            'label'         => esc_html__('Link Hover Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 7,
            'values'        => array(
              'default' => '#999999',
            ),
          ),
          'anymag_postmeta_color' => array(
            'label'         => esc_html__('Post Meta Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 8,
            'values'        => array(
              'default' => '#2d2d2d',
            ),
          ),
          'anymag_postmeta_hover' => array(
            'label'         => esc_html__('Post Meta Hover Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 9,
            'values'        => array(
              'default' => '#999',
            ),
          ),
          'anymag_categs_color_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Categories', 'anymag'),
            'priority'      => 10,
          ),
          'anymag_categ_backgr_color' => array(
            'label'         => esc_html__('Category Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 11,
            'values'        => array(
              'default' => '#ff027f',
            ),
          ),
          'anymag_btn_color_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Buttons', 'anymag'),
            'priority'      => 12,
          ),
          'anymag_button_color' => array(
            'label'         => esc_html__('Button Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 13,
            'values'        => array(
              'default' => '#ff027f',
            ),
          ),
          'anymag_button_hover_color' => array(
            'label'         => esc_html__('Button Hover Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 14,
            'values'        => array(
              'default' => '#fc3095',
            ),
          ),
          'anymag_button_text_color' => array(
            'label'         => esc_html__('Button Text Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 15,
            'values'        => array(
              'default' => '#ffffff',
            ),
          ),
          'anymag_button_text_hover' => array(
            'label'         => esc_html__('Button Text Hover Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 16,
            'values'        => array(
              'default' => '#ffffff',
            ),
          ),
          'anymag_tag_color_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Tags', 'anymag'),
            'priority'      => 17,
          ),
          'anymag_tag_background_color' => array(
            'label'         => esc_html__('Tag Background Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 18,
            'values'        => array(
              'default' => '#f2f2f2',
            ),
          ),
          'anymag_tag_text_color' => array(
            'label'         => esc_html__('Tag Text Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 19,
            'values'        => array(
              'default' => '#787878',
            ),
          ),
          'anymag_pagination_color_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Pagination', 'anymag'),
            'priority'      => 21,
          ),
          'anymag_pagination_color' => array(
            'label'         => esc_html__('Active Pagination Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 22,
            'values'        => array(
              'default' => '#ff027f',
            ),
          ),
          'anymag_pagination_text_color' => array(
            'label'         => esc_html__('Active Pagination Text Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 23,
            'values'        => array(
              'default' => '#ffffff',
            ),
          ),
          'anymag_unactive_pagination_color' => array(
            'label'         => esc_html__('Pagination Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 24,
            'values'        => array(
              'default' => '#eeeeee',
            ),
          ),
          'anymag_unactive_pagination_text_color' => array(
            'label'         => esc_html__('Pagination Text Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 25,
            'values'        => array(
              'default' => '#787878',
            ),
          ),
          'anymag_unactive_pagination_color_hover' => array(
            'label'         => esc_html__('Pagination Color Hover', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 26,
            'values'        => array(
              'default' => '#e8e8e8',
            ),
          ),
          'anymag_unactive_pagination_text_color_hover' => array(
            'label'         => esc_html__('Pagination Text Color Hover', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 27,
            'values'        => array(
              'default' => '#111111',
            ),
          ),
        )
      ),            
//04.Header ==========================================================================
      'anymag_section_header' => array(
        'title' => esc_html__('Site Menu & Header', 'anymag'),
        'description' => '',
        'priority' => 4,
        'settings' => array(
          'anymag_menu_logo' => array(
            'class'         => 'image',
            'label'         => esc_html__('Menu Logo', 'anymag'),
            'description'   => '',
            'priority'      => 1,
           ),  
          'anymag_toggle_background' => array(
            'label'         => esc_html__('Toggle Background Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 2,
            'values'        => array(
              'default' => '#ff027f',
            ),
          ),
          'anymag_menu_bg_color' => array(
            'label'         => esc_html__('Menu Background Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 3,
            'values'        => array(
              'default' => '#f4f4f4',
            ),
          ),
          'anymag_topbar_linkcolor' => array(
            'label'         => esc_html__('Menu Links Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 4,
            'values'        => array(
              'default' => '#111111',
            ),
          ),
          'anymag_topbar_linkhover' => array(
            'label'         => esc_html__('Menu Links Hover Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 5,
            'values'        => array(
              'default' => '#fff',
            ),
          ),
          'anymag_topbar_linkhover_bg' => array(
            'label'         => esc_html__('Menu Links Hover Background Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 6,
            'values'        => array(
              'default' => '#ff027f',
            ),
          ),
          'anymag_topbar_search' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Menu Search Icon', 'anymag'),
            'description'   => '',
            'priority'      => 7,
            'values'        => array(
              'default' => true,
            ),
          ),
          'anymag_topbarright_search' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Right Header Search Icon', 'anymag'),
            'description'   => '',
            'priority'      => 8,
            'values'        => array(
              'default' => true,
            ),
          ),
          'anymag_topbar_social' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Social Links', 'anymag'),
            'description'   => '',
            'priority'      => 9,
            'values'        => array(
              'default' => false,
            ),
          ),
          'anymag_nav_shadow_opacity' => array(
            'class' => 'slider',
            'label' => esc_html__('Nav Panel Fold Shadow Opacity', 'anymag'),
            'description' => '',
            'priority'      => 10,
            'choices' => array(
              'min'         => 0,
              'max'         => 9,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 0,
            ),
          ),
        )
      ),   
//05.Cover ==============================================================
      'anymag_section_cover' => array(
        'title' => esc_html__('Cover', 'anymag'),
        'description' => '',
        'priority' => 5,
        'settings' => array(
          'anymag_cover' => array(
            'class'         => 'image',
            'label'         => esc_html__('Magazine Cover', 'anymag'),
            'description'   => esc_html__('Upload Magazine Cover Image', 'anymag'),
            'priority'      => 1
          ),
          'anymag_overlay_color' => array(
            'label'         => esc_html__('Overlay Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 2,
            'values'        => array(
              'default' => '#000000',
            ),
          ),
          'anymag_overlay_opacity' => array(
            'class'         => 'slider',
            'label'         => esc_html__('Cover Overlay Opacity', 'anymag'),
            'description'   => '',
            'priority'      => 3,
            'choices' => array(
              'min'         => 0,
              'max'         => 9,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 3,
            ),
          ),
          'anymag_cover_width' => array(
            'class'         => 'slider',
            'label'         => esc_html__('Cover Width(%)', 'anymag'),
            'description'   => '',
            'priority'      => 4,
            'choices' => array(
              'min'         => 20,
              'max'         => 60,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 50,
            ),
          ),
          'anymag_cover_logo_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Cover Logo', 'anymag'),
            'priority'      => 5,
          ),
          'anymag_cover_logo' => array(
            'class'         => 'image',
            'label'         => esc_html__('Сover Logo', 'anymag'),
            'description'   => '',
            'priority'      => 6,
           ),  
          'anymag_logo_position' => array(
            'type'          => 'radio',
            'label'         => esc_html__('Logo Position', 'anymag'),
            'description'   => '',
            'priority'      => 7,
            'choices'       => array(
              'logo-center' => esc_html__('Logo Center','anymag'),
              'logo-left' => esc_html__('Logo Left','anymag'),
            ),
            'values' => array(
              'default' => 'logo-center',
            )  
          ),
          'anymag_logo_width' => array(
            'class'         => 'slider',
            'label'         => esc_html__('Logo Width(%)', 'anymag'),
            'description'   => '',
            'priority'      => 8,
            'choices' => array(
              'min'         => 10,
              'max'         => 100,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 80,
            ),
          ),
          'anymag_home_nav' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Post Navigation', 'anymag'),
            'description'   => '',
            'priority'      => 9,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_cover_video_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Cover Video', 'anymag'),
            'priority'      => 10,
          ),
          'anymag_video_url' => array(
            'type'          => 'text',
            'label'         => esc_html__('YouTube Video Url', 'anymag'),
            'description'   => '',
            'priority'      => 11,
            'values'        => array(
              'default' => '',
            )
          ),
          'anymag_video_start' => array(
            'type'          => 'number',
            'label'         => esc_html__('Video Start (sec)', 'anymag'),
            'description'   => '',
            'priority'      => 12,
            'values'        => array(
              'default' => '',
            )
          ),
          'anymag_video_end' => array(
            'type'          => 'number',
            'label'         => esc_html__('Video End (sec)', 'anymag'),
            'description'   => '',
            'priority'      => 13,
            'values'        => array(
              'default' => '',
            )
          ),
          'anymag_vid_control' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Control', 'anymag'),
            'description'   => '',
            'priority'      => 14,
            'values'        => array(
              'default' => true,
            ) 
          ),  
          'anymag_video_scale' => array(
            'class'         => 'slider',
            'label'         => esc_html__('Video Scale', 'anymag'),
            'description'   => '',
            'priority'      => 15,
            'choices' => array(
              'min'         => 0,
              'max'         => 99,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 3,
            ),
          ),
        ) 
      ),  
 //06.Slider ==============================================================
      'anymag_section_slider' => array(
        'title' => esc_html__('Post Slider', 'anymag'),
        'description' => '',
        'priority' => 6,
        'settings' => array(
          'anymag_posts_slider' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Enable Featured Slider', 'anymag'),
            'description'   => '',
            'priority'      => 1,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_autoplay_slider' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Autoplay', 'anymag'),
            'description'   => '',
            'priority'      => 2,
            'values'        => array(
              'default' => false,
            )  
          ),
         'anymag_slides_number' => array(
            'type'          => 'number',
            'label'         => esc_html__('Amount of Slides', 'anymag'),
            'description'   => '',
            'priority'      => 3,
            'values'        => array(
              'default' => '5',
            )  
          ),
         'anymag_featured_id' => array(
            'type'          => 'text',
            'label'         => esc_html__('Featured Posts IDs', 'anymag'),
            'description'   => '',
            'priority'      => 4,
            'values'        => array(
              'default' => '',
            )
          ),
          'anymag_slider_height' => array(
            'class'         => 'slider',
            'label'         => esc_html__('Slider Height', 'anymag'),
            'description'   => '',
            'priority'      => 5,
            'choices'       => array(
              'min'  => 200,
              'max'  => 1080,
              'step' => 1
            ),
            'values'        => array(
              'default' => 510,
            ),
          ),
          'anymag_slider_font_size' => array(
            'class'         => 'slider',
            'label'         => esc_html__('Slider Font Size', 'anymag'),
            'description'   => '',
            'priority'      => 6,
            'choices'       => array(
              'min'  => 16,
              'max'  => 86,
              'step' => 1
            ),
            'values'        => array(
              'default' => 37,
            ),
          ),
          'anymag_slider_categ' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Categories', 'anymag'),
            'description'   => '',
            'priority'      => 7,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_slider_author' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Author', 'anymag'),
            'description'   => '',
            'priority'      => 8,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_slider_avatar' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Author Avatar', 'anymag'),
            'description'   => '',
            'priority'      => 9,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_slider_date' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Date', 'anymag'),
            'description'   => '',
            'priority'      => 10,
            'values'        => array(
              'default' => true,
            )  
          ),
        )  
      ),          
  //07.Home =======================================================
      'anymag_home_page' => array(
        'title' => esc_html__('Home Page', 'anymag'),
        'description' => '',
        'priority' => 7,
        'settings' => array(
          'anymag_hide_home_logo' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Hide Logo on Home Page', 'anymag'),
            'description'   => '',
            'priority'      => 1,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_intro_line_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Intro Line', 'anymag'),
            'priority'      => 2,
          ),
          'anymag_intro_line' => array(
            'type'          => 'textarea',
            'label'         => esc_html__('Intro Line', 'anymag'),
            'description'   => '',
            'priority'      => 3,
          ),
          'anymag_intro_line_width' => array(
            'class' => 'slider',
            'label' => esc_html__('Intro Line Width(%)', 'anymag'),
            'description'   => '',
            'priority'      => 4,
            'choices' => array(
              'min'         => 40,
              'max'         => 100,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 60,
            ),
          ),
          'anymag_intro_line_font_size' => array(
            'class' => 'slider',
            'label' => esc_html__('Intro Line Font Size', 'anymag'),
            'description'   => '',
            'priority'      => 5,
            'choices' => array(
              'min'         => 18,
              'max'         => 150,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 37,
            ),
          ),
          'anymag_random_posts_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Random Posts', 'anymag'),
            'priority'      => 6,
          ),
          'anymag_show_random' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Random Posts', 'anymag'),
            'description'   => '',
            'priority'      => 7,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_random_header' => array(
            'type'          => 'text',
            'label'         => esc_html__('Heading', 'anymag'),
            'description'   => '',
            'priority'      => 8,
            'values'        => array(
              'default' => '',
            )
          ),
          'anymag_random_style' => array(
            'type'          => 'radio',
            'label'         => esc_html__('Posts Style', 'anymag'),
            'description'   => '',
            'priority'      => 9,
            'choices'       => array(
              'classic' => esc_html__('Classic','anymag'),
              'overlayed' => esc_html__('Overlayed','anymag'),
            ),
            'values' => array(
              'default' => 'classic',
            )  
          ),
          'anymag_random_date' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Post Date', 'anymag'),
            'description'   => '',
            'priority'      => 10,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_random_num' => array(
            'type'         => 'select',
            'label'         => esc_html__('Posts Number', 'anymag'),
            'description'   => '',
            'priority'      => 11,
            'choices' => array(
              '3' => esc_html__('3', 'anymag'),
              '6' => esc_html__( '6', 'anymag' ),
            ),
            'values'        => array(
              'default' => '3',
            )  
          ),
          'anymag_feat_cat_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Featured Category', 'anymag'),
            'priority'      => 12,
          ),
          'anymag_show_featcat' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Featured Category', 'anymag'),
            'description'   => '',
            'priority'      => 13,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_featcat_header' => array(
            'type'          => 'text',
            'label'         => esc_html__('Heading', 'anymag'),
            'description'   => '',
            'priority'      => 14,
            'values'        => array(
              'default' => '',
            )
          ),
          'anymag_featured_category' => array(
            'class'        => 'catdrop',
            'label'        => esc_html__('Category', 'anymag'),
            'priority'     => 15,
          ),
          'anymag_featcat_date' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Post Date', 'anymag'),
            'description'   => '',
            'priority'      => 16,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_latest_posts_heading' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Latest Posts Heading', 'anymag'),
            'priority'      => 17,
          ),
          'anymag_latest_posts_header' => array(
            'type'          => 'text',
            'label'         => esc_html__('Latest Posts Heading', 'anymag'),
            'description'   => '',
            'priority'      => 18,
            'values'        => array(
              'default' => '',
            )
          ),
        )  
      ),       
  //08.Post Archive =======================================================
      'anymag_section_posts' => array(
        'title' => esc_html__('Post Archive', 'anymag'),
        'description' => '',
        'priority' => 8,
        'settings' => array(
          'anymag_img_height' => array(
            'class' => 'slider',
            'label' => esc_html__('Image Height', 'anymag'),
            'description' => '',
            'priority'      => 1,
            'choices' => array(
              'min'         => 200,
              'max'         => 900,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 300,
            ),
          ),
          'anymag_img_border_radius' => array(
            'class' => 'slider',
            'label' => esc_html__('Image Border Radius', 'anymag'),
            'description' => '',
            'priority'      => 2,
            'choices' => array(
              'min'         => 0,
              'max'         => 40,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 0,
            ),
          ),
          'anymag_hover_style' => array(
            'type'          => 'radio',
            'label'         => esc_html__('Post Title Hover Style', 'anymag'),
            'description'   => '',
            'priority'      => 3,
            'choices'       => array(
              'hover-underline' => esc_html__('Underline','anymag'),
              'hover-classic' => esc_html__('Classic','anymag'),
            ),
            'values' => array(
              'default' => 'hover-underline',
            )  
          ),
          'anymag_hover_zoom' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Image Hover Zoom', 'anymag'),
            'description'   => '',
            'priority'      => 4,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_post_author' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Author', 'anymag'),
            'description'   => '',
            'priority'      => 5,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_post_avatar' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Author Avatar', 'anymag'),
            'description'   => '',
            'priority'      => 6,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_list_categ' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Categories', 'anymag'),
            'description'   => '',
            'priority'      => 7,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_categ_style' => array(
            'type'          => 'radio',
            'label'         => esc_html__('Category Style', 'anymag'),
            'description'   => '',
            'priority'      => 9,
            'choices'       => array(
              'cat-classic' => esc_html__('Classic','anymag'),
              'cat-boxed' => esc_html__('Boxed','anymag'),
            ),
            'values' => array(
              'default' => 'cat-boxed',
            )  
          ),
          'anymag_list_date' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Date', 'anymag'),
            'description'   => '',
            'priority'      => 9,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_list_comments' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Comments Number', 'anymag'),
            'description'   => '',
            'priority'      => 10,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_show_excerpt' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Excerpt', 'anymag'),
            'description'   => '',
            'priority'      => 11,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_excerpt_lenght' => array(
            'class' => 'slider',
            'label' => esc_html__('Exerpt Length(words)', 'anymag'),
            'description' => '',
            'priority' => 12,
            'choices' => array(
              'min'         => 5,
              'max'         => 80,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 20,
            ),
          ),
          'anymag_pagination_type' => array(
            'type'         => 'select',
            'label'         => esc_html__('Pagination Type', 'anymag'),
            'description'   => '',
            'priority'      => 13,
            'choices' => array(
              'classic' => esc_html__('Classic', 'anymag'),
              'loadmore' => esc_html__( 'Load More', 'anymag' ),
              'infinite' => esc_html__( 'Infinite Scroll', 'anymag' ),
            ),
            'values'        => array(
              'default' => 'classic',
            )  
          ),
        )  
      ),
  //09.Single Post  ==========================================================================
      'anymag_section_single' => array(
        'title' => esc_html__('Single Post', 'anymag'),
        'description' => '',
        'priority' => 9,
        'settings' => array( 
          'anymag_single_logo' => array(
            'class'        => 'heading',
            'label'        => esc_html__('Post Page Logo', 'anymag'),
            'priority'     => 1,
          ),
          'anymag_sp_logo_position' => array(
            'type'          => 'radio',
            'label'         => esc_html__('Logo Position', 'anymag'),
            'description'   => '',
            'priority'      => 2,
            'choices'       => array(
              'logo-center' => esc_html__('Logo Center','anymag'),
              'logo-left' => esc_html__('Logo Left','anymag'),
            ),
            'values' => array(
              'default' => 'logo-center',
            )  
          ),
          'anymag_sp_logo_width' => array(
            'class'         => 'slider',
            'label'         => esc_html__('Logo Width(%)', 'anymag'),
            'description'   => '',
            'priority'      => 3,
            'choices' => array(
              'min'         => 10,
              'max'         => 80,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 80,
            ),
          ), 
          'anymag_post_title' => array(
            'class'        => 'heading',
            'label'        => esc_html__('Single Post Title', 'anymag'),
            'priority'     => 4,
          ),
          'anymag_post_title_font_size' => array(
            'class' => 'slider',
            'label' => esc_html__('Title Font Size', 'anymag'),
            'description'   => '',
            'priority'      => 5,
            'choices' => array(
              'min'         => 40,
              'max'         => 150,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 67,
            ),
          ),
          'anymag_single_title_line' => array(
            'class' => 'slider',
            'label' => esc_html__('Title Line Height', 'anymag'),
            'description'   => '',
            'priority'      => 6,
            'choices' => array(
              'min'         => 0.7,
              'max'         => 1.6,
              'step'        => 0.1
            ),
            'values'  => array(
              'default' => 1.1,
            ),
          ),
          'anymag_single_title_letterspace' => array(
            'class' => 'slider',
            'label' => esc_html__('Letter Spacing', 'anymag'),
            'description'   => '',
            'priority'      => 7,
            'choices' => array(
              'min'         => -10,
              'max'         => 10,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 0,
            ),
          ),
          'anymag_post_meta' => array(
            'class'         => 'heading',
            'label'         => esc_html__('Post Meta', 'anymag'),
            'priority'      => 10,
          ), 
          'anymag_single_author' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Author', 'anymag'),
            'description'   => '',
            'priority'      => 11,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_single_avatar' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Author Avatar', 'anymag'),
            'description'   => '',
            'priority'      => 12,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_single_date' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Date', 'anymag'),
            'description'   => '',
            'priority'      => 13,
            'values'        => array(
              'default' => true,
            )  
          ),  
          'anymag_single_categ' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Categories', 'anymag'),
            'description'   => '',
            'priority'      => 14,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_post_tags' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Tags', 'anymag'),
            'description'   => '',
            'priority'      => 15,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_single_cvr_elements_heading' => array(
            'class'        => 'heading',
            'label'        => esc_html__('Cover Image Elements', 'anymag'),
            'priority'     => 16,
          ),
          'anymag_cover_nav' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Prev/Next Navigation on Image', 'anymag'),
            'description'   => '',
            'priority'      => 17,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_cover_share' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Social Share on Image', 'anymag'),
            'description'   => '',
            'priority'      => 18,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_single_overlay_opacity' => array(
            'class'         => 'slider',
            'label'         => esc_html__('Image Overlay Opacity', 'anymag'),
            'description'   => '',
            'priority'      => 19,
            'choices' => array(
              'min'         => 0,
              'max'         => 9,
              'step'        => 1
            ),
            'values'  => array(
              'default' => 3,
            ),
          ),
          'anymag_post_cover' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Home Page Cover', 'anymag'),
            'description'   => '',
            'priority'      => 20,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_single_cont_elements_heading' => array(
            'class'        => 'heading',
            'label'        => esc_html__('Post Content Elements', 'anymag'),
            'priority'     => 21,
          ),
          'anymag_about_author' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show About Author Box', 'anymag'),
            'description'   => '',
            'priority'      => 22,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_related_posts' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Related Posts', 'anymag'),
            'description'   => '',
            'priority'      => 23,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_content_nav' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Prev/Next Navigation on Content', 'anymag'),
            'description'   => '',
            'priority'      => 24,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_post_comments' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Comments', 'anymag'),
            'description'   => '',
            'priority'      => 25,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_content_share' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Social Share', 'anymag'),
            'description'   => '',
            'priority'      => 26,
            'values'        => array(
              'default' => true,
            )  
          ),
          'anymag_share_heading' => array(
            'class'        => 'heading',
            'label'        => esc_html__('Social Share', 'anymag'),
            'priority'     => 27,
          ),
          'anymag_share_facebook' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Share Facebook', 'anymag'),
            'description'   => '',
            'priority'      => 28,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_share_twitter' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Share Twitter', 'anymag'),
            'description'   => '',
            'priority'      => 29,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_share_linkedin' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Share Linkedin', 'anymag'),
            'description'   => '',
            'priority'      => 30,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_share_pinterest' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Share Pinterest', 'anymag'),
            'description'   => '',
            'priority'      => 31,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_share_whatsapp' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Share Whatsapp', 'anymag'),
            'description'   => '',
            'priority'      => 32,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_share_telegram' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Share Telegram', 'anymag'),
            'description'   => '',
            'priority'      => 33,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_share_vk' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Share VKontakte', 'anymag'),
            'description'   => '',
            'priority'      => 34,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_share_ok' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Share Odnoklassniki', 'anymag'),
            'description'   => '',
            'priority'      => 35,
            'values'        => array(
              'default' => false,
            )  
          ),
        )
      ),       
     
  //10.Page ==========================================================================
      'anymag_section_page' => array(
        'title' => esc_html__('Page', 'anymag'),
        'description' => '',
        'priority' => 10,
        'settings' => array(  
          'anymag_page_share' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Page Share Links', 'anymag'),
            'description'   => '',
            'priority'      => 1,
            'values'        => array(
              'default' => false,
            )  
          ),
          'anymag_page_comments' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Hide Page Comments', 'anymag'),
            'description'   => '',
            'priority'      => 2,
            'values'        => array(
              'default' => false,
            )  
          ),  
        )
      ),        
  //11.Social Links ========================================================
      'anymag_section_social' => array(
        'title' => esc_html__('Social Links', 'anymag'),
        'description' => '',
        'priority' => 11,
        'settings' => array(
          'anymag_facebook' => array(
            'type'          => 'text',
            'label'         => esc_html__('Facebook','anymag'),
            'priority'      => 1
          ),
          'anymag_twitter' => array(
            'type'          => 'text',
            'label'         => esc_html__('Twitter','anymag'),
            'priority'      => 2
          ),
          'anymag_instagram' => array(
            'type'          => 'text',
            'label'         => esc_html__('Instagram','anymag'),
            'priority'      => 4
          ),
          'anymag_youtube' => array(
            'type'          => 'text',
            'label'         => esc_html__('Youtube','anymag'),
            'priority'      => 5
          ),
          'anymag_vimeo' => array(
            'type'          => 'text',
            'label'         => esc_html__('Vimeo','anymag'),
            'priority'      => 6
          ),
          'anymag_linkedin' => array(
            'type'          => 'text',
            'label'         => esc_html__('Linkedin','anymag'),
            'priority'      => 7
          ),
          'anymag_tiktok' => array(
            'type'          => 'text',
            'label'         => esc_html__('TikTok','anymag'),
            'priority'      => 8
          ),
          'anymag_pinterest' => array(
            'type'          => 'text',
            'label'         => esc_html__('Pinterest','anymag'),
            'priority'      => 9
          ),
          'anymag_dribbble' => array(
            'type'          => 'text',
            'label'         => esc_html__('Dribbble','anymag'),
            'priority'      => 10
          ),
          'anymag_flickr' => array(
            'type'          => 'text',
            'label'         => esc_html__('Flickr','anymag'),
            'priority'      => 11
          ),
          'anymag_tumblr' => array(
            'type'          => 'text',
            'label'         => esc_html__('Tumblr','anymag'),
            'priority'      => 12
          ),
          'anymag_snapchat' => array(
            'type'          => 'text',
            'label'         => esc_html__('Snapchat','anymag'),
            'priority'      => 13
          ),
          'anymag_spotify' => array(
            'type'          => 'text',
            'label'         => esc_html__('Spotify','anymag'),
            'priority'      => 14
          ),
          'anymag_soundcloud' => array(
            'type'          => 'text',
            'label'         => esc_html__('Soundcloud','anymag'),
            'priority'      => 15
          ),
          'anymag_telegram' => array(
            'type'          => 'text',
            'label'         => esc_html__('Telegram','anymag'),
            'priority'      => 16
          ),
          'anymag_whatsapp' => array(
            'type'          => 'text',
            'label'         => esc_html__('WhatsApp','anymag'),
            'priority'      => 17
          ),
          'anymag_vk' => array(
            'type'          => 'text',
            'label'         => esc_html__('VK','anymag'),
            'priority'      => 18
          ),
          'anymag_skype' => array(
            'type'          => 'text',
            'label'         => esc_html__('Skype','anymag'),
            'priority'      => 19
          ),
          'anymag_odnoklassniki' => array(
            'type'          => 'text',
            'label'         => esc_html__('Odnoklassniki','anymag'),
            'priority'      => 20
          ),
          'anymag_rss' => array(
            'type'          => 'text',
            'label'         => esc_html__('RSS','anymag'),
            'priority'      => 21
          ),
          'anymag_issuu' => array(
            'type'          => 'text',
            'label'         => esc_html__('Issuu','anymag'),
            'priority'      => 22
          ),
        )   
      ),
  //12.Footer =============================================================
      'anymag_section_footer' => array(
        'title' => esc_html__('Footer', 'anymag'),
        'description' => '',
        'priority' => 12,
        'settings' => array(
          'anymag_footer_logo' => array(
            'class'         => 'image',
            'label'         => esc_html__('Footer Logo', 'anymag'),
            'description'   => esc_html__('Upload Footer Logo Image', 'anymag'),
            'priority'      => 1
          ),
          'anymag_show_footer_logo' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Footer Logo', 'anymag'),
            'description'   => '',
            'priority'      => 2,
            'values'        => array(
              'default' => true,
            ),
          ),
          'anymag_footer_bg' => array(
            'label'         => esc_html__('Footer Background Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 3,
            'values'        => array(
              'default'   => '#fafafa',
            ),
          ),
          'anymag_footer_text' => array(
            'label'         => esc_html__('Footer Text Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 4,
            'values'        => array(
              'default'   => '#989898',
            ),
          ),
          'anymag_footer_links' => array(
            'label'         => esc_html__('Footer Links Color', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 5,
            'values'        => array(
              'default'   => '#111111',
            ),
          ),
          'anymag_footer_hover' => array(
            'label'         => esc_html__('Footer Links Hover', 'anymag'),
            'description'   => '',
            'class'         => 'color',
            'priority'      => 6,
            'values'        => array(
              'default'   => '#999',
            ),
          ),
          'anymag_footer_menu' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Footer Menu', 'anymag'),
            'description'   => '',
            'priority'      => 7,
            'values'        => array(
              'default' => false,
            ),
          ),
          'anymag_footer_social' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Social Links', 'anymag'),
            'description'   => '',
            'priority'      => 8,
            'values'        => array(
              'default' => false,
            ),
          ),
          'anymag_copyright_text' => array(
            'type'          => 'textarea',
            'label'         => esc_html__('Footer Copyright Text', 'anymag'),
            'description'   => '',
            'priority'      => 9,
          ),
          'anymag_show_copyright' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show Copyright', 'anymag'),
            'description'   => '',
            'priority'      => 10,
            'values'        => array(
              'default' => true,
            ),
          ),
        )
      ),
  // 13. Advertising  =================================================================
      'anymag_section_advertising' => array(
        'title' => esc_html__('Advertising Area', 'anymag'),
        'description' => '',
        'priority' => 13,
        'settings' => array(
          'anymag_adv_image' => array(
            'class'         => 'image',
            'label'         => esc_html__('Advertising Image', 'anymag'),
            'description'   => esc_html__('Upload Advertising Image', 'anymag'),
            'priority'      => 1
          ),
          'anymag_adv_link' => array(
            'type'          => 'text',
            'label'         => esc_html__('Advertising link', 'anymag'),
            'description'   => '',
            'priority'      => 2,
            'values'        => array(
              'default' => '',
            )
          ),
          'anymag_adv_new' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Open in New Tab', 'anymag'),
            'description'   => '',
            'priority'      => 3,
            'values'        => array(
              'default' => false,
            ),
          ),
          'anymag_adv_home' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show on Home Page', 'anymag'),
            'description'   => '',
            'priority'      => 4,
            'values'        => array(
              'default' => false,
            ),
          ),
          'anymag_adv_single' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show on Single Post', 'anymag'),
            'description'   => '',
            'priority'      => 5,
            'values'        => array(
              'default' => false,
            ),
          ),
          'anymag_adv_archive' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show on Archive & Category', 'anymag'),
            'description'   => '',
            'priority'      => 6,
            'values'        => array(
              'default' => false,
            ),
          ),
          'anymag_adv_pages' => array(
            'class'         => 'toggle',
            'label'         => esc_html__('Show on Pages', 'anymag'),
            'description'   => '',
            'priority'      => 7,
            'values'        => array(
              'default' => false,
            ),
          ),
        )
      ),

//Settings  =================================================================
    );
  }

      public function anymag_customizer_script() {
        // Register
        wp_enqueue_style('anymag-customize', get_template_directory_uri() . '/customize/assets/css/customizer.css', array(),null);
        wp_enqueue_style('jquery-ui', get_template_directory_uri() . '/customize/assets/css/jquery-ui.min.css', array(),null);
        wp_enqueue_script('anymag-customize', get_template_directory_uri() . '/customize/assets/js/customizer.js', array('jquery'), null, true);       
      }


      public function add_customize($customizers) {
        $this->customizers = array_merge($this->customizers, $customizers);
      }

      public function anymag_register_customizer() {
          global $wp_customize;

          foreach ($this->customizers as $section => $section_values) {
            //add section
            $wp_customize->add_section($section, $section_values);
            if (isset($section_values['settings']) && count($section_values['settings']) > 0) {
              foreach ($section_values['settings'] as $setting => $values) {
                //add setting
                $setting_values = array();
                if (isset($values['values'])) {
                  $setting_values = $values['values'];
                  unset($values['values']);
                }
                $wp_customize->add_setting($setting, array_merge( array( 'sanitize_callback' => null ), $setting_values));
                //Get class control
                $class = 'WP_Customize_Control';
                if (isset($values['class']) && !empty($values['class'])) {
                  $class = 'WP_Customize_' . ucfirst($values['class']) . '_Control';
                  unset($values['class']);
                }
                //add values section and settings
                $values['section'] = $section;
                $values['settings'] = $setting;
                //add controll
                $wp_customize->add_control(
                  new $class($wp_customize, $setting, $values)
                );
              }
            }
          }
          foreach($this->panels as $key => $panel){
            $wp_customize->add_panel($key, $panel);
          }
          return;
      }
  }
}

//Set Fonts  =================================================================

function anymag_get_used_google_fonts(){
  $googlefonts = array_unique(
    array(
      get_theme_mod('anymag_main_font', 'Poppins'),
      get_theme_mod('anymag_title_font', 'Oswald'),
      get_theme_mod('anymag_navigation_font', 'Poppins'),
    )
  );
  return $googlefonts;
}

if (!function_exists('anymag_google_fonts')){
  add_action( 'wp_enqueue_scripts', 'anymag_google_fonts' );
  add_action( 'enqueue_block_editor_assets', 'anymag_google_fonts' );
  function anymag_google_fonts() {
    $default = array(
      'Arial',
      'Verdana',
      'Trebuchet',
      'Times New Roman, sans-serif',
      'Tahoma'
    );

    $googlefonts = anymag_get_used_google_fonts();  
    $customfont = '';
    $googlefonts = array_unique($googlefonts);
    $google_style = ':100,100italic,200,200italic,300,300italic,400,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic';
    $fonts_set = '';
    $subset = get_theme_mod('anymag_google_font_subset');
    $subset_str = '';
    if(is_array($subset)){
      $subset = array_unique($subset);
      if(!empty($subset)){
        $subset_str = implode(',', $subset);
      }
    } else {
      $subset_str = $subset;
    }
    if($subset_str == '' || $subset_str == 'latin'){
      $subset_str = '';
    } else {
      $subset_str = '&amp;subset='.$subset_str;
    }
    $count = 1; 
    foreach($googlefonts as $getfonts) {
      if(!in_array($getfonts, $default)) {
        $font_l = strtolower(str_replace(' ', '-', $getfonts));
        $google_style_t = get_theme_mod('anymag_google_font_'.$font_l);
        if(is_array($google_style_t)){
          $google_style_t = array_unique($google_style_t);
          if(!empty($google_style_t)){
            $google_style = ':'.implode(',', $google_style_t);
          }
        } else {
          if($google_style_t != ''){
            $google_style = ':'.$google_style_t;
          }
        }
        $customfont = str_replace(' ', '+', $getfonts).$google_style;
        if($customfont != ''){
          $font_name = strtolower(str_replace(' ', '-', $getfonts));
          if($count == 1) {
            $divider = '';
          } else {
            $divider = '%7C';
          }
            $fonts_set .= $divider.$customfont;
        }
        $count++;
      }
    }
    
    if( $fonts_set != '' ){
      wp_enqueue_style( 'google-fonts-anymag', esc_url("//fonts.googleapis.com/css?family=".$fonts_set.$subset_str), array(), NULL, 'all' );
    }
  }
}