<?php
  $category = get_queried_object();
  $cat_id ='category_'.$category->term_id;
  if (class_exists('ACF')) {
    $cat_image = get_field('category_image', $cat_id);
    $cat_text =  get_field('category_text', $cat_id);
  } 
?>
<div class="magcover">
  <?php if(get_theme_mod('anymag_turn_left', true)) : ?><div class="turn-left"></div><?php endif; ?>
  <div class="fold-shadow-left"></div>
    <div class="cover-wrap">
      <div class="cover-content">
        <?php get_template_part('inc/headers/header-post'); ?>
        <div class="overlay"></div>
          <?php 
            $thumbnail1 = $cat_image ['sizes']['anymag-post'];
            $thumbnail2 = $cat_image ['sizes']['anymag-thumb'];
          ?>
        <div class="single-post-image" data-interlace-src="<?php echo esc_url($thumbnail1); ?>" data-interlace-low="<?php echo esc_url($thumbnail2); ?>"> </div>   
      </div>
  </div> 
  <?php the_archive_description( '<div class="category-descr">', '</div>' ); ?>
</div> 
