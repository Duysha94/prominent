<?php get_header(); ?>

   <div class="content-area<?php if (get_theme_mod('anymag_home_sidebar', true) && is_active_sidebar('main-sidebar')) : ?> has-sidebar<?php endif; ?>">
      <?php if(get_theme_mod('anymag_adv_home') == true) : ?>     
        <?php get_template_part('inc/templates/add-area'); ?>
      <?php endif; ?> 

      <!-- Intro Line -->
     <?php if(get_theme_mod('anymag_intro_line')) : ?>
        <?php get_template_part('inc/templates/intro-line'); ?>
     <?php endif; ?>  

      <div class="posts-area">
       <!-- Posts Slider -->
        <?php if(get_theme_mod('anymag_posts_slider') == true ) : ?>
          <div id="slider-content"> 
            <?php get_template_part('inc/post-slider/post-slider'); ?>
          </div> 
        <?php endif; ?>    
        <!-- Random Posts -->
        <?php if(get_theme_mod('anymag_show_random') == true ) : ?>  
          <?php get_template_part('inc/templates/random-posts'); ?>
        <?php endif; ?>
       <!-- Featured Category -->
        <?php if(get_theme_mod('anymag_show_featcat') == true ) : ?>  
          <?php get_template_part('inc/templates/feat-category'); ?>
        <?php endif; ?>  

        <?php if  (get_theme_mod( 'anymag_latest_posts_header' )) : ?>
          <div class="section-title <?php if (get_theme_mod('anymag_side_pattern', true)) : ?>side-pattern<?php endif; ?>">
            <h2><?php echo wp_kses(get_theme_mod('anymag_latest_posts_header'), $anymag_allow_html); ?></h2>
          </div>
        <?php endif; ?> 

        <?php 
          if (get_theme_mod('anymag_home_layout') == 'home-grid') { $postclass="two-fr"; }
          elseif (get_theme_mod('anymag_home_layout') == 'home-wide') { $postclass="post-wide"; }
          else { $postclass="post-list one-fr"; }
        ?>
          <div id="latest-posts" class="blog-posts <?php echo esc_html($postclass) ?>">
            
          <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
              <?php get_template_part('content'); ?>
            <?php endwhile; ?>
          <?php endif; ?>
          
          </div>
          
          <div class="page-nav">
            <?php anymag_pagination_type(); ?>
          </div>
      
      </div>
      
        <?php if (get_theme_mod('anymag_home_sidebar', true) && is_active_sidebar('main-sidebar')) : ?>
          <?php get_sidebar(); ?>
        <?php endif; ?>
      </div>
    


<?php get_footer(); ?>
