/*!
 * AK Brand Development Studio — motion layer for WordPress.
 *
 * Zeyna already loads GSAP (with SplitText, ScrollTrigger, Flip, Observer),
 * Lenis and Barba, so this file loads none of them. It adds the studio's own
 * devices on top and — critically — tears them down and rebuilds them around
 * Barba's container swap, which is what breaks on most bespoke work bolted
 * onto a transition theme.
 *
 * Zeyna puts data-barba="container" on <main id="primary"> and calls
 * get_footer() after it, so the footer lives OUTSIDE the container and
 * persists. The Seam therefore lives in the footer and initialises once.
 */
(function () {
  'use strict'

  // Run-once guard: a page optimizer inlining the script beside the enqueued
  // copy would otherwise double-bind every Barba hook and listener.
  if (window.AK) return

  var doc = document
  var root = doc.documentElement
  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)')

  /* ── Registry ────────────────────────────────────────────────────────────
   * Components register themselves instead of the transition code hard-coding
   * every one of them. Each phase runs in registration order inside try/catch,
   * so one throwing handler can never break navigation.
   * -------------------------------------------------------------------- */
  var registry = new Map()

  var AK = (window.AK = {
    register: function (entry) {
      registry.set(entry.id, entry)
      if (entry.init) safely(entry.init.bind(entry), currentContainer())
    },
    unregister: function (id) {
      var e = registry.get(id)
      if (e && e.cleanup) safely(e.cleanup.bind(e), currentContainer())
      registry.delete(id)
    },
    reducedMotion: function () {
      return reduced.matches
    }
  })

  function currentContainer() {
    return doc.querySelector('[data-barba="container"]') || doc.body
  }

  function safely(fn, container) {
    try {
      fn(container)
    } catch (err) {
      if (window.console) console.warn('[AK]', err)
    }
  }

  function runPhase(name, container) {
    registry.forEach(function (entry) {
      if (entry[name]) safely(entry[name].bind(entry), container)
    })
  }

  /* ── Named eases ─────────────────────────────────────────────────────────
   * The same four curves as the CSS tokens, so a GSAP tween and a CSS
   * transition on one element are physically identical. Registered as plain
   * functions because Zeyna's GSAP bundle does not include CustomEase.
   * -------------------------------------------------------------------- */
  function bezier(x1, y1, x2, y2) {
    return function (t) {
      var lo = 0, hi = 1, u = t
      for (var i = 0; i < 20; i++) {
        var mt = 1 - u
        var x = 3 * mt * mt * u * x1 + 3 * mt * u * u * x2 + u * u * u
        if (Math.abs(x - t) < 0.0005) break
        if (x < t) lo = u; else hi = u
        u = (lo + hi) / 2
      }
      var m = 1 - u
      return 3 * m * m * u * y1 + 3 * m * u * u * y2 + u * u * u
    }
  }

  if (window.gsap) {
    gsap.registerEase('ak.cut', bezier(0.16, 1, 0.3, 1))
    gsap.registerEase('ak.thread', bezier(0.65, 0.05, 0.36, 1))
    gsap.registerEase('ak.snap', bezier(0.34, 1.56, 0.64, 1))
    gsap.registerEase('ak.drape', bezier(0.22, 0.61, 0.36, 1))
  }

  /* ── Mode switch: ATELIER / RUNWAY ───────────────────────────────────────
   * Zeyna has no light/dark mode — verified, there is not one selector for it
   * anywhere in the theme. This is ours.
   *
   * State lives on <html data-theme>, NOT on <body>. That is deliberate: Barba
   * replaces body classes wholesale on every navigation, so a mode kept on the
   * body flashes back on every soft navigation. An attribute on the
   * documentElement survives untouched.
   *
   * First paint is handled by a blocking inline script in <head> (see
   * inc/theme-mode.php), so a dark visitor never sees a white flash.
   * -------------------------------------------------------------------- */
  function applyMode(mode, persist) {
    root.setAttribute('data-theme', mode)
    // Only an explicit click persists. Writing the OS-derived value would
    // turn a default into a stored "choice" and pin the visitor to their
    // first-visit mode forever.
    if (persist) {
      try {
        localStorage.setItem('ak-theme', mode)
      } catch (e) { /* private mode: the choice lasts this visit */ }
    }

    var dark = mode === 'dark'
    Array.prototype.forEach.call(doc.querySelectorAll('[data-ak-mode]'), function (btn) {
      btn.setAttribute('aria-pressed', String(dark))
      btn.setAttribute('aria-label', 'Switch to ' + (dark ? 'Atelier (light)' : 'Runway (dark)') + ' mode')
      var label = btn.querySelector('.ak-mode__label')
      if (label) label.textContent = dark ? 'Runway' : 'Atelier'
    })
  }

  var chosen = false

  doc.addEventListener('click', function (e) {
    var btn = e.target.closest ? e.target.closest('[data-ak-mode]') : null
    if (!btn) return
    e.preventDefault()
    chosen = true
    applyMode(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark', true)
  })

  var stored = null
  try { stored = localStorage.getItem('ak-theme') } catch (e) { /* ignore */ }
  if (!stored) {
    var osMode = window.matchMedia('(prefers-color-scheme: dark)')
    if (osMode.addEventListener) {
      osMode.addEventListener('change', function (ev) {
        if (chosen) return
        applyMode(ev.matches ? 'dark' : 'light')
      })
    }
  }
  applyMode(root.getAttribute('data-theme') || 'light')

  /* ── Cut text ────────────────────────────────────────────────────────────
   * The house headline reveal: each line split along its midline into two
   * halves that start displaced in opposite directions and close.
   *
   * The split is DISMANTLED on completion — clip released, duplicate hidden —
   * because display type at ~0.9 leading puts descenders outside the line box,
   * and clip-path clips to the element's own box no matter what padding a
   * parent carries. Clipping exists only while something is moving.
   * -------------------------------------------------------------------- */
  AK.register({
    id: 'ak:cut-text',
    _ctx: null,
    _timers: [],
    init: function (container) {
      if (!window.gsap || !window.SplitText || reduced.matches) return
      var self = this
      self._ctx = gsap.context(function () {
        Array.prototype.forEach.call(container.querySelectorAll('[data-ak-cut]'), function (host) {
          SplitText.create(host, {
            type: 'lines',
            linesClass: 'ak-cut-line',
            autoSplit: true,
            aria: 'auto',
            onSplit: function (split) {
              var halves = []
              split.lines.forEach(function (line) {
                var html = line.innerHTML
                line.innerHTML = ''
                var top = doc.createElement('span')
                top.className = 'ak-cut-half ak-cut-half--top'
                top.innerHTML = html
                var bottom = doc.createElement('span')
                bottom.className = 'ak-cut-half ak-cut-half--bottom'
                bottom.innerHTML = html
                line.appendChild(top)
                line.appendChild(bottom)
                halves.push([top, bottom])
              })

              var tl = gsap.timeline({
                defaults: { ease: 'ak.cut' },
                scrollTrigger: { trigger: host, start: 'top 86%', once: true },
                onComplete: function () {
                  split.lines.forEach(function (l) { l.setAttribute('data-cut-settled', '') })
                  halves.forEach(function (pair) {
                    pair[0].style.clipPath = 'none'
                    pair[1].style.display = 'none'
                  })
                }
              })

              halves.forEach(function (pair, i) {
                var at = i * 0.028
                tl.fromTo(pair[0], { xPercent: 4, yPercent: -46, opacity: 0 },
                  { xPercent: 0, yPercent: 0, opacity: 1, duration: 1.2 }, at)
                  .fromTo(pair[1], { xPercent: -4, yPercent: 46, opacity: 0 },
                    { xPercent: 0, yPercent: 0, opacity: 1, duration: 1.2 }, at)
              })

              // A reveal that starts at opacity 0 must never be able to
              // strand content if its trigger never fires — but only rescue
              // hosts actually IN the viewport: everything below the fold is
              // legitimately waiting for the visitor to scroll to it.
              self._timers.push(setTimeout(function () {
                var r = host.getBoundingClientRect()
                if (r.top < window.innerHeight && r.bottom > 0 &&
                    tl.progress() === 0 && !tl.isActive()) tl.play()
              }, 2500))

              return tl
            }
          })
        })
      }, container)
    },
    cleanup: function () {
      this._timers.forEach(clearTimeout)
      this._timers = []
      if (this._ctx) this._ctx.revert()
      this._ctx = null
    },
    reinit: function () {
      if (window.ScrollTrigger) ScrollTrigger.refresh()
    }
  })

  /* ── Measure frame ───────────────────────────────────────────────────────
   * Hover and focus do the work on fine pointers (pure CSS). On touch the
   * annotations appear when the block scrolls into view, so no figure is ever
   * hover-only.
   * -------------------------------------------------------------------- */
  AK.register({
    id: 'ak:measure',
    _io: null,
    init: function (container) {
      var frames = container.querySelectorAll('[data-ak-measure]')
      if (!frames.length) return
      if (window.matchMedia('(hover: hover) and (pointer: fine)').matches) return

      this._io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          entry.target.classList.toggle('is-measured', entry.isIntersecting)
        })
      }, { threshold: 0.55 })

      var io = this._io
      Array.prototype.forEach.call(frames, function (f) { io.observe(f) })
    },
    cleanup: function () {
      if (this._io) this._io.disconnect()
      this._io = null
    }
  })

  /* ── The Seam ────────────────────────────────────────────────────────────
   * One orange thread down the page, bowing against scroll velocity on an
   * underdamped spring. It lives in the footer, outside Barba's container, so
   * it initialises once and survives every navigation.
   * -------------------------------------------------------------------- */
  ;(function seam() {
    var host = doc.querySelector('[data-ak-seam]')
    if (!host || !window.gsap) return
    var paths = host.querySelectorAll('path')
    var knot = host.querySelector('circle')
    if (paths.length < 2) return

    var X = 30, H = 1000
    var pos = 0, vel = 0, target = 0
    var last = window.scrollY, lastT = performance.now()

    function draw() {
      if (reduced.matches) {
        pos = 0
      } else {
        // Underdamped spring: the thread wobbles taut rather than snapping.
        vel = (vel + (target - pos) * 0.09) * 0.78
        pos += vel
      }
      var d = 'M ' + X + ' 0 Q ' + (X + pos) + ' ' + H / 2 + ' ' + X + ' ' + H
      paths[0].setAttribute('d', d)
      paths[1].setAttribute('d', d)

      var max = doc.documentElement.scrollHeight - window.innerHeight
      var prog = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0
      paths[1].style.strokeDasharray = '2000'
      paths[1].style.strokeDashoffset = String((1 - prog) * 2000)
      if (knot) {
        knot.setAttribute('cy', String(prog * H))
        knot.setAttribute('cx', String(X + 2 * (1 - prog) * prog * pos))
      }
    }

    window.addEventListener('scroll', function () {
      var now = performance.now()
      var dt = Math.max(1, now - lastT)
      var v = ((window.scrollY - last) / dt) * 16
      last = window.scrollY
      lastT = now
      target = Math.max(-34, Math.min(34, -v * 0.9))
    }, { passive: true })

    gsap.ticker.add(draw)
  })()

  /* ── Barba bridge ────────────────────────────────────────────────────────
   * Without this, every navigation leaks ScrollTriggers and observers, scroll
   * positions drift, and pinned sections compute against the wrong document
   * height. Zeyna ships no teardown for third-party work.
   * -------------------------------------------------------------------- */
  function bindBarba() {
    if (!window.barba || !barba.hooks) return

    barba.hooks.beforeLeave(function (data) {
      runPhase('cleanup', (data && data.current && data.current.container) || currentContainer())
    })

    barba.hooks.afterEnter(function (data) {
      var container = (data && data.next && data.next.container) || currentContainer()
      runPhase('init', container)
      runPhase('reinit', container)

      // Accessibility across a soft navigation — Barba ships none of this.
      container.setAttribute('tabindex', '-1')
      container.focus({ preventScroll: true })
      var live = doc.getElementById('ak-route-announcer')
      if (live) live.textContent = doc.title
    })
  }

  if (doc.readyState === 'complete') bindBarba()
  else window.addEventListener('load', bindBarba)
})()
