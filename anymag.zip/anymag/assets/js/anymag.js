jQuery(document).ready(function($) {

  "use strict";

  $.fn.clickToggle = function(a,b) {
    function cb(){
      [b,a][this._tog^=1].call(this);
    }
    return this.on("click", cb);
  };
  
  // Menu
  $('.top-menu-button').on( 'click', function(e) {
    e.preventDefault();
    $('.site-wrapper').toggleClass('nav-open');
  });

  // Sidebar Nav
    var $navMenu = $('#nav-wrapper .nav-menu');

    if( $navMenu.length ) {
      $navMenu.children('li').addClass('menu-item-parent');
      
      $navMenu.find('.menu-item-has-children > span').on('click', function(e){

        e.preventDefault();
        var itemSub = $(this).next('.sub-menu'),
            parentSubs = $(this).closest('.menu-item-parent').find('.sub-menu');
        
        $navMenu.find('.sub-menu').not(parentSubs).slideUp(250);
        itemSub.slideToggle(250);
      }); 
    } 

  new SimpleBar(document.getElementById('nav-wrapper'), { 
     autoHide: false,
   }
  );


// Search
  $('a.search').on('click', function (e) {
      e.preventDefault();
      $('body').addClass('open-search-form');
      setTimeout(function(){
          $('.searchform .search-field').focus();
      }, 600);
  });
  $('.btn-close-search').on('click', function (e) {
      e.preventDefault();
      $('body').removeClass('open-search-form');
  });


// Side Menu
  var $sidebar_inner =  $('.sidebar');
  $('.widget_nav_menu, .widget_pages', $sidebar_inner).addClass('menu').closest('.widget').addClass('sidebar-menu');
  $('.widget_categories, .widget_product_categories', $sidebar_inner).closest('.widget').addClass('categ-menu');
  $('.children').closest('.cat-item').addClass('has-sub');

  $('.menu li > ul, .categ-menu li > ul').each(function(){
      var $ul = $(this);
      $ul.before('<span class="narrow"><i></i></span>');
  });

  $('.sidebar-menu li.menu-item-has-children > a span, .menu li.mm-item-has-sub > a span, .menu li > .narrow, .has-sub > .narrow').on('click', function(e){
      e.preventDefault();
      var $parent = $(this).parent();
      if ($parent.hasClass('open')) {
          $parent.removeClass('open');
          $parent.find('>ul').stop().slideUp();
      } else {
          $parent.addClass('open');
          $parent.find('>ul').stop().slideDown();
          $parent.siblings().removeClass('open').find('>ul').stop().slideUp();
      }

  });

// WooCommerce
$( document ).on( 'click', '.plus-btn, .minus-btn', function() {
    var $qty    = $( this ).closest( '.quantity' ).find( '.qty' ),
      currentVal  = parseFloat( $qty.val() ),
      max     = parseFloat( $qty.attr( 'max' ) ),
      min     = parseFloat( $qty.attr( 'min' ) ),
      step    = $qty.attr( 'step' );

    if ( ! currentVal || currentVal === '' || currentVal === 'NaN' ) currentVal = 0;
    if ( max === '' || max === 'NaN' ) max = '';
    if ( min === '' || min === 'NaN' ) min = 0;
    if ( step === 'any' || step === '' || step === undefined || parseFloat( step ) === 'NaN' ) step = 1;

    if ( $( this ).is( '.plus-btn' ) ) {
      if ( max && ( max == currentVal || currentVal > max ) ) {
        $qty.val( max );
      } else {
        $qty.val( currentVal + parseFloat( step ) );
      }
    } else {
      if ( min && ( min == currentVal || currentVal < min ) ) {
        $qty.val( min );
      } else if ( currentVal > 0 ) {
        $qty.val( currentVal - parseFloat( step ) );
      }
    }
    $qty.trigger( 'change' );
});  

  $('.woocommerce-tabs .wc-tab-title a').on('click', function(e){
    e.preventDefault();
    var $this = $(this),
    $wrap = $this.closest('.woocommerce-tabs'),
    $wc_tabs = $wrap.find('.wc-tabs'),
    $panel = $this.closest('.wc-tab');

    $wc_tabs.find('a[href="'+ $this.attr('href') +'"]').parent().toggleClass('active').siblings().removeClass('active');
    $panel.toggleClass('active').siblings().removeClass('active');
  });
  $('.woocommerce-Tabs-panel--description').addClass('active');

    jQuery('.product-wrapper').each(function(){
      jQuery(this).on('mouseover click', function(){
        jQuery(this).addClass('hover');
      });
      jQuery(this).on('mouseleave', function(){
        jQuery(this).removeClass('hover');
      });
    });

  // Detect Adminbar

  if ($('#wpadminbar').length && $('#wpadminbar').is(':visible')) {
    var toppos = $('#wpadminbar').height();
  }
  else {
    toppos = 0;
  }

  $('.cover-sidebar-left, .cover-sidebar-right, .social-share-cover, .category-descr, .post-navigation').css('bottom', toppos+30);


// Hidden Sidebar

  $('.widgets-side').css('top', toppos);

  $('.hidden-sidebar-button a').click(function(){
    return false;
  });
  $('.hidden-sidebar-button a').clickToggle(
    function(){
      $(this).addClass('active');
      $('#hidden-sidebar').addClass('active');
      return false;
    },function(){
      $(this).removeClass('active');
      $('#hidden-sidebar').removeClass('active');
      return false;
   }
  );
  $('#hidden-sidebar a.close-button').click(function(){
    $(this).parent('#hidden-sidebar').removeClass('active');
    $('.hidden-sidebar-button a').click();
    return false;
  });

// Video Thumbnails

(function () {
  var APIinit = false;
  var process = false;
  var curent = [];
  var frames = [];
  var attrs = [];

  // Create deferred object
  var YTdeferred = $.Deferred();
  window.onYouTubePlayerAPIReady = function () {
      // resolve Youtube callback
      YTdeferred.resolve( window.YT );
  };

    // Embedding Youtube iframe API
    function embedYoutubeAPI() {
      var tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      var firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode.insertBefore( tag, firstScriptTag );
    }

  // Video rescale.
  function rescaleVideo() {
     $('.video-init').each(function(){
      var w = $(this).parent().width();
      var h = $(this).parent().height();
      var vidControls = 500;
      var id = $(this).attr('data-video-id');
      if (w / h > 16 / 9) {
        frames[id].setSize(w, w / 16 * 9 + vidControls);
      } else {
        frames[id].setSize(h / 9 * 16, h + vidControls);
      }
    });
  }

  // Init video background.
  function initVideo() {

    if (process) {
      return;
    }

    process = true;

    // Smart init API.
    if (!APIinit) {
      var elements = $('.video-wrapper[data-video-id]');

      if (elements.length) {
        embedYoutubeAPI();
        APIinit = true;
      }
    }

    if (!APIinit) {
      process = false;
      return;
    }

    // Whenever youtube callback was called = deferred resolved
    // your custom function will be executed with YT as an argument.
    YTdeferred.done(function (YT) {

      $('.video-content').each(function () {

        // The state.
        var isInit = $(this).hasClass('video-init');

        var id = null;

        // Generate unique ID.
        if (!isInit) {
          id = Math.random().toString(36).substr(2, 9);
        } else {
          id = $(this).attr('data-video-id');
        }

        // Create curent.
        curent[id] = this;

        // The actived.
        var isActive = $(curent[id]).hasClass('active');

        // The monitor.
        var isInView = $(curent[id]).isInViewport();

        // Initialization.
        if (isInView && !isInit) {
          // Add init class.
          $(curent[id]).addClass('video-init');

          // Add unique ID.
          $(curent[id]).attr('data-video-id', id);

          // Get video attrs.
          var videoID = $(curent[id]).parent().data('video-id');
          var videoStart = $(curent[id]).parent().data('video-start');
          var videoEnd = $(curent[id]).parent().data('video-end');

          // Check video id.
          if (typeof videoID === 'undefined' || !videoID) {
            return;
          }

          // Video attrs.
          attrs[id] = {
            'videoId': videoID,
            'startSeconds': videoStart,
            'endSeconds': videoEnd,
            'suggestedQuality': 'hd720'
          };

          // Creating a player.
          frames[id] = new YT.Player(curent[id], {
            playerVars: {
              autoplay: 0,
              autohide: 1,
              modestbranding: 1,
              rel: 0,
              showinfo: 0,
              controls: 0,
              disablekb: 1,
              enablejsapi: 0,
              iv_load_policy: 3,
              playsinline: 1,
              loop: 1
            },
            events: {
              'onReady': function onReady() {
                frames[id].loadVideoById(attrs[id]);
                frames[id].mute();
              },
              'onStateChange': function onStateChange(e) {
                if (e.data === 1) {
                  $(curent[id]).parents('.video-overlay, .video-wrapper').addClass('video-thumb-init');
                  $(curent[id]).addClass('active');
                } else if (e.data === 0) {
                  frames[id].seekTo(attrs[id].startSeconds);
                }
              }
            }
          });
          rescaleVideo();
        }
      });
    });
    process = false;
  }
    // Volume Control
    $(document).on( 'click', '.video-volume', function(){
      var videowrap = $(this).parents('.video-overlay, .video-wrapper').find('.video-content');
      var id = $(videowrap).attr('data-video-id');
      $(this).toggleClass('video-mute video-unmute');
      $(this).children().toggleClass('fa-volume-mute fa-volume-down');
      if ($(this).hasClass('video-unmute')) {
        frames[id].unMute();
      } else {
        frames[id].mute();
      }
    });
    // Play Control
    $(document).on( 'click', '.video-state', function() {
      var videowrap = $(this).parents('.video-overlay, .video-wrapper').find('.video-content');
      var id = $(videowrap).attr('data-video-id');
      $(this).toggleClass('video-pause video-play');
      $(this).children().toggleClass('fa-pause-circle fa-play-circle');
      if ($(this).hasClass('video-pause')) {
        $(this).removeClass('video-unpause');
        frames[id].playVideo();
      } else {
        $(this).addClass('video-unpause');
        frames[id].pauseVideo();
      }
    });
    // Stop Control
    $(document).on( 'click', '.video-stop', function() {
      var videowrap = $(this).parents('.video-overlay, .video-wrapper').find('.video-content');
      var id = $(videowrap).attr('data-video-id');
      $(this).siblings('.video-state').removeClass('video-pause').addClass('video-play');
      $(this).siblings('.video-state').addClass('video-unpause');
      frames[id].pauseVideo();
    } );
    // On document ready
    $(document).ready(function() {
      initVideo();
    });
    // On document ready
    $(document).ready(function() {
      initVideo();
    });
    // On document resize.
    $(window).on('resize', function() {
      rescaleVideo();
    });
    // On scroll
    $(window).on('load scroll resize scrollstop', function() {
      initVideo();
    });

  // Init.
  initVideo();
})(); 

  // Detect if an element in the view port.
  $.fn.isInViewport = function() {
    var elementTop = $( this ).offset().top;
    var elementBottom = elementTop + $( this ).outerHeight();
    var viewportTop = $( window ).scrollTop();
    var viewportBottom = viewportTop + $( window ).height();
    return elementBottom > viewportTop && elementTop < viewportBottom;
  };

 // Fitvids
  $(document).ready(function(){
    // Target your .container, .wrapper, .post, etc.
    $(".container").fitVids();
  });

    //Widget Title
  $('.wp-block-group__inner-container > h1,.wp-block-group__inner-container > h2,.wp-block-group__inner-container > h3,.wp-block-group__inner-container > h4,.wp-block-group__inner-container > h5,.wp-block-group__inner-container > h6').each(function(){
    var e = $(this);
    e.after('<h4 class="widget-title">'+e.text()+'</h4>');
    e.remove();
  });

  //Category Widget Last Element
  $('.sidebar .widget_category:last').css("margin-bottom","50px");
       
  // IE, Edge image fit
  var userAgent, ieReg, ie, msedge;
  userAgent = window.navigator.userAgent;
  ieReg = /msie|Trident.*rv[ :]*11\./gi;
  ie = ieReg.test(userAgent);
  msedge = /Edge\/\d./i.test(navigator.userAgent);
  if(ie || msedge) {
    $(".image-part, feat-categ-item .image-part, single-post-image, cover-image, .random-image").each(function () {
      var $container = $(this),
          imgUrl = $container.find("img").prop("src");
      if (imgUrl) {
        $container.css("backgroundImage", 'url(' + imgUrl + ')').addClass("custom-object-fit");
      }
    });
  } 

})