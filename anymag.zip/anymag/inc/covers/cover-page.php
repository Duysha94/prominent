<?php
  $page_tag = get_the_tags($post->ID);
  if (class_exists('ACF')) {
    $page_descr = get_field('anymag_page_descr');
  }  
?>

<div class="magcover">
    <?php if(get_theme_mod('anymag_turn_left', true)) : ?><div class="turn-left"></div><?php endif; ?>
    <div class="fold-shadow-left"></div>
    <div class="cover-wrap">
      <div class="cover-content">
        <?php get_template_part('inc/headers/header-cover'); ?>
        <div class="overlay"></div>
          <?php 
           $thumbnail1 = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "anymag-post" );
           $thumbnail2 = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "anymag-thumb" );
          ?>
         <div class="video-overlay">
          <div class="cover-image" data-interlace-src="<?php echo esc_url($thumbnail1[0]); ?>" data-interlace-low="<?php echo esc_url($thumbnail2[0]); ?>" data-interlace-alt="<?php echo get_option('blogdescription'); ?>"> 
             <?php get_video_thumbnail('archive'); ?>
          </div> 
         </div>   
        <div class="single-post-image" data-interlace-src="<?php echo esc_url($thumbnail1[0]); ?>" data-interlace-low="<?php echo esc_url($thumbnail2[0]); ?>"data-interlace-alt="<?php the_title(); ?>"> </div> 

        <?php if (is_front_page() || $page_tag) :?>
           <div class="cover-sidebar-left">
              <div class="cover-widgets">
                <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Cover Sidebar Left') ) ?>
              </div> 
            </div>
            <div class="cover-sidebar-right">
              <div class="cover-widgets">
                <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Cover Sidebar Right') ) ?>
                  <?php if(get_theme_mod('anymag_home_nav') == true) : ?> 
                    <?php get_template_part('inc/templates/home-nav'); ?>
                  <?php endif; ?>

              </div> 
            </div>  
        <?php endif; ?> 
          <?php if ($page_descr) :?>
            <div class="category-descr">
              <p><?php echo esc_html($page_descr) ?></p>
            </div>  
          <?php endif; ?> 
      </div>
    </div>
</div>