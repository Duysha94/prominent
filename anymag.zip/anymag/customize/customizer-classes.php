<?php

//Heading
class WP_Customize_Heading_Control extends WP_Customize_Control {
  public $type = 'heading';
    public function  render_content()
    {
    ?>
      <div class="customizer-heading"><h3><?php echo esc_html( $this->label )?></h3></div>
    <?php
    }
}

//Layout
class WP_Customize_Layout_Control extends WP_Customize_Control {
public $type = 'layout';
public function  render_content() {
  if (empty( $this->choices))
  return;
  ?>
    <div class="customize-control-<?php echo esc_html( $this->type ); ?> ">
        <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
        <?php foreach ($this->choices as $value => $label) { ?>
        <?php $selected = $this->value(); ?>
        <label <?php echo esc_attr($value == $selected) ? 'class="selected"' : ''; ?> >
         <input type="radio" name="anymag_<?php echo esc_attr( $this->type ); ?>" value="<?php echo esc_attr($value); ?>" data-id="<?php echo esc_attr($this->id); ?>"
            <?php echo esc_attr($selected == $value) ? 'checked="checked"' : ''; ?>>
            <img src="<?php echo esc_attr($label); ?>" alt="<?php echo esc_attr__('Layout','anymag'); ?>" />
          <?php  ?>
        </label>
      <?php } ?>
    </div>
  <?php }
}

//Slider
class WP_Customize_Slider_Control extends WP_Customize_Control {
  public $type = 'slider';
  public function  render_content() {
    if (empty( $this->choices))
    return;
    $setting = $this->choices;
    ?>
    <label>
      <div class="customize-control-<?php echo esc_html($this->type); ?> ">
        <span class="customize-control-title"><?php echo esc_html($this->label); ?></span>
        <label>
          <div class="custom-slider-range"  data-max="<?php echo esc_attr($setting['max']);?>" data-min="<?php echo esc_attr($setting['min']);?>" data-step="<?php echo esc_attr( $setting['step'] );?>"></div>
          <input type="text" class="custom-slider-range-input" name="custom_<?php echo esc_attr( $this->type ); ?>" value="<?php echo esc_attr(intval($this->value())); ?>" data-id="<?php echo esc_attr($this->id); ?>" />
        </label>
      </div>
    </label>
  <?php }
}

//Toggle
class WP_Customize_Toggle_Control extends WP_Customize_Control {
public $type = 'toggle';
public function  render_content() {
  ?>
  <label>
    <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
    <div class="customize-control-<?php echo esc_html( $this->type ); ?>-checkbox ">
      <input type="checkbox" class="custom-toggle" id="<?php echo esc_attr( $this->id ); ?>-checkbox" value="1"
      <?php $this->link(); checked( $this->value(), 1 ); ?> />
      <label for="<?php echo esc_attr( $this->id ); ?>-checkbox"></label>
    </div>
  </label>
  <?php }
}

//Info
class WP_Customize_Info_Control extends WP_Customize_Control {
  public $type = 'info';
    public function  render_content()
    {
      ?> 
      <div class="custom-info-custom">
        <p><span><?php echo esc_html( $this->label ); ?></span><?php echo esc_html( $this->description ); ?></p> 
      </div>
  <?php }
}

//Multiple
class WP_Customize_Multiple_Control extends WP_Customize_Control {
public $type = 'multiple';
public function  render_content() {
if ( empty( $this->choices ) )
return;
?>
<label>
    <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
    <select <?php $this->link(); ?> multiple="multiple">
      <?php
      foreach ( $this->choices as $value => $label ) {
          $selected = ( in_array( $value, $this->value() ) ) ? selected( 1, 1, false ) : '';
          echo '<option value="' . esc_attr( $value ) . '"' . esc_attr($selected) . '>' . esc_html($label) . '</option>';
      }
      ?>
    </select>
</label>
<?php }
}

//Category Dropdown
class WP_Customize_Catdrop_Control extends WP_Customize_Control {

    public function render_content() {
        $dropdown = wp_dropdown_categories(
            array(
              'orderby'           => 'name',
                'name'              => '_customize-dropdown-categories-' . $this->id,
                'echo'              => 0,
                'show_count'        => 1,
                'hierarchical'      => 1,
                'show_option_none'  => __( '&mdash; Select &mdash;', 'anymag' ),
                'option_none_value' => '0',
                'selected'          => $this->value(),
            )
        );

        $dropdown = str_replace( '<select', '<select ' . $this->get_link(), $dropdown );

        printf(
            '<label class="customize-control-select"><span class="customize-control-title">%s</span> %s</label>',
            $this->label,
            $dropdown
        );
    }
}

?>