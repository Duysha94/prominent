<?php

require_once( ABSPATH . WPINC . '/class-wp-customize-control.php' );
require_once(get_template_directory() . '/customize/customize-controller.php');
require_once(get_template_directory() .'/customize/customizer-classes.php');

$anymag_customize = anymag_Customize::getInstance();
$anymag_customize->init();

