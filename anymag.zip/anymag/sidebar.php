<aside class="sidebar main-sidebar">
	<div class="sidebar-container">
    <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Main Sidebar')) ?>            
  </div> 
</aside>