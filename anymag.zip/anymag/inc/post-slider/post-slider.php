<?php
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
if( $paged == 1 ) :
?>
<div class="slider-area">
			
	<div id="home-slider" class="featured-carousel owl-carousel">
	
			<?php
				
				$featured_cat = get_theme_mod( 'anymag_featured_cat' );
				$get_featured_posts = get_theme_mod('anymag_featured_id');
				$number = get_theme_mod( 'anymag_slides_number' );
				$anymag_allow_html = array('i' => array());
        $autoplay = get_theme_mod( 'anymag_autoplay_slider' );
          if($autoplay != '1'){
            $autoplay = 'false';
          }

				if($get_featured_posts) {
					$featured_posts = explode(',', $get_featured_posts);
					$args = array( 'showposts' => $number, 
						             'post_type' => array('post', 'page'), 
						             'post__in' => $featured_posts, 
						             'orderby' => 'post__in',
						             'ignore_sticky_posts' => 1 
						            );
				} else {
					$args = array( 'cat' => $featured_cat, 
						             'showposts' => $number,
						             'post_type'  => 'post',
						             'ignore_sticky_posts' => 1 
						           );
				}
				
				$owl_custom = 'jQuery(document).ready(function($){
				"use strict";
					setTimeout(function(){
					var owl = $("#home-slider").owlCarousel(
				    {
					    center: false,
					    items: 1,
			        autoplay: '.$autoplay.',
			        autoplayTimeout: 5000,
              autoplayHoverPause: true,
			        singleItem: false,
              loop: true,
              margin: 1,
              nav: true,
              navText : ["<i class=\'fas fa-arrow-left\'></i>","<i class=\'fas fa-arrow-right\'></i>"],
						  responsive: { 280:{items: 1}, 500:{items: 1 }, 600:{items: 1}, 700:{items: 1}, 768:{items: 1}, 800:{items: 1} },
			        themeClass: "owl-post-slider",';
				    $owl_custom .= '});';
          $owl_custom .= '}, 100);
  			});';
			wp_add_inline_script('anymag-scripts', $owl_custom);
			?>
			
			<?php $feat_query = new WP_Query( $args ); ?>
		
			<?php if ($feat_query->have_posts()) : while ($feat_query->have_posts()) : $feat_query->the_post(); ?>


			<?php 
				
				// Get slider image
				if(get_post_meta( get_the_ID(), 'meta-image', true )) :
				
					$feat_image = get_post_meta( get_the_ID(), 'meta-image', true );
					
				else :
				
					if(has_post_thumbnail()) {
						$get_feat_image = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'anymag-slide' );
						$feat_image = $get_feat_image[0];
					} else {
						$feat_image = get_template_directory_uri() . '/assets/img/slider-default.png';
					}
				
				endif;
			
			?>
			
			<div class="slide-item">
				<div class="post-overlay"></div>
   				<div class="slide-content" style="background-image:url(<?php echo esc_url($feat_image); ?>)">
				  	<div class="slide-text">
				  		<?php if(get_theme_mod('anymag_slider_categ', true)) : ?>
					  		<div class="post-categs-box slider-meta">
							  	 <span class="categ"><?php the_category(' '); ?></span>
							  </div> 
						  <?php endif; ?> 
			        <div class="slide-title <?php if (get_theme_mod('anymag_hover_style', true) == 'hover-underline'):?>underline<?php endif; ?>">
						  	<h3><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h3>
             </div>
     		     <ul class="post-meta">
		          <?php if(get_theme_mod('anymag_slider_author', true)) : ?>
		            <?php if(get_theme_mod('anymag_slider_avatar')) : ?>
		             <div class="author-avatar"><?php echo get_avatar( get_the_author_meta( 'ID' ), 30 ); ?></div>
		            <?php endif; ?> 
		            <li class="post-author">
		              <span class="author"><?php the_author_posts_link(); ?></span>
		            </li>
		          <?php endif; ?>  
		          <?php if(get_theme_mod('anymag_slider_date', true)) : ?>
		          <li class="list-date">
		            <span class="post-date date updated published"><?php the_time( get_option('date_format') ); ?></span>
		          </li>
		          <?php endif; ?> 
		        </ul>
					</div>
         </div>
      </div>
			
			<?php endwhile; endif; ?>
			
	</div>
	
</div>
<?php endif; ?> <!-- #if paged -->