<?php
$page_logo = '';
  if (class_exists('ACF')) {
    $page_logo = get_field('page_logo');
    $post_logo = get_field('post_logo');
    if ($post_logo) {
      $post_logo = $post_logo['sizes']['anymag-post'];
    }
    if ($page_logo) {
      $page_logo = $page_logo['sizes']['anymag-post'];
    }  
  }  
?>

<header id="cover-header">

  <div class="top-menu-button">
    <a href="#" class="open-hidden-menu" aria-label="Main Menu">
      <span class="bar-1"></span>
      <span class="bar-2"></span>
      <span class="bar-3"></span>
    </a>
  </div>

  <div class="cover-logo<?php if (get_theme_mod('anymag_logo_position') === 'logo-left'):?> logo-left<?php endif;?> <?php if(get_theme_mod('anymag_hide_home_logo') && is_front_page()):?> hide-logo<?php endif;?>">
   <?php if (get_theme_mod( 'anymag_cover_logo' ) && !$page_logo ) : ?>
     <a href="<?php echo esc_url(home_url()); ?>/"><img src="<?php  echo esc_url(get_theme_mod('anymag_cover_logo')); ?>" alt="<?php bloginfo( 'name' ); ?>" /></a>
      <?php elseif ($page_logo) : ?>
     <a href="<?php echo esc_url(home_url()); ?>/"><img src="<?php echo esc_html($page_logo); ?>" alt="<?php bloginfo( 'name' ); ?>" /></a>
   <?php else : ?>
     <a href="<?php echo esc_url(home_url()); ?>/"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/cover-logo.png" alt="<?php bloginfo( 'name' ); ?>" /></a>
   <?php endif; ?>  
  </div>

  <div class="nav-panel">
    <div class="fold-shadow-left"></div>
    <div class="nav-header">
      <div class="menu-logo">
       <?php if (get_theme_mod( 'anymag_menu_logo' )) : ?>
         <a href="<?php echo esc_url(home_url()); ?>/"><img src="<?php  echo esc_url(get_theme_mod('anymag_menu_logo')); ?>" alt="<?php bloginfo( 'name' ); ?>" /></a>
       <?php else : ?>
         <a href="<?php echo esc_url(home_url()); ?>/"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/menu-logo.png" alt="<?php bloginfo( 'name' ); ?>" /></a>
       <?php endif; ?>  
      </div>
      <?php if ( class_exists('WooCommerce') ) : ?>
        <div class="wc-shopping-cart">
        <?php $count = WC()->cart->get_cart_contents_count(); ?>
          <a class="cart-contents" href="<?php echo esc_url(wc_get_cart_url()); ?>" title="<?php esc_attr_e( 'View your shopping cart', 'anymag' ); ?>"><i class="fas fa-shopping-cart"></i><?php if ( $count >= 0 ) echo '<span class="cart-count">' . $count . '</span>'; ?>
          </a>
        </div>
      <?php endif; ?>
    </div>
    
    <div id="nav-wrapper" data-simplebar>
    <?php
      if (has_nav_menu('header-menu')) :
       wp_nav_menu( array( '
        container' => '', 
        'theme_location' => 'header-menu', 
        'menu_class' => 'nav-menu'
       ) ); 
     endif;
     ?>
    <div class="menu-search">
      <?php if (get_theme_mod('anymag_topbar_search', true)) : ?>
        <div class="site-search">
          <div id="top-search">
           <a href="#" class="search"><i class="fas fa-search"></i><?php esc_html_e('Search', 'anymag')?></a>
          </div>
        </div> 
      <?php endif; ?>
      </div>
    </div>
  </div>

</header>