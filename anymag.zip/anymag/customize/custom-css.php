<?php
if(!function_exists('anymag_minify')) {
    function anymag_minify( $minify ) {
       /* remove comments */
      $minify = preg_replace( '!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $minify );
      /* remove tabs, spaces, newlines, etc. */
      $minify = str_replace( array("\r\n", "\r", "\n", "\t", '; ', '  ', '    ', '    ',': ', ', ','{ ','}.'), array('','','','',';','','','',':',',','{','} .'), $minify );
      return $minify;
    }
}

/* Convert hexdec color string to rgb(a) string */
 
function hex2rgba($color, $opacity = false) {
 
  $default = 'rgb(0,0,0)';
 
  //Return default if no color provided
  if(empty($color))
    return $default; 

   //Sanitize $color if "#" is provided 
    if ($color[0] == '#' ) {
      $color = substr( $color, 1 );
    }

    //Check if color has 6 or 3 characters and get values
    if (strlen($color) == 6) {
            $hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
    } elseif ( strlen( $color ) == 3 ) {
            $hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
    } else {
            return $default;
    }

    //Convert hexadec to rgb
    $rgb =  array_map('hexdec', $hex);

    //Check if opacity is set(rgba or rgb)
    if($opacity){
      if(abs($opacity) > 1)
        $opacity = 1.0;
      $output = 'rgba('.implode(",",$rgb).','.$opacity.')';
    } else {
      $output = 'rgb('.implode(",",$rgb).')';
    }

    //Return rgb(a) color string
    return $output;
}

function anymag_custom_styles() {
?>
<?php ob_start(); ?>
    
    body,
    input,
    .button,
    .content-part .post-meta,
    .widget_recent_entries span,
    .sidebar ul li.cat-item,
    .list-date,
    .latest-posts-meta,
    .post-meta,
    .slider-list-meta,
    .sidebar .widget_recent_comments .recentcomments .url,
    input, 
    select, 
    textarea {
      font-family: <?php echo esc_attr(get_theme_mod('anymag_main_font', 'Poppins')); ?>; 
    }

    body,
    #hidden-sidebar.active .widgets-side,
    .magcover,
    .post-format,
    #top-bar-right,
    .turn-left {
     background: <?php echo esc_attr(get_theme_mod('anymag_site_bg_color', '#fff')); ?>; 
    } 

    .searchform-overlay {
      background-color: <?php $color = get_theme_mod('anymag_site_bg_color', '#ffffff');
      $rgb = hex2rgba($color);
      $rgba = hex2rgba($color, 0.95);
      echo esc_html($rgba) ?>; 
    }
    
    body p,
    .main-content li,
    .main-content blockquote,
    .post-content li,
    .post-content blockquote {
      font-size: <?php echo esc_attr(get_theme_mod('anymag_font_size', '15')); ?>px; 
      line-height: <?php echo esc_attr(get_theme_mod('anymag_mainfont_line', '1.6')); ?>em;
      letter-spacing: <?php echo esc_attr(get_theme_mod('anymag_mainfont_letterspace', '0')); ?>px; 
    }
    
    h1, h2, h3, h4, h5, h6,
    .widget_recent_entries ul li a,
    .widget_recent_comments ul li a,
    .sidebar .widget-title,
    .post-readmore a,
    .intro-line h1,
    .sidebar .recentcomments a,
    .elementor-image-carousel-caption { 
      font-family: <?php echo esc_attr(get_theme_mod('anymag_title_font', 'Oswald')); ?>; 
      color: <?php echo esc_attr(get_theme_mod('anymag_post_title_color', '#111111')); ?>; 
    }

    a,
    .post-content a,
    .sidebar a,
    .post-comments span.reply a,
    .sidebar .widget a,
    .sidebar .widget.widget_archive li a {
      color: <?php echo esc_attr(get_theme_mod('anymag_link_color', '#111111')); ?>; 
    }

    a:hover,
    .post-content a:hover,
    .sidebar a:hover,
    .post-comments span.reply a:hover,
    .sidebar .widget ul li a:hover,
    .sidebar .widget.widget_archive li a:hover {
      color: <?php echo esc_attr(get_theme_mod('anymag_link_hover', '#999999')); ?>; 
    }

    .post-title,
    .post-title a {
      font-size: <?php echo esc_attr(get_theme_mod('anymag_title_font_size', '26')); ?>px;
      font-weight: <?php echo esc_attr(get_theme_mod('anymag_title_font_weight', '800')); ?>;
      line-height: <?php echo esc_attr(get_theme_mod('anymag_title_line', '1.3')); ?>em;
      letter-spacing: <?php echo esc_attr(get_theme_mod('anymag_title_letterspace', '0')); ?>px; 
    }

    .slide-title,
    .slide-title h2 a,
    .slide-title h3 a {
      font-size: <?php echo esc_attr(get_theme_mod('anymag_slider_font_size', '37')); ?>px;
      font-weight: <?php echo esc_attr(get_theme_mod('anymag_title_font_weight', '800')); ?>;
      letter-spacing: <?php echo esc_attr(get_theme_mod('anymag_title_letterspace', '0')); ?>px; 
    }

    .slide-item {
      height: <?php echo esc_attr(get_theme_mod('anymag_slider_height', '510')); ?>px;
    }

    .page-title,
    .post-header h1,
    .item-related h5 a,
    .entry-title,
    .random-ttl a,
    .feat-categ-item .content-part h5 a,
    .sidebar .widget_recent_entries ul li a,
    .sidebar .widget-content .img-button,
    .sidebar .widget_recent_comments .recentcomments > a,
    .sidebar .latest-posts .latest-posts-item a {
      font-weight: <?php echo esc_attr(get_theme_mod('anymag_title_font_weight', '800')); ?>;
    }

    <?php 
      if(get_theme_mod('anymag_title_upper')) {
        $css = '
        .post-title a, 
        .slide-title h2 a,
        .slide-title h3 a,
        .random-ttl a,
        .feat-title a,
        .item-related h5 a,
        .entry-title,
        .latest-posts-text a,
        .widget_recent_entries { 
          text-transform: uppercase;
        }';
        echo esc_attr( $css,'anymag' );
      }
    ?>

    .top-menu-button,
    #nav-wrapper .simplebar-track.simplebar-vertical {
      background: <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>; 
    }

    #nav-wrapper .simplebar-scrollbar::before {
     background: <?php echo esc_attr(get_theme_mod('anymag_topbar_linkcolor', '#111111')); ?>
    }

    .nav-panel {
      background: <?php echo esc_attr(get_theme_mod('anymag_menu_bg_color', '#f4f4f4')); ?>; 
    }

    #nav-wrapper .nav-menu li a,
    .slicknav_nav li a {
      font-family: <?php echo esc_attr(get_theme_mod('anymag_navigation_font', 'Oswald')); ?>; 
      font-size: <?php echo esc_attr(get_theme_mod('anymag_nav_font_size', '33')); ?>px; 
      font-weight: <?php echo esc_attr(get_theme_mod('anymag_nav_font_weight', '800')); ?>;
    }

    .magcover,
    .f-width #site-header {
      width: <?php echo esc_attr(get_theme_mod('anymag_cover_width', '50')); ?>%; 
    }

    .magcontent,
    .f-width.nav-open #footer {
      width: <?php 
      $mcwidth = 100 - get_theme_mod('anymag_cover_width', '50');
      echo esc_attr ($mcwidth); ?>%;
    }
    
    .magheader {
      width: <?php echo esc_attr ($mcwidth); ?>%;
    }

    .f-width.nav-open #main-area {
      margin-left: <?php echo esc_attr(get_theme_mod('anymag_cover_width', '50')); ?>%; 
    }

    .cover-logo {
      width: <?php echo esc_attr(get_theme_mod('anymag_logo_width', '80')); ?>%;
    }
    .single .cover-logo {
      width: <?php echo esc_attr(get_theme_mod('anymag_sp_logo_width', '80')); ?>%; 
    }
    
    .magcover .overlay,
    .magcover .post-overlay {
      opacity: .<?php echo esc_attr(get_theme_mod('anymag_overlay_opacity', '3')); ?>;
      background: <?php echo esc_attr(get_theme_mod('anymag_overlay_color', '#000000')); ?>
    }

    .single-post .magcover .overlay {
      opacity: .<?php echo esc_attr(get_theme_mod('anymag_single_overlay_opacity', '3')); ?>;
      background: <?php echo esc_attr(get_theme_mod('anymag_overlay_color', '#000000')); ?>
    }

    .fold-shadow-right,
    .fold-shadow-left,
    .fold-shadow {
      opacity: .<?php echo esc_attr(get_theme_mod('anymag_shadow_opacity', '0')); ?>
    }

    .nav-panel .fold-shadow-left {
      opacity: .<?php echo esc_attr(get_theme_mod('anymag_nav_shadow_opacity', '0')); ?>
    }

    #nav-wrapper .nav-menu li a,
    .sub-menu-toggle::after,
    #nav-wrapper ul.nav-menu ul a,
    .slicknav_nav a,
    #top-search a.search {          
      color: <?php echo esc_attr(get_theme_mod('anymag_topbar_linkcolor', '#111111')); ?>; 
    }

    #nav-wrapper .nav-menu li a:hover,
    #nav-wrapper .nav-menu li a:hover:after,
    #topbar-social-links a:hover,
    .slicknav_nav a:hover,
    .sticky-social a:hover,
    .sticky-subscribe a:hover,
    .nav-panel .current-menu-item > a {          
      color: <?php echo esc_attr(get_theme_mod('anymag_topbar_linkhover', '#fff')); ?>!important; 
    }
    
    #nav-wrapper .nav-menu li a {
      background: linear-gradient(to bottom, transparent 62%, <?php echo esc_attr(get_theme_mod('anymag_topbar_linkhover_bg', '#ff027f')); ?> 0) left bottom/0 400% no-repeat;
    }

    #nav-wrapper .current-menu-item > a {
      background: <?php echo esc_attr(get_theme_mod('anymag_topbar_linkhover_bg', '#ff027f')); ?>!important;
    }

    body,
    .post-list-entry p, 
    .post-entry .post-meta li,
    .post-content,
    .post-author,
    .thecomment p,
    .latest-posts-meta,
    #post-navigation span,
    .sidebar .widget_recent_comments ul,
    .widget_meta li a,
    .about-content,
    .sidebar .widget_recent_comments .recentcomments .url,
    .comment-text .date,
    .post-navigation span,
    .searchform-overlay p,
    .searchform-overlay .search-field,
    .searchform-overlay .search-button,
    input, 
    select, 
    .hidden-sidebar-button a.open-hidden-sidebar,
    textarea {
      color: <?php echo esc_attr(get_theme_mod('anymag_post_text_color', '#787878')); ?>; 
    }

    .post-content h1, 
    .post-content h2, 
    .post-content h3, 
    .post-content h4, 
    .post-content h5, 
    .post-content h6,
    .post-content blockquote,
    .comment-text blockquote,
    blockquote::before,
    .post-title, 
    .post-title a,
    .about-title,
    .page-title, 
    .post-header h1,
    .random-ttl a,
    .feat-title a,
    .item-related h5 a,
    .about-title,
    .about-content h5,
    .entry-title,
    .post-readmore a,
    .category-box h1,
    #post-navigation h6,
    .header-social-links a,
    .postnav-noimage .navprev::after,
    .postnav-noimage .navnext::after,
    .sidebar .widget-title,
    .sidebar .latest-posts-text h4 a,
    .sidebar .widget_recent_entries a,
    .sidebar .recentcomments a,
    .sidebar .widget-content .img-button,
    .thecomment .comment-text h6.author,
    .thecomment .comment-text h6.author a,
    .archive-box span,
    #respond h,
    label {
    color: <?php echo esc_attr(get_theme_mod('anymag_post_title_color', '#111111')); ?>; 
    } 
    
    .post-title:hover, 
    .post-title a:hover,
    .random-ttl a:hover,
    .feat-title a:hover,
    .post-readmore a:hover,
    .item-related h5 a:hover,
    .post-navigation a:hover h6, 
    .sidebar .latest-posts .latest-posts-text h4 a:hover,
    .sidebar .widget_recent_entries ul li a:hover,
    .sidebar #recentcomments li a:hover,
    .header-social-links a:hover {
      color: <?php echo esc_attr(get_theme_mod('anymag_post_title_hover', '#999999')); ?>; 
    }

    .post-item .image-part,
    .owl-stage-outer,
    .random-image,
    .feat-categ-item .image-part,
    .category-wid .category-img,
    .about-img  {
      border-radius: <?php echo esc_attr(get_theme_mod('anymag_img_border_radius', '0')); ?>px;
    }
    .post-item .image-part,
    .post-list .post-item .image-part {
      height: <?php echo esc_attr(get_theme_mod('anymag_img_height', '300')); ?>px;
    }
    .entry-title {
      font-size: <?php echo esc_attr(get_theme_mod('anymag_post_title_font_size', '67')); ?>px; 
      line-height: <?php echo esc_attr(get_theme_mod('anymag_single_title_line', '1.1')); ?>em;
      letter-spacing: <?php echo esc_attr(get_theme_mod('anymag_single_title_letterspace', '0')); ?>px;
    }

    .underline a {
      background: linear-gradient(to bottom, transparent 62%, <?php echo esc_attr(get_theme_mod('anymag_post_title_underline', '#ff027f')); ?> 0) left bottom/0 20% no-repeat;
    }

    .section-title h2,
    .author-content {
      border-left: 3px solid <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>;
    }

    content-part .post-meta, 
    .content-part .post-meta a,
    .post-meta li,
    .post-meta li span,
    .post-entry .post-meta a,
    .widget-date {
      color: <?php echo esc_attr( get_theme_mod('anymag_postmeta_color', '#111111')); ?>; 
    }
    
    ul.post-meta li:not(:last-child)::after {
      background: <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>; 
    }

    .content-part .post-meta a:hover,
    .sidebar .widget .tagcloud a:hover,
    .post-tags a:hover,
    .post-entry .post-meta a:hover {
      color: <?php echo esc_attr(get_theme_mod('anymag_postmeta_hover', '#999999')); ?>; 
    }

    .owl-prev:hover i,
    .owl-next:hover i,
    .widget li > .narrow i,
    .error404 h1 span,
    .intro-line h1 i, .intro-line h1 b, .intro-line h1 em, .intro-line h1 strong {
      color: <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>; 
    }

    .post-categs-box .categ a,
    .single-categs-box .categ a {
      background: <?php echo esc_attr(get_theme_mod('anymag_categ_backgr_color', '#ff027f')); ?>; 
    }

    .post-categs .categ a,
    .single-categs .categ a,
    .sidebar ul li.cat-item a,
    .sidebar ul li.cat-item a:hover {
      color: <?php echo esc_attr(get_theme_mod('anymag_categ_backgr_color', '#ff027f')); ?>; 
    }

    blockquote {
      border-left: 3px solid <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>;
    }

    .category-box h1 {
      border-left: 5px solid <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>;
    }

    .post-format {
      color: <?php echo esc_attr(get_theme_mod('anymag_categ_backgr_color', '#ff027f')); ?>;
    }

    .post-tags a,
    .sidebar .widget .tagcloud a {
      background: <?php echo esc_attr(get_theme_mod('anymag_tag_background_color', '#f2f2f2')); ?>!important;
      color: <?php echo esc_attr(get_theme_mod('anymag_tag_text_color', '#787878')); ?>!important;
    }

    .post-readmore i,
    .post-comments .reply i {
      color: <?php echo esc_attr(get_theme_mod('anymag_button_color', '#ff027f')); ?>!important;
    }
    
    .related-posts-cover-title h4 {
      border-bottom: 3px solid <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>;
    }

    .sidebar .widget-title,
    .random-posts-title h3 {
      border-left: 3px solid <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>;
    }
    
    .wp-block-search button,
    input[type='submit'],
    input.button,
    [type='radio']:checked + label:after,
    [type='radio']:not(:checked) + label:after {
      font-family: <?php echo esc_attr(get_theme_mod('anymag_title_font', 'Oswald')); ?>; 
      background: <?php echo esc_attr(get_theme_mod('anymag_button_color', '#ff027f')); ?>!important;
      color: <?php echo esc_attr(get_theme_mod('anymag_button_text_color', '#fff')); ?>!important;
    }
    
    .wp-block-search button:hover,
    input[type="submit"]:hover,
    input.button:hover {
      background: <?php echo esc_attr(get_theme_mod('anymag_button_hover_color', '#ff52a7')); ?>!important;
      color: <?php echo esc_attr(get_theme_mod('anymag_button_text_hover', '#ffffff')); ?>!important;
    }

    .wp-block-button a.wp-block-button__link {
      background-color: <?php echo esc_attr(get_theme_mod('anymag_button_color', '#ff027f')); ?>;
      color: <?php echo esc_attr(get_theme_mod('anymag_button_text_color', '#ffffff')); ?>;
      border: 2px solid <?php echo esc_attr(get_theme_mod('anymag_button_color', '#ff027f')); ?>;
    }
    .wp-block-button.is-style-outline a.wp-block-button__link {
      border: 2px solid <?php echo esc_attr(get_theme_mod('anymag_button_color', '#ff027f')); ?>;
    }

    .wp-block-button a.wp-block-button__link:hover,
    .wp-block-button.is-style-outline a.wp-block-button__link:hover {
      background-color: <?php echo esc_attr(get_theme_mod('anymag_button_hover_color', '#ff52a7')); ?>;
      color: <?php echo esc_attr(get_theme_mod('anymag_button_text_hover', '#ffffff')); ?>;
      border: 2px solid <?php echo esc_attr(get_theme_mod('anymag_button_hover_color', '#ff52a7')); ?>;
    }

    .pagination .nav-links .current,
    .pagination-post > span,
    .loadmore.button {
      background: <?php echo esc_attr(get_theme_mod('anymag_pagination_color', '#ff027f')); ?>;
      color: <?php echo esc_attr(get_theme_mod('anymag_pagination_text_color', '#ffffff')); ?>;  
    }

    .navigation.pagination .nav-links a {
      background: <?php echo esc_attr(get_theme_mod('anymag_unactive_pagination_color', '#eeeeee')); ?>;
      color: <?php echo esc_attr(get_theme_mod('anymag_unactive_pagination_text_color', '#787878')); ?>;  
    }

    .navigation.pagination .nav-links a:hover,
    .loadmore.button:hover {
      background: <?php echo esc_attr(get_theme_mod('anymag_unactive_pagination_color_hover', '#e8e8e8')); ?>;
      color: <?php echo esc_attr(get_theme_mod('anymag_unactive_pagination_text_color_hover', '#111111')); ?>;  
    }

    .intro-line {
      width: <?php echo esc_attr(get_theme_mod('anymag_intro_line_width', '60')); ?>%; 
    }
    .intro-line h1 {
      font-size: <?php echo esc_attr(get_theme_mod('anymag_intro_line_font_size', '26')); ?>px;
    }
    
    #footer {
      background: <?php echo esc_attr(get_theme_mod('anymag_footer_bg', '#fafafa')); ?>; 
    }

    #footer, #footer-copyright {
      color: <?php echo esc_attr(get_theme_mod('anymag_footer_text', '#989898')); ?>; 
    }

    #footer a {
      color: <?php echo esc_attr(get_theme_mod('anymag_footer_links', '#111111')); ?>; 
    }
    
    #footer a:hover {
      color: <?php echo esc_attr(get_theme_mod('anymag_footer_hover', '#989898')); ?>!important; 
    }
    .video-wrapper {
     transform: scale(1.<?php echo esc_attr(get_theme_mod('anymag_video_scale', '9')); ?>);
    }



<?php if( class_exists('WooCommerce') ) {  ?>

    .single-product.woocommerce #site-header {
      width: <?php echo esc_attr(get_theme_mod('anymag_cover_width', '50')); ?>%; 
    }

    .woocommerce ul.product_list_widget li a,
    .woocommerce .comment-respond .comment-reply-title,
    .woocommerce table.shop_table td.product-name a,
    .woocommerce ul.product_list_widget li a,
    .woocommerce .comment-respond .comment-reply-title, 
    .woocommerce table.shop_table td.product-name { 
      font-family: <?php echo esc_attr(get_theme_mod('anymag_title_font', 'Oswald')); ?>; 
    }

    .woocommerce table.shop_table td.product-name a,
    .woocommerce-checkout label,
    .woocommerce table.shop_table td.product-name,
    .woocommerce table.shop_table tfoot td,
    .woocommerce-cart table.shop_table td.product-subtotal .amount,
    .woocommerce-Price-amount .amount,
    .order-total .amount,
    .woocommerce form .form-row label,
    .woocommerce-MyAccount-navigation-link a  {
      color: <?php echo esc_attr(get_theme_mod('anymag_post_title_color', '#111111')); ?>; 
    }

    .woocommerce-MyAccount-navigation-link .is-active a {
       color: <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>!important;
    }

    .woocommerce ul.products li.product .price, 
    .woocommerce div.product p.price,
    .woocommerce .product-remove a.remove,
    .cart-subtotal .amount,
    .cart-contents i {
      color: <?php echo esc_attr(get_theme_mod('anymag_post_text_color', '#111111')); ?>!important; 
    }

    .woocommerce .product-item .product-image  {
      border-radius: <?php echo esc_attr(get_theme_mod('anymag_img_border_radius', '0')); ?>px;
    }

    .cart-contents .cart-count,
    .woocommerce span.onsale {
      background: <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>!important;
    }
    
    .woocommerce ul.products li.product .button:hover,
    .woocommerce div.product form.cart .button:hover {
      background: <?php echo esc_attr(get_theme_mod('anymag_button_hover_color', '#ff52a7')); ?>!important; 
      color: <?php echo esc_attr(get_theme_mod('anymag_button_text_hover', '#ffffff')); ?>!important; 
    }

    .woocommerce .star-rating {
      color: <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>!important;
    }

    .woocommerce .widget_price_filter .ui-slider .ui-slider-handle {
      background-color: <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>!important;
    }

    .woocommerce-page.woocommerce ul.products li.product .button,
    .woocommerce-page.woocommerce-cart .wc-proceed-to-checkout a.checkout-button,
    .woocommerce-page.woocommerce div.product form.cart .button,
    .woocommerce #payment #place_order,
    .woocommerce a.button {
      background: <?php echo esc_attr(get_theme_mod('anymag_button_color', '#ff027f')); ?>!important;
      border: 1px solid <?php echo esc_attr(get_theme_mod('anymag_button_color', '#ff027f')); ?>!important;
      color: <?php echo esc_attr(get_theme_mod('anymag_button_text_color', '#fff')); ?>!important;
    }

    .woocommerce a.button:hover,
    .woocommerce #respond input#submit.alt:hover,
    .woocommerce a.button.alt:hover,
    .woocommerce button.button.alt:hover,
    .woocommerce input.button.alt:hover,
    .woocommerce-page.woocommerce ul.products li.product .button:hover,
    .woocommerce button.button:hover {
      background: <?php echo esc_attr(get_theme_mod('anymag_button_hover_color', '#ff52a7')); ?>!important; 
      border: 1px solid <?php echo esc_attr(get_theme_mod('anymag_button_hover_color', '#ff52a7')); ?>!important;  
      color: <?php echo esc_attr(get_theme_mod('anymag_button_text_color', '#ffffff')); ?>!important; 
    }

    .woocommerce-page .woocommerce a.button, 
    .woocommerce-page .woocommerce button.button, 
    .woocommerce-page .woocommerce input.button {
      border: 1px solid <?php echo esc_attr(get_theme_mod('anymag_button_color', '#ff52a7')); ?>!important;  
    }

    .woocommerce .product-title a,
    .woocommerce .loop-product-title a h6,
    .woocommerce div.product .product_title,
    .woocommerce-MyAccount-navigation-link a {
      color: <?php echo esc_attr(get_theme_mod('anymag_post_title_color', '#111111')); ?>; 
    } 
    
    .woocommerce .product-title a:hover,
    .woocommerce .loop-product-title a h6:hover,
    .woocommerce .product-name a:hover
    .woocommerce-MyAccount-navigation-link a:hover {
      color: <?php echo esc_attr(get_theme_mod('anymag_post_title_hover', '#999999')); ?>; 
    } 

    .woocommerce button, 
    .woocommerce .cart .button, 
    .woocommerce .cart input.button,
    .woocommerce .comment-reply-title {
      font-family: <?php echo esc_attr(get_theme_mod('anymag_main_font', 'Poppins')); ?>!important; 
    }

    .woocommerce div.product .woocommerce-tabs ul.tabs li.active {
      border-bottom: 3px solid <?php echo esc_attr(get_theme_mod('anymag_button_color', '#ff027f')); ?>!important; 
    }

    .select2-container--default .select2-selection--single .select2-selection__rendered,
    .woocommerce-info,
    .woocommerce table.shop_table th,
    .woocommerce div.product .woocommerce-tabs ul.tabs li a {
      color: <?php echo esc_attr(get_theme_mod('anymag_post_text_color', '#787878')); ?>!important; 
    }

    .woocommerce-message::before, 
    .woocommerce-error::before, 
    .woocommerce-info::before {
      color: <?php echo esc_attr(get_theme_mod('anymag_button_color', '#ff027f')); ?>!important;
    }

    .woocommerce table.shop_table th,
    .woocommerce-tabs ul.tabs li.active a,
    .woocommerce div.product .woocommerce-tabs ul.tabs li.active a {
      color: <?php echo esc_attr(get_theme_mod('anymag_post_title_color', '#111111')); ?>!important; 
    }

    .select2-container--default,
    .select2-selection--single,
    .select2-selection__rendered,
    select2-dropdown,
    .select2-dropdown--below {
      background: <?php echo esc_attr(get_theme_mod('anymag_site_bg_color', '#fff')); ?>!important; 
    }

    .woocommerce nav.woocommerce-pagination ul li span.current {
      background: <?php echo esc_attr(get_theme_mod('anymag_pagination_color', '#ff027f')); ?>!important;
      color: <?php echo esc_attr(get_theme_mod('anymag_pagination_text_color', '#ffffff')); ?>!important;  
    }

    .woocommerce nav.woocommerce-pagination ul li a {
      background: <?php echo esc_attr(get_theme_mod('anymag_unactive_pagination_color', '#eeeeee')); ?>!important;
      color: <?php echo esc_attr(get_theme_mod('anymag_unactive_pagination_text_color', '#787878')); ?>!important;
    }

    .woocommerce nav.woocommerce-pagination ul li a:hover {
      background: <?php echo esc_attr(get_theme_mod('anymag_unactive_pagination_color_hover', '#e8e8e8')); ?>!important;
      color: <?php echo esc_attr(get_theme_mod('anymag_unactive_pagination_text_color_hover', '#111111')); ?>!important;  
    } 
    <?php 
      if(get_theme_mod('anymag_woo_sidebar')) {
        $css = '
        .woocommerce-page aside.sidebar {
          display: none;
        } 
        .woocommerce-page #main-area {
          width: 100%;
        } ';
        echo esc_attr( $css,'anymag' );
      }
    ?> 

<?php 
}

$out=ob_get_contents(); $out = anymag_minify($out); ob_end_clean();
wp_add_inline_style('anymag-main', $out);

}

add_action( 'wp_enqueue_scripts', 'anymag_custom_styles' );

?>