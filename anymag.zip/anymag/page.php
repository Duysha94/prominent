<?php get_header(); ?>

	<div class="container site-content">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	  	<?php get_template_part('content', 'page'); ?>
	  	<?php endwhile; ?>
    <?php endif; ?>
 	</div>

<?php get_footer(); ?>