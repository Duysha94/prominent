<?php

use ElementorPro\Modules\ThemeBuilder\Module as Theme_Builder_Module;
use Elementor\Core\Responsive\Responsive;

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

class ElementorHelper {

	private static $instance = null;
	public static function get_instance() {

		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	private function __construct() {
		add_action( 'elementor/theme/register_locations', [ __CLASS__, 'register_locations' ] );
	}

	/** Register locations */
	public static function register_locations( $elementor_theme_manager ) {
		
		$elementor_theme_manager->register_all_core_location();

		$elementor_theme_manager->register_location(
			'page-title-location',
			[
				'label' => esc_html__( 'Page Title', 'anymag' ),
				'multiple' => true,
				'edit_in_content' => true,
			]
		);
	}

	public static function is_elementor_pro_active() {
		if ( is_admin() ) {
			return function_exists('elementor_pro_load_plugin');
		}
		return function_exists( 'elementor_theme_do_location' );
	}

	public static function is_build_with_elementor() {
		if( ! self::is_elementor_active() ) {
			return false;
		}
		global $post;
		if ( ! isset( $post->ID ) ) {
			return false;
		}
		return \Elementor\Plugin::$instance->db->is_built_with_elementor( $post->ID );
	}

	public static function is_elementor_active() {
		return class_exists( '\Elementor\Plugin' );
	}

}
