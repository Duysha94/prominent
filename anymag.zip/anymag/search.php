
<?php get_header(); ?>

    <div class="content-area<?php if (get_theme_mod('anymag_archive_sidebar') && is_active_sidebar('main-sidebar')) : ?> has-sidebar<?php endif; ?>">
    
    <div class="archive-box">
      <?php esc_html_e( 'Search results for:', 'anymag' ); ?>
      <span><?php printf( esc_html__( '%s', 'anymag' ), get_search_query() ); ?></span>
    </div>
    <?php if (have_posts()): ?>
      <div class="posts-area">
        <div class="blog-posts two-fr">
        <?php while (have_posts()) : the_post(); ?>
          <?php get_template_part('content'); ?>
        <?php endwhile; ?>
        </div>   
        <div class="page-nav">
          <?php anymag_pagination_type(); ?>
        </div>
    <?php else : ?>
        <?php get_template_part('content', 'none'); ?>
      <?php endif; ?>
    </div>
    <?php if ( get_theme_mod('anymag_archive_sidebar') && is_active_sidebar('main-sidebar')) : ?>
      <?php get_sidebar(); ?>
    <?php endif; ?>
  
    </div>

<?php get_footer(); ?>