<?php get_header(); ?>

  <div class="content-area<?php if (get_theme_mod('anymag_archive_sidebar') && is_active_sidebar('main-sidebar')) : ?> has-sidebar<?php endif; ?>">
      <?php if(get_theme_mod('anymag_adv_archive') == true) : ?>     
        <?php get_template_part('inc/templates/add-area'); ?>
      <?php endif; ?> 
			
			<div class="category-box">
				<h1>
        <?php the_author(); ?>
				</h1>	
			</div>
			 <div class="posts-area">
        <?php 
          if (get_theme_mod('anymag_categ_layout') == 'categ-list') { $postclass="post-list"; }
          elseif (get_theme_mod('anymag_categ_layout') == 'categ-wide') { $postclass="post-wide"; }
          else { $postclass="two-fr"; }
        ?>

          <div class="blog-posts <?php echo esc_html($postclass) ?>">
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
              <?php get_template_part('content'); ?>
            <?php endwhile; ?>
          </div>  
          <div class="page-nav">
            <?php anymag_pagination_type(); ?>
          </div>
      </div> 
      <?php if ( get_theme_mod('anymag_archive_sidebar') && is_active_sidebar('main-sidebar')) : ?>
        <?php get_sidebar(); ?>
      <?php endif; ?>
      
      <?php else : ?>
        <?php get_template_part('content', 'none'); ?>
      <?php endif; ?>
  </div>



<?php get_footer(); ?>