<div class="magcover">
<div class="fold-shadow-left"></div>
  <div class="cover-wrap">
    <div class="cover-content">
      <?php get_template_part('inc/headers/header-cover'); ?>
      <div class="overlay"></div>
      <?php 
        $value = get_theme_mod('anymag_cover');
        $id = attachment_url_to_postid($value);
        $thumbnail1 = wp_get_attachment_image_src( $id , 'anymag-post' );
        $thumbnail2 = wp_get_attachment_image_src( $id , 'anymag-thumb' );
      ?>
      <div class="video-overlay">
          <div class="cover-image" data-interlace-src="<?php echo esc_url($thumbnail1[0]); ?>" data-interlace-low="<?php echo esc_url($thumbnail2[0]); ?>" data-interlace-alt="<?php echo get_option('blogdescription'); ?>"> 
            <?php if (get_theme_mod('anymag_video_url')) : ?>
             <?php get_video_thumbnail(); ?>
            <?php endif; ?> 
         </div> 
      </div>

      <div class="cover-sidebar-left">
        <div class="cover-widgets">
          <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Cover Sidebar Left') ) ?>
        </div> 
      </div>
      <div class="cover-sidebar-right">
        <div class="cover-widgets">
          <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Cover Sidebar Right') ) ?>
          <?php if(get_theme_mod('anymag_home_nav') == true) : ?> 
            <?php get_template_part('inc/templates/home-nav'); ?>
          <?php endif; ?>   
        </div>
      </div>   
    </div> 
  </div>  
</div>