<?php

if( !function_exists('wp_body_open') ){
  function wp_body_open() {
    return false;
  }
}

// Google Font
//--------------------------------------------------------------------------*/
if(!function_exists('anymag_googlefonts')){
    function anymag_googlefonts(){
      global $wp_filesystem;
      $filepath = get_template_directory().'/assets/googlefont/googlefont.json';
      if( empty( $wp_filesystem ) ) {
        require_once( ABSPATH .'/wp-admin/includes/file.php' );
        WP_Filesystem();
      }
      if( $wp_filesystem ) {
        $listGoogleFont=$wp_filesystem->get_contents($filepath);
      }
      if($listGoogleFont){
        $gfont = json_decode($listGoogleFont);
        $fontarray = $gfont->items;
        $options = array();
        foreach($fontarray as $font){
          $options[$font->family] = $font->family;
        }
          return $options;
      }
      return false;
    }
}

// Allow HTML
//--------------------------------------------------------------------------*/
$anymag_allow_html = array(
  'a' => array(
    'href' => array(),
    'title' => array()
  ),
  'br' => array(),
  'em' => array(),
  'strong' => array(),
  'b' => array(),
  'i' => array(),
);

// Theme Option
//--------------------------------------------------------------------------*/

if ( ! function_exists( 'anymag_option' ) ) :
function anymag_option($id, $default = false) {
  if (!$id) { return; }
  return get_theme_mod($id, $default);
}
endif;

// Excerpt
//--------------------------------------------------------------------------*/

function anymag_excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt).'...';
  } else {
    $excerpt = implode(" ",$excerpt);
  } 
  $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
  return $excerpt;
}

//Comments Layout
//--------------------------------------------------------------------------*/
function anymag_comment_form($arg,$class='btn-variant',$id='submit'){
    ob_start();
    comment_form($arg);
    $form = ob_get_clean();
    echo str_replace('id="submit"','id="'.$id.'"', $form);
}

function anymag_list_comments($comment, $args, $depth){
    $path = get_template_directory() . '/inc/templates/list_comments.php';
    if( is_file($path) ) require ($path);
}

function anymag_enqueue_comments_reply() {
    if( get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'comment_form_before', 'anymag_enqueue_comments_reply' );

// Twitter Ampersand Decode
//--------------------------------------------------------------------------*/
if ( !function_exists('anymag_social_title') ) {
function anymag_social_title( $title ) {
    $title = html_entity_decode( $title );
    $title = urlencode( $title );
    return $title;
  }
}

// Video Thumbnails
//--------------------------------------------------------------------------*/
if ( ! function_exists('get_youtube_video_id')) {
  function get_youtube_video_id( $url ) {
    preg_match( '/(http(s|):|)\/\/(www\.|)yout(.*?)\/(embed\/|watch.*?v=|)([a-z_A-Z0-9\-]{11})/i', $url, $results );

    if ( isset( $results[6] ) && $results[6] ) {
      return $results[6];
    }
  }
}
function get_video_thumbnail( $video_url = null, $args = '' ) {

    $args = wp_parse_args( $args );

    if (is_home()) {
      $video_url = get_theme_mod('anymag_video_url');
      $start = get_theme_mod('anymag_video_start');
      $end   = get_theme_mod('anymag_video_end');
      $id = get_youtube_video_id($video_url);
    }
    else {
      $post_id = get_the_ID();
      $video_url = get_post_meta( $post_id, 'post_video_url', true );
      $start = get_post_meta( $post_id, 'post_video_bg_start_time', true );
      $end   = get_post_meta( $post_id, 'post_video_bg_end_time', true );
      $id = get_youtube_video_id($video_url);
    }

    $id = get_youtube_video_id($video_url);
    
    if ( $id ) {
      ?>
      <div class="loader"></div>
      <div class="video-wrapper" data-video-id="<?php echo esc_attr( $id ); ?>" data-video-start="<?php echo esc_attr( $start ); ?>" data-video-end="<?php echo esc_attr( $end ); ?>">
        <div class="video-content"></div>
      </div>
      <?php if(get_theme_mod('anymag_vid_control', true)) : ?> 
        <div class="video-control">
          <span class="video-button video-volume video-mute"><i class="fas fa-volume-down"></i></span>
          <span class="video-button video-state video-pause"><i class="far fa-pause-circle"></i></span>
        </div>
      <?php endif; ?>   
     <?php
    }
  }

// Author Social Links
function anymag_contactmethods( $contactmethods ) {

  $contactmethods['facebook']  = 'Facebook Link';
  $contactmethods['twitter']   = 'Twitter Link';
  $contactmethods['linkedin']  = 'Linkedin Link';
  $contactmethods['tumblr']    = 'Tumblr Link';
  $contactmethods['instagram'] = 'Instagram Link';
  $contactmethods['pinterest'] = 'Pinterest Link';

  return $contactmethods;
}
add_filter('user_contactmethods','anymag_contactmethods',10,1);


//Add Meta Description
function insert_descr_in_head() {
  if (have_posts()) {
  global $post;
      echo '<meta property="description" content="' .anymag_excerpt(20). '"/>'."\n";
  }  
}
add_action( 'wp_head', 'insert_descr_in_head', 5 );

//Social Share Info
function insert_og_image_in_head() {
  if (have_posts()) {
  global $post;
  if(has_post_thumbnail( $post->ID )) {
      $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'anymag-misc' );
      echo '<meta property="og:image" content="' . esc_html( $thumbnail_src[0] ) . '"/>';
    } 
  }  
}
add_action( 'wp_head', 'insert_og_image_in_head', 5 );

function insert_og_descr_in_head() {
  global $post;
    echo '<meta property="og:description" content="'. esc_attr(anymag_excerpt(20)).'"/>';
}
add_action( 'wp_head', 'insert_og_descr_in_head', 5 );


//Submenu Toggle
add_filter( 'walker_nav_menu_start_el', 'add_arrow',10,4);
function add_arrow( $output, $item, $depth, $args ){
if('header-menu' == $args->theme_location ) {
  if (in_array("menu-item-has-children", $item->classes)) {
    $output .='<span class="sub-menu-toggle"></span>';
  }
}
  return $output;
}

//Pagination

function anymag_pagination($pages = '', $range = 2) {  
    $showitems = ($range * 2)+1;
    $out ='';

    global $paged;
    if(empty($paged)) $paged = 1;

    if($pages == '') {
      global $wp_query;
      $pages = $wp_query->max_num_pages;
      if(!$pages) {
        $pages = 1;
      }
    }
    
    if(1 != $pages) {
      if($paged > 1) {
        $out .= get_previous_posts_link('<i class="fa fa-angle-left"></i>');
      }
      
      for ($i=1; $i <= $pages; $i++) {
        if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) {
          $out .= ($paged == $i)? "<span class=\"current\">".$i."</span>":"<a href='".get_pagenum_link($i)."' class=\"inactive\">".$i."</a>";
        }
      }
      if ($paged < $pages) {
          $out .= get_next_posts_link('<i class="fa fa-angle-right"></i>');
        }
    }
    return '<nav class="navigation pagination"><div class="nav-links">'.$out.'</div></nav>';
}

function anymag_pagination_type() {
  $pagn_type = get_theme_mod('anymag_pagination_type');
  if($pagn_type == 'loadmore' || $pagn_type == 'infinite') {
      wp_enqueue_script('infinite-scroll');
      $script = "var win = jQuery(window);
        var doc = jQuery(document);
        var gridBlog = jQuery('.blog-posts');
        doc.ready(function($){ 

          gridBlog.infinitescroll({
            navSelector  : '.page-nav #pagination', 
            nextSelector : '.page-nav #pagination a',
            itemSelector : '.post-item', 
            history: true,
            scrollThreshold: true,
                loading: {
                  finishedMsg: '".esc_html__('No more items to load.', 'anymag')."',
                  msgText: '<i class=\"fa fa-spinner fa-spin fa-1x\"></i>'
                },
              },  
            );
              $('a.loadmore').click(function () {
                $(this).addClass('active');
                gridBlog.infinitescroll('retrieve');
                return false;
            });
         });";
         if($pagn_type == 'loadmore') {
            $script .= "jQuery(document).ready(function(){
              gridBlog;
              jQuery(window).unbind('.infscr');
           });";
         }
      
      wp_add_inline_script('infinite-scroll', $script);
  
      echo '<div id="pagination" class="hide pagination">'.get_next_posts_link().'</div>';
      if($pagn_type == 'loadmore') {
      echo '<div class="loadmore-container"><a href="#" class="loadmore button"><span>'.esc_html__('Load More', 'anymag').'</span></a></div>';
      }
  } 
  else { 
    echo anymag_pagination(); 
  }
}


// add tag support to pages
function tags_support_all() {
  register_taxonomy_for_object_type('post_tag', 'page');
}

// ensure all tags are included in queries
function tags_support_query($wp_query) {
  if ($wp_query->get('tag')) $wp_query->set('post_type', 'any');
}

// tag hooks
add_action('init', 'tags_support_all');
add_action('pre_get_posts', 'tags_support_query');

// WooCommerce
//--------------------------------------------------------------------------*/
if( class_exists('WooCommerce') ){
  
  add_action( 'after_setup_theme', 'anymag_woocommerce_support' );
  function anymag_woocommerce_support() {
    add_theme_support( 'woocommerce' );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );
  }

  function anymag_add_to_cart_header( $fragments ) {
    ob_start(); ?>
    <?php if( WC()->cart->get_cart_contents_count() >= 0 ) : ?>
      <span class="cart-count"><?php echo sprintf (_n( '%d', '%d', WC()->cart->get_cart_contents_count(), 'anymag' ), WC()->cart->get_cart_contents_count() ); ?></span>
    <?php endif; ?>
    <?php $fragments['span.cart-count'] = ob_get_clean(); return $fragments;
  }
  add_filter( 'woocommerce_add_to_cart_fragments', 'anymag_add_to_cart_header' );

  function anymag_related_products_args( $args ) {
    $args['posts_per_page'] = 4; // 4 related products
    $args['columns'] = 4; // arranged in 4 columns
    return $args;
  }
  
  add_filter( 'woocommerce_output_related_products_args', 'anymag_related_products_args' );
  //move message to top
  remove_action( 'woocommerce_before_shop_loop', 'wc_print_notices', 10 );
  add_action( 'woocommerce_show_message', 'wc_print_notices', 10 );
  //remove add to cart button after item
  remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
  remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
    //Single product organize
  remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
  add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 15 );
  remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
  add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 15 );
  remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
  //remove cart total under cross sell
  remove_action( 'woocommerce_before_single_product', 'woocommerce_output_all_notices', 10 );
  
}

if ( !function_exists('anymag_get_products') ) {
    function anymag_get_products( $args = array() ) {

      global $woocommerce, $wp_query;

        $args = wp_parse_args( $args, array(
          'categories' => array(),
          'product_type' => 'recent_product',
          'paged' => 1,
          'post_per_page' => -1,
          'orderby' => '',
          'order' => '',
          'includes' => array(),
          'excludes' => array(),
          'author' => '',
        ));
        extract($args);

        $query_args = array(
          'post_type' => 'product',
          'posts_per_page' => $post_per_page,
          'post_status' => 'publish'
        );

        switch ($product_type) {
          case 'best_selling':
            $query_args['meta_key']='total_sales';
            $query_args['orderby']='meta_value_num';
            $query_args['ignore_sticky_posts']   = 1;
            $query_args['meta_query'] = array();
            $query_args['meta_query'][] = $woocommerce->query->stock_status_meta_query();
            $query_args['meta_query'][] = $woocommerce->query->visibility_meta_query();
          break;
          case 'featured_product':
            $product_visibility_term_ids = wc_get_product_visibility_term_ids();
            $query_args['tax_query'][] = array(
                'taxonomy' => 'product_visibility',
                'field'    => 'term_taxonomy_id',
                'terms'    => $product_visibility_term_ids['featured'],
            );
          break;
          case 'top_rate':
            $query_args['meta_query'] = array();
            $query_args['meta_query'][] = $woocommerce->query->stock_status_meta_query();
            $query_args['meta_query'][] = $woocommerce->query->visibility_meta_query();
          break;
          case 'recent_product':
            $query_args['meta_query'] = array();
            $query_args['meta_query'][] = $woocommerce->query->stock_status_meta_query();
          break;
          case 'on_sale':
            $product_ids_on_sale    = wc_get_product_ids_on_sale();
            $product_ids_on_sale[]  = 0;
            $query_args['post__in'] = $product_ids_on_sale;
          break;            
        }

    $loop = new WP_Query($query_args);
    return $loop;
  }
} 


  





