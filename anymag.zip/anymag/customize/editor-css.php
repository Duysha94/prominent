<?php
function anymag_editor_dynamic_styles() {
?>
<?php ob_start(); ?>

body .editor-styles-wrapper {
  background:  <?php echo esc_attr(get_theme_mod('anymag_site_bg_color', '#fff')); ?>; 
}

.editor-styles-wrapper .edit-post-visual-editor__post-title-wrapper .editor-post-title,
body .editor-post-title__block .editor-post-title__input,
.wp-block.editor-block-list__block .editor-block-list__block-edit .title h2, 
.wp-block.editor-block-list__block .editor-block-list__block-edit .title h3,
.editor-post-title__block .editor-post-title__input { 
  font-family: <?php echo esc_attr(get_theme_mod( 'anymag_title_font', 'Oswald' )); ?>;
  font-weight: <?php echo esc_attr(get_theme_mod('anymag_title_font_weight', '800')); ?>;
  font-size: <?php echo esc_attr(get_theme_mod('anymag_post_title_font_size', '67')); ?>px;
  line-height: <?php echo esc_attr(get_theme_mod('anymag_single_title_line', '1.2')); ?>em;
  letter-spacing: <?php echo esc_attr(get_theme_mod('anymag_single_title_letterspace', '1')); ?>px; 
  color: <?php echo esc_attr(get_theme_mod('anymag_post_title_color', '#111111')); ?>; 
}

body .editor-styles-wrapper .editor-block-list__block-edit .components-autocomplete > p:not(.wp-block-cover-text),
body .editor-styles-wrapper:not(pre),
body .editor-styles-wrapper p,
body .editor-styles-wrapper ul.wp-block li,
body .editor-styles-wrapper .wp-block ul li,
body .editor-styles-wrapper ol.wp-block li {
  font-family: <?php echo esc_attr(get_theme_mod( 'anymag_main_font', 'Poppins' )); ?>;
  font-size: <?php echo esc_attr(get_theme_mod( 'anymag_font_size', '15' )); ?>px;
  line-height: <?php echo esc_attr(get_theme_mod('anymag_mainfont_line', '1.6')); ?>em;
  letter-spacing: <?php echo esc_attr(get_theme_mod('anymag_mainfont_letterspace', '0')); ?>px; 
}

body .wp-block.editor-block-list__block .editor-block-list__block-edit,
body .editor-styles-wrapper .editor-block-list__block-edit .components-autocomplete > p:not(.wp-block-cover-text),
body .editor-styles-wrapper {
  color: <?php echo esc_attr(get_theme_mod('anymag_post_text_color', '#787878')); ?>; 
}

.wp-block.editor-block-list__block .editor-block-list__block-edit .has-regular-font-size {
  font-size: <?php echo esc_attr(get_theme_mod( 'anymag_font_size', '15' )); ?>px;
}

body .editor-styles-wrapper h1, 
body .editor-styles-wrapper h2, 
body .editor-styles-wrapper h3, 
body .editor-styles-wrapper h4, 
body .editor-styles-wrapper h5, 
body .editor-styles-wrapper h6  {
  font-family: <?php echo esc_attr(get_theme_mod( 'anymag_title_font', 'Oswald' )); ?>;  
  color: <?php echo esc_attr(get_theme_mod('anymag_post_title_color', '#111111')); ?>; 
}

.wp-block-freeform.block-library-rich-text__tinymce a, body .block-editor-rich-text__editable a {
  color: <?php echo esc_attr(get_theme_mod('anymag_post_title_color', '#111111')); ?>; 
}

body a, 
body .wp-block-freeform a {
  color: <?php echo esc_attr(get_theme_mod('anymag_link_color', '#111111')); ?>; 
}

body blockquote,
body .editor-styles-wrapper blockquote,
body .editor-styles-wrapper .wp-block-block-quote,
body .editor-styles-wrapper .wp-block-quote {
  border-left: 3px solid <?php echo esc_attr(get_theme_mod('anymag_toggle_background', '#ff027f')); ?>;
  color: <?php echo esc_attr(get_theme_mod('anymag_post_title_color', '#111111')); ?>; 
}


body .wp-block-freeform.block-library-rich-text__tinymce blockquote,
body .wp-block-quote div {
  color: <?php echo esc_attr(get_theme_mod('anymag_post_title_color', '#111111')); ?>; 
}

<?php 
  if(get_theme_mod('anymag_title_upper')) {
    $css = '
      .editor-post-title,
			body .editor-post-title__block .editor-post-title__input,
			.wp-block.editor-block-list__block .editor-block-list__block-edit .title h2, 
			.wp-block.editor-block-list__block .editor-block-list__block-edit .title h3,
			.editor-post-title__block .editor-post-title__input { 
      text-transform: uppercase;
    }';
    echo esc_attr( $css,'anymag' );
  }
?>

body .wp-block-button__link {
  background-color:<?php echo esc_attr(get_theme_mod('anymag_button_color', '#ff027f')); ?>!important;
  color: <?php echo esc_attr(get_theme_mod('anymag_button_text_color', '#fff')); ?>;
  border: 2px solid <?php echo esc_attr(get_theme_mod('anymag_button_color', '#ff027f')); ?>!important;
}

body .wp-block-button .wp-block-button__link:hover {
  background-color:<?php echo esc_attr(get_theme_mod('anymag_button_hover_color', '#ff027f')); ?>!important;
  color: <?php echo esc_attr(get_theme_mod('anymag_button_text_color', '#fff')); ?>;
  border: 2px solid <?php echo esc_attr(get_theme_mod('anymag_button_hover_color', '#ff027f')); ?>!important;
}  

.wp-block-freeform.block-library-rich-text__tinymce a, 
body .block-editor-rich-text__editable a {
  color: <?php echo esc_attr(get_theme_mod('anymag_link_color', '#111111')); ?>;
}

.wp-block-freeform.block-library-rich-text__tinymce a:hover, 
body .block-editor-rich-text__editable a:hover {
  color: <?php echo esc_attr(get_theme_mod('anymag_link_hover', '#999999')); ?>;
}

<?php $out=ob_get_contents(); $out = anymag_minify($out); ob_end_clean();
    wp_add_inline_style('anymag-blocks-style', $out);
}
add_action( 'enqueue_block_editor_assets', 'anymag_editor_dynamic_styles', 30 );
?>